const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const projectInterface = `
export interface Project {
  id: number | string;
  name: string;
  district: string;
  stage: number;
  status: string;
  founder?: string;
}
`;

code = code.replace(/import \* as THREE from 'three';/, "import * as THREE from 'three';\n" + projectInterface);

code = code.replace(/project: any/g, "project: Project");
code = code.replace(/aliveProjects: any\[\]/g, "aliveProjects: Project[]");
code = code.replace(/deadProjects: any\[\]/g, "deadProjects: Project[]");
code = code.replace(/p: any/g, "p: Project");
code = code.replace(/revivingIds: Set<any>/g, "revivingIds: Set<number | string>");
code = code.replace(/timeColors: any/g, "timeColors: Record<string, string>");
code = code.replace(/setCollabProject: \(p: Project\) => void, /g, "");

fs.writeFileSync('src/components/City3D.tsx', code);

// In App.tsx also fix setCollabProject not being passed/needed?
// Let's not touch App.tsx unless it fails. Wait, City3D inside App.tsx receives setCollabProject but we just removed it from props in City3D.tsx. Let's remove it from App.tsx as well.

let appCode = fs.readFileSync('src/App.tsx', 'utf-8');
appCode = appCode.replace(/setCollabProject=\{setCollabProject\}/, "");
fs.writeFileSync('src/App.tsx', appCode);

