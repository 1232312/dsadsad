const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// Add import
code = code.replace(/import { CreateProjectService } from '\.\/lib\/CreateProjectService';/, `import { CreateProjectService } from './lib/CreateProjectService';\nimport { City3D } from './components/City3D';`);

// Replace Main City Viewport contents
const startIdx = code.indexOf('{/* Main City Viewport */}');
const endIdx = code.indexOf('<ProjectCubeOverlay project={selectedProject}');

if (startIdx !== -1 && endIdx !== -1) {
  const replacement = `{/* Main City Viewport */}
        <div className="flex-1 overflow-auto relative bg-transparent">
          <City3D 
            aliveProjects={aliveProjects}
            deadProjects={deadProjects}
            setSelectedProject={setSelectedProject}
            setCollabProject={setCollabProject}
            revivingIds={revivingIds}
            timeColors={timeColors}
          />
        </div>
        
        <AnimatePresence>
          {selectedProject && (
            `;
            
  const sliceBefore = code.slice(0, startIdx);
  const sliceAfter = code.slice(endIdx);
  
  code = sliceBefore + replacement + sliceAfter;
} else {
  console.log("Could not find bounds");
}

fs.writeFileSync('src/App.tsx', code);
