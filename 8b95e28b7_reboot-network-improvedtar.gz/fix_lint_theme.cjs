const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/theme: any/g, "theme: { color: string, emissive: string }");

fs.writeFileSync('src/components/City3D.tsx', code);
