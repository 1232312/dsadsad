const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/useFrame\(\(state\) => \{\n    if \(ref\.current\) \{\n      ref\.current\.children\.forEach/, "useFrame(() => {\n    if (ref.current) {\n      ref.current.children.forEach");

// Let's make a regex that handles this globally just in case
code = code.replace(/useFrame\(\(state\) => \{\n    if \(ref.current\) \{\n      ref.current.children.forEach\(\(child, i\) => \{\n        const drone = drones\[i\];/g, "useFrame(() => {\n    if (ref.current) {\n      ref.current.children.forEach((child, i) => {\n        const drone = drones[i];");

fs.writeFileSync('src/components/City3D.tsx', code);
