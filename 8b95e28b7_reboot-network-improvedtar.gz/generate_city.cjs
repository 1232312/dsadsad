const fs = require('fs');

const code = `import React, { useRef, useState, useEffect, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { CameraControls, Text, Edges, ContactShadows, Environment, Float, Html, Sparkles, Stars, Grid } from '@react-three/drei';
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';

export interface Project {
  id: number | string;
  name: string;
  district: string;
  stage: number;
  status: string;
  founder?: string;
  timeline?: string;
}

const THEMES: Record<string, {color: string, emissive: string}> = {
  'AI District': { color: '#22d3ee', emissive: '#0891b2' },
  'Gaming': { color: '#e879f9', emissive: '#c026d3' },
  'Health': { color: '#34d399', emissive: '#059669' },
  'Finance': { color: '#fbbf24', emissive: '#d97706' },
  'Education': { color: '#60a5fa', emissive: '#2563eb' },
  'Art & Design': { color: '#f87171', emissive: '#dc2626' },
  'default': { color: '#a78bfa', emissive: '#7c3aed' }
};

function getProjectPosition(project: Project, aliveProjects: Project[], deadProjects: Project[]): THREE.Vector3 {
  const isDead = project.stage === 0 || project.status === 'Abandoned';
  const spacing = 8;
  if (!isDead) {
    const cols = Math.ceil(Math.sqrt(aliveProjects.length || 1)) + 1;
    const i = aliveProjects.findIndex(p => p.id === project.id);
    const x = (i % cols) * spacing - ((cols * spacing) / 2);
    const z = Math.floor(i / cols) * spacing - 15;
    return new THREE.Vector3(x, 0, z);
  } else {
    const colsDead = Math.ceil(Math.sqrt(deadProjects.length || 1)) + 1;
    const i = deadProjects.findIndex(p => p.id === project.id);
    const x = (i % colsDead) * spacing - ((colsDead * spacing) / 2);
    const z = Math.floor(i / colsDead) * spacing + 15;
    return new THREE.Vector3(x, 0, z);
  }
}

function SciFiBuilding({ stage, isDead, isReviving, theme, hovered }: any) {
  const matBlack = useMemo(() => new THREE.MeshStandardMaterial({ color: '#0a0a0c', roughness: 0.2, metalness: 0.8 }), []);
  const matDead = useMemo(() => new THREE.MeshStandardMaterial({ color: '#050505', roughness: 0.9, metalness: 0.1 }), []);
  
  const emissiveColor = isDead ? '#ff0000' : theme.emissive;
  const matGlow = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#000000', 
    emissive: emissiveColor, 
    emissiveIntensity: hovered || isReviving ? 3 : (isDead ? 0.5 : 1.5)
  }), [emissiveColor, hovered, isReviving, isDead]);

  const h = isDead ? 0.5 : Math.max(1, stage * 1.8);
  const w = isDead ? 1.5 : (1 + stage * 0.15);

  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (isDead && ref.current) {
      // Glitching effect for dead buildings
      const flicker = Math.random() > 0.95 ? 0.1 : 0.5;
      (matGlow as any).emissiveIntensity = flicker;
    }
    if (isReviving && ref.current) {
      // Pulse effect
      (matGlow as any).emissiveIntensity = 2 + Math.sin(state.clock.elapsedTime * 8) * 1.5;
    }
  });

  return (
    <group ref={ref} position={[0, h/2, 0]}>
      {/* Main Core */}
      <mesh material={isDead ? matDead : matBlack}>
        <boxGeometry args={[w, h, w]} />
        <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
      </mesh>

      {/* Neon Accents */}
      {!isDead && stage >= 2 && (
        <mesh material={matGlow} position={[0, 0, w/2 + 0.01]}>
          <planeGeometry args={[w * 0.1, h * 0.8]} />
        </mesh>
      )}
      {!isDead && stage >= 3 && (
        <mesh material={matGlow} position={[w/2 + 0.01, 0, 0]} rotation={[0, Math.PI/2, 0]}>
          <planeGeometry args={[w * 0.1, h * 0.8]} />
        </mesh>
      )}

      {/* Roof Structures */}
      {stage >= 3 && !isDead && (
        <group position={[0, h/2, 0]}>
          <mesh material={matBlack} position={[0, 0.2, 0]}>
            <cylinderGeometry args={[w*0.3, w*0.3, 0.4, 8]} />
          </mesh>
          <mesh material={matGlow} position={[0, 0.45, 0]}>
            <cylinderGeometry args={[w*0.1, w*0.1, 0.1, 8]} />
          </mesh>
        </group>
      )}

      {/* Landmark Ring */}
      {stage >= 5 && !isDead && (
        <Float speed={2} rotationIntensity={1}>
          <mesh position={[0, h/2 + 2, 0]} rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[w*1.5, 0.05, 16, 64]} />
            <meshBasicMaterial color={theme.color} />
          </mesh>
        </Float>
      )}

      {/* Reviving Scaffold */}
      {isReviving && (
        <mesh>
          <boxGeometry args={[w + 0.4, h + 0.4, w + 0.4]} />
          <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
        </mesh>
      )}
    </group>
  );
}

function HtmlNode({ position, title, value, children }: any) {
  return (
    <Html position={position} center className="pointer-events-auto z-50">
      <div className="bg-black/90 border border-fuchsia-500/30 p-3 rounded-lg backdrop-blur-xl min-w-[140px] shadow-[0_0_30px_rgba(232,121,249,0.15)] transform transition-transform hover:scale-105">
        <div className="text-[9px] text-fuchsia-400 font-mono uppercase tracking-[0.2em] mb-1.5 opacity-80">{title}</div>
        {value && <div className="text-sm text-white font-medium tracking-wide">{value}</div>}
        {children}
      </div>
    </Html>
  );
}

function EchoAIBrain({ project, isDead, onRevive, close }: any) {
  const brainRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (brainRef.current) {
      brainRef.current.rotation.y += 0.005;
      brainRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <group position={[0, 4, 0]}>
      <Float speed={2} floatIntensity={1}>
        <group ref={brainRef}>
          <mesh>
            <icosahedronGeometry args={[1.5, 2]} />
            <meshBasicMaterial color={isDead ? "#ff0000" : "#0891b2"} wireframe transparent opacity={0.4} />
          </mesh>
          <mesh>
            <icosahedronGeometry args={[0.8, 1]} />
            <meshBasicMaterial color={isDead ? "#880000" : "#22d3ee"} transparent opacity={0.6} />
          </mesh>
          <Sparkles count={50} scale={3} size={4} speed={0.5} color={isDead ? "#ff0000" : "#ffffff"} />
        </group>
      </Float>

      {/* Neural Nodes */}
      <HtmlNode position={[2.5, 1.5, 0]} title="Founder" value={project.founder || "Unknown"} />
      <HtmlNode position={[-2.5, 1, 1]} title="Status" value={project.status} />
      <HtmlNode position={[0, 3, 0]} title="Timeline" value={project.timeline || "Active"} />
      <HtmlNode position={[1.5, -2, 1]} title="District" value={project.district} />
      
      <Html position={[0, -3.5, 0]} center className="pointer-events-auto z-50">
        <div className="flex gap-4">
          {isDead && (
            <button 
              onClick={(e) => { e.stopPropagation(); onRevive(project.id); close(); }} 
              className="bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500 text-cyan-400 px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
            >
              Initiate Revival
            </button>
          )}
          <button 
            onClick={(e) => { e.stopPropagation(); close(); }} 
            className="bg-white/5 hover:bg-white/10 border border-white/20 text-white px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
          >
            Close Core
          </button>
        </div>
      </Html>
    </group>
  );
}

function BuildingNode({ project, position, onClick, isReviving, isDead, isSelected, onRevive, close }: any) {
  const [hovered, setHovered] = useState(false);
  const theme = THEMES[project.district] || THEMES.default;

  if (isSelected) {
    return (
      <group position={position}>
        <EchoAIBrain project={project} isDead={isDead} onRevive={onRevive} close={close} />
        {/* Faded ghost of the building */}
        <group opacity={0.1} transparent>
          <SciFiBuilding stage={project.stage} isDead={isDead} isReviving={isReviving} theme={theme} hovered={false} />
        </group>
      </group>
    );
  }

  return (
    <group 
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        onClick(project);
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
        document.body.style.cursor = 'pointer';
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setHovered(false);
        document.body.style.cursor = 'auto';
      }}
    >
      <SciFiBuilding stage={project.stage} isDead={isDead} isReviving={isReviving} theme={theme} hovered={hovered} />
      
      {/* Label */}
      <Text
        position={[0, Math.max(1, project.stage * 1.8) + (hovered ? 1.5 : 0.5), 0]}
        fontSize={0.5}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.05}
        outlineColor="black"
        visible={hovered}
      >
        {project.name}
      </Text>
    </group>
  );
}

function CityEnvironment({ aliveProjects, deadProjects, onProjectClick, revivingIds, selectedProject, onRevive, close }: any) {
  const controlsRef = useRef<CameraControls>(null);

  useEffect(() => {
    if (selectedProject && controlsRef.current) {
      const pos = getProjectPosition(selectedProject, aliveProjects, deadProjects);
      controlsRef.current.setLookAt(
        pos.x, pos.y + 6, pos.z + 12, // camera pos
        pos.x, pos.y + 3, pos.z,      // target pos
        true                          // animate
      );
    } else if (controlsRef.current) {
      // Default view
      controlsRef.current.setLookAt(0, 30, 45, 0, 0, 0, true);
    }
  }, [selectedProject, aliveProjects, deadProjects]);

  return (
    <group>
      <CameraControls 
        ref={controlsRef} 
        maxPolarAngle={Math.PI / 2 - 0.05}
        minDistance={5}
        maxDistance={150}
        makeDefault
      />
      
      {aliveProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray()}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={false}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      <Float speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
        <Text 
          position={[0, 0.5, 7]} 
          fontSize={3} 
          color="#ff0000" 
          rotation={[-Math.PI/2, 0, 0]} 
          opacity={0.3} 
          transparent 
          outlineWidth={0.05} 
          outlineColor="black"
        >
          GRAVEYARD
        </Text>
      </Float>
      
      {deadProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray()}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={true}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      {/* Cyberpunk Ground & Roads */}
      <Grid
        position={[0, -0.01, -10]}
        args={[200, 100]}
        cellSize={2}
        cellThickness={1}
        cellColor="#0891b2"
        sectionSize={10}
        sectionThickness={1.5}
        sectionColor="#22d3ee"
        fadeDistance={80}
        fadeStrength={1.5}
      />
      
      <Grid
        position={[0, -0.02, 20]}
        args={[200, 60]}
        cellSize={2}
        cellThickness={1}
        cellColor="#660000"
        sectionSize={10}
        sectionThickness={1.5}
        sectionColor="#ff0000"
        fadeDistance={50}
        fadeStrength={2}
      />
      
      <ContactShadows resolution={1024} scale={150} blur={2.5} opacity={0.6} far={20} color="#000000" />
      <Environment preset="night" />
      <Sparkles count={800} scale={150} size={1.5} speed={0.2} opacity={0.1} color="#22d3ee" />
      <Stars radius={100} depth={50} count={3000} factor={3} saturation={0} fade speed={0.5} />
    </group>
  );
}

export function City3D({ aliveProjects, deadProjects, selectedProject, setSelectedProject, onRevive, revivingIds, timeColors }: { 
  aliveProjects: Project[], 
  deadProjects: Project[], 
  selectedProject: Project | null,
  setSelectedProject: (p: Project | null) => void,
  onRevive: (id: any) => void,
  revivingIds: Set<number | string>, 
  timeColors: Record<string, string> 
}) {
  return (
    <div className="absolute inset-0 w-full h-full z-10 pointer-events-auto bg-[#020203]">
      <Canvas camera={{ position: [0, 30, 45], fov: 45 }}>
        <fog attach="fog" args={['#020203', 20, 120]} />
        <ambientLight intensity={0.2} />
        <directionalLight position={[15, 30, 10]} intensity={1.5} color={timeColors?.ambientLight || '#ffffff'} />
        <pointLight position={[0, 10, -10]} intensity={1.5} color="#22d3ee" distance={80} />
        <pointLight position={[0, 5, 20]} intensity={1.5} color="#ff0000" distance={60} />
        
        <CityEnvironment 
          aliveProjects={aliveProjects}
          deadProjects={deadProjects}
          onProjectClick={setSelectedProject}
          revivingIds={revivingIds}
          selectedProject={selectedProject}
          onRevive={onRevive}
          close={() => setSelectedProject(null)}
        />
        
        <EffectComposer disableNormalPass>
          <Bloom luminanceThreshold={0.6} mipmapBlur intensity={1.5} />
          <ChromaticAberration offset={new THREE.Vector2(0.0005, 0.0005)} />
          <Vignette eskil={false} offset={0.1} darkness={1.2} />
        </EffectComposer>
      </Canvas>
      
      {/* Search/Exit Overlay (Optional HTML layer over Canvas) */}
      {selectedProject && (
        <div className="absolute top-8 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="bg-black/80 border border-cyan-500/50 px-6 py-3 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.2)]">
            <h2 className="text-xl font-bold text-white tracking-widest uppercase">{selectedProject.name}</h2>
            <div className="text-xs text-cyan-400 font-mono tracking-widest text-center mt-1">ECHO AI CORE ACCESSED</div>
          </div>
        </div>
      )}
    </div>
  );
}
`

fs.writeFileSync('src/components/City3D.tsx', code);
