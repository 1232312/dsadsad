const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const trafficComponent = `
function CityTraffic() {
  const count = 30;
  const drones = useMemo(() => Array.from({ length: count }).map(() => ({
    x: (Math.random() - 0.5) * 150,
    y: 5 + Math.random() * 15,
    z: (Math.random() - 0.5) * 100,
    speed: 0.1 + Math.random() * 0.3,
    axis: Math.random() > 0.5 ? 'x' : 'z',
    color: Math.random() > 0.5 ? '#22d3ee' : '#e879f9'
  })), []);
  
  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (ref.current) {
      ref.current.children.forEach((child, i) => {
        const drone = drones[i];
        if (drone.axis === 'x') {
          child.position.x += drone.speed;
          if (child.position.x > 75) child.position.x = -75;
        } else {
          child.position.z += drone.speed;
          if (child.position.z > 50) child.position.z = -50;
        }
      });
    }
  });

  return (
    <group ref={ref}>
      {drones.map((d, i) => (
        <mesh key={i} position={[d.x, d.y, d.z]}>
          <boxGeometry args={[0.3, 0.1, 0.3]} />
          <meshBasicMaterial color={d.color} />
        </mesh>
      ))}
    </group>
  );
}
`;

if (!code.includes('CityTraffic')) {
  const insertIndex = code.indexOf('function CityEnvironment');
  code = code.slice(0, insertIndex) + trafficComponent + '\n' + code.slice(insertIndex);
  
  // Add <CityTraffic /> to CityEnvironment
  code = code.replace(/<Environment preset="night" \/>/, "<Environment preset=\"night\" />\n      <CityTraffic />");
  
  fs.writeFileSync('src/components/City3D.tsx', code);
}
