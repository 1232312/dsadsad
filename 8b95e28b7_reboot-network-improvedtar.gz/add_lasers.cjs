const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const revivingAdditions = `
      {/* Reviving Scaffold */}
      {isReviving && (
        <group>
          <mesh>
            <boxGeometry args={[w + 0.4, h + 0.4, w + 0.4]} />
            <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
          </mesh>
          {/* Repair Lasers */}
          <mesh position={[w, h, w]} rotation={[0.5, -0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.8} />
          </mesh>
          <mesh position={[-w, h, -w]} rotation={[-0.5, 0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#e879f9" transparent opacity={0.8} />
          </mesh>
          {/* Drones */}
          <mesh position={[w + 1, h + 1, w + 1]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          <mesh position={[-w - 1, h + 1, -w - 1]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        </group>
      )}
`;

code = code.replace(/\{\/\* Reviving Scaffold \*\/\}\s*\{isReviving && \(\s*<mesh>\s*<boxGeometry args=\{\[w \+ 0\.4, h \+ 0\.4, w \+ 0\.4\]\} \/>\s*<meshBasicMaterial color="#00ffff" wireframe transparent opacity=\{0\.3\} \/>\s*<\/mesh>\s*\)\}/, revivingAdditions);

fs.writeFileSync('src/components/City3D.tsx', code);
