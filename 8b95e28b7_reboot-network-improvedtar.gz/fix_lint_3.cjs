const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/export function City3D\({ aliveProjects, deadProjects, setSelectedProject, setCollabProject, revivingIds, timeColors }: \{ aliveProjects: Project\[\], deadProjects: Project\[\], setSelectedProject: \(p: Project\) => void, revivingIds: Set<number \| string>, timeColors: Record<string, string> \}/, "export function City3D({ aliveProjects, deadProjects, setSelectedProject, revivingIds, timeColors }: { aliveProjects: Project[], deadProjects: Project[], setSelectedProject: (p: Project) => void, revivingIds: Set<number | string>, timeColors: Record<string, string> })");

fs.writeFileSync('src/components/City3D.tsx', code);
