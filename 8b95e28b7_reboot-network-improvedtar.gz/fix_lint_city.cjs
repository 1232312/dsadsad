const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/function SciFiBuilding\(\{ stage, isDead, isReviving, theme, hovered \}: any\)/g, "function SciFiBuilding({ stage, isDead, isReviving, theme, hovered }: { stage: number, isDead: boolean, isReviving: boolean, theme: any, hovered: boolean })");
code = code.replace(/function HtmlNode\(\{ position, title, value, children \}: any\)/g, "function HtmlNode({ position, title, value, children }: { position: [number, number, number], title: string, value?: string, children?: React.ReactNode })");
code = code.replace(/function EchoAIBrain\(\{ project, isDead, onRevive, close \}: any\)/g, "function EchoAIBrain({ project, isDead, onRevive, close }: { project: Project, isDead: boolean, onRevive: (id: string | number) => void, close: () => void })");
code = code.replace(/function BuildingNode\(\{ project, position, onClick, isReviving, isDead, isSelected, onRevive, close \}: any\)/g, "function BuildingNode({ project, position, onClick, isReviving, isDead, isSelected, onRevive, close }: { project: Project, position: [number, number, number], onClick: (p: Project) => void, isReviving: boolean, isDead: boolean, isSelected: boolean, onRevive: (id: string | number) => void, close: () => void })");
code = code.replace(/function CityEnvironment\(\{ aliveProjects, deadProjects, onProjectClick, revivingIds, selectedProject, onRevive, close \}: any\)/g, "function CityEnvironment({ aliveProjects, deadProjects, onProjectClick, revivingIds, selectedProject, onRevive, close }: { aliveProjects: Project[], deadProjects: Project[], onProjectClick: (p: Project) => void, revivingIds: Set<number | string>, selectedProject: Project | null, onRevive: (id: string | number) => void, close: () => void })");
code = code.replace(/onRevive: \(id: any\) => void/g, "onRevive: (id: string | number) => void");
code = code.replace(/\(matGlow as any\)\.emissiveIntensity/g, "matGlow.emissiveIntensity");

fs.writeFileSync('src/components/City3D.tsx', code);
