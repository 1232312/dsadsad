const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const newThemes = `const THEMES: Record<string, {color: string, emissive: string}> = {
  'AI District': { color: '#22d3ee', emissive: '#0891b2' },
  'Gaming': { color: '#e879f9', emissive: '#c026d3' },
  'Health': { color: '#34d399', emissive: '#059669' },
  'Finance': { color: '#fbbf24', emissive: '#d97706' },
  'Education': { color: '#60a5fa', emissive: '#2563eb' },
  'Art & Design': { color: '#f87171', emissive: '#dc2626' },
  'Robotics': { color: '#f97316', emissive: '#c2410c' },
  'Space': { color: '#ffffff', emissive: '#94a3b8' },
  'Open Source': { color: '#84cc16', emissive: '#4d7c0f' },
  'Marketplace': { color: '#38bdf8', emissive: '#0284c7' },
  'default': { color: '#a78bfa', emissive: '#7c3aed' }
};`;

code = code.replace(/const THEMES: Record<string, \{color: string, emissive: string\}> = \{[\s\S]*?'default': \{ color: '#a78bfa', emissive: '#7c3aed' \}\n\};/, newThemes);

const newLandmarkIf = `
    let Landmark = DefaultLandmark;
    if (district === 'AI District') Landmark = AILandmark;
    else if (district === 'Gaming') Landmark = GamingLandmark;
    else if (district === 'Robotics') Landmark = RoboticsLandmark;
    else if (district === 'Space') Landmark = SpaceLandmark;
`;

code = code.replace(/let Landmark = DefaultLandmark;\s*if \(district === 'AI District'\) Landmark = AILandmark;\s*else if \(district === 'Gaming'\) Landmark = GamingLandmark;\s*else if \(district === 'Robotics District'\) Landmark = RoboticsLandmark;\s*else if \(district === 'Space District'\) Landmark = SpaceLandmark;/, newLandmarkIf);

fs.writeFileSync('src/components/City3D.tsx', code);
