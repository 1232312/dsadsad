const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/opacity=\{0\.3\} \n\s*transparent \n/g, 'fillOpacity={0.3}\n');
code = code.replace(/opacity=\{0\.3\}\n\s*transparent\n/g, 'fillOpacity={0.3}\n');

// Also fix the import error: TS1259: Module '"/app/applet/node_modules/@types/react/index"' can only be default-imported using the 'esModuleInterop' flag
code = code.replace(/import React, /g, 'import * as React from "react";\nimport ');

fs.writeFileSync('src/components/City3D.tsx', code);
