const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/useFrame\(\(state\) => \{\n    if \(ref.current\) \{\n      ref.current.children.forEach/, "useFrame(() => {\n    if (ref.current) {\n      ref.current.children.forEach");

fs.writeFileSync('src/components/City3D.tsx', code);
