const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

// Replace SciFiBuilding definition
const newSciFiBuilding = `
function AILandmark({ w, h, theme, hovered, matBlack, matGlow }: any) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.children[1].rotation.z = state.clock.elapsedTime * 0.5; // Neural ring rotate
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[w*0.8, w*1.2, h, 8]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      {/* Neural Ring */}
      <mesh position={[0, h/2 + 1, 0]} material={matGlow} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[w*1.5, 0.1, 16, 64]} />
      </mesh>
      <mesh material={matGlow} position={[0, 0, w*0.8]}>
        <planeGeometry args={[0.2, h*0.8]} />
      </mesh>
    </group>
  );
}

function GamingLandmark({ w, h, theme, hovered, matBlack, matGlow }: any) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.children.forEach((child, i) => {
        if (i > 0) child.rotation.y = Math.sin(state.clock.elapsedTime * 0.5 + i) * 0.1;
      });
    }
  });
  return (
    <group ref={ref} position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <boxGeometry args={[w*1.5, h*0.3, w*1.5]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <mesh material={matBlack} position={[0, h*0.3, 0]}>
        <boxGeometry args={[w*1.2, h*0.3, w*1.2]} />
      </mesh>
      <mesh material={matGlow} position={[0, h*0.6, 0]}>
        <boxGeometry args={[w*0.8, h*0.3, w*0.8]} />
      </mesh>
      {/* Floating neon blocks */}
      <Float speed={3} floatIntensity={2}>
        <mesh material={matGlow} position={[w, h*0.5, w]}>
          <boxGeometry args={[0.5, 0.5, 0.5]} />
        </mesh>
        <mesh material={matGlow} position={[-w, h*0.8, -w]}>
          <boxGeometry args={[0.3, 0.3, 0.3]} />
        </mesh>
      </Float>
    </group>
  );
}

function RoboticsLandmark({ w, h, theme, hovered, matBlack, matGlow }: any) {
  const armRef = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (armRef.current) {
      armRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * Math.PI / 4;
      armRef.current.children[0].rotation.z = Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <boxGeometry args={[w*2, h*0.6, w*2]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      {/* Robotic Arm */}
      <group ref={armRef} position={[0, h*0.3, 0]}>
        <mesh material={matBlack} position={[0, h*0.2, 0]}>
          <cylinderGeometry args={[0.2, 0.3, h*0.4]} />
        </mesh>
        <mesh material={matGlow} position={[0, h*0.4, 0]}>
          <sphereGeometry args={[0.3]} />
        </mesh>
      </group>
    </group>
  );
}

function SpaceLandmark({ w, h, theme, hovered, matBlack, matGlow }: any) {
  const satRef = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (satRef.current) {
      satRef.current.rotation.y = state.clock.elapsedTime * 0.8;
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[w*0.5, w*1.5, h, 4]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      {/* Launch Tower Light */}
      <mesh material={matGlow} position={[0, h/2, 0]}>
        <cylinderGeometry args={[0.1, 0.1, h*1.2]} />
      </mesh>
      {/* Orbiting Satellite */}
      <group ref={satRef} position={[0, h*0.6, 0]}>
        <mesh material={matGlow} position={[w*2, 0, 0]}>
          <sphereGeometry args={[0.2]} />
        </mesh>
      </group>
    </group>
  );
}

function DefaultLandmark({ w, h, theme, hovered, matBlack, matGlow }: any) {
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[0.1, w*1.5, h*1.2, 4]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <Float speed={2}>
        <mesh material={matGlow} position={[0, h*0.7, 0]}>
          <octahedronGeometry args={[w*0.8]} />
        </mesh>
      </Float>
    </group>
  );
}

function SciFiBuilding({ stage, district, isDead, isReviving, theme, hovered }: { stage: number, district: string, isDead: boolean, isReviving: boolean, theme: { color: string, emissive: string }, hovered: boolean }) {
  const matBlack = useMemo(() => new THREE.MeshStandardMaterial({ color: '#0a0a0c', roughness: 0.2, metalness: 0.8 }), []);
  const matDead = useMemo(() => new THREE.MeshStandardMaterial({ color: '#050505', roughness: 0.9, metalness: 0.1 }), []);
  
  const emissiveColor = isDead ? '#ff0000' : theme.emissive;
  const matGlow = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#000000', 
    emissive: emissiveColor, 
    emissiveIntensity: hovered || isReviving ? 3 : (isDead ? 0.5 : 1.5)
  }), [emissiveColor, hovered, isReviving, isDead]);

  const h = isDead ? 0.5 : Math.max(1, stage * 1.8);
  const w = isDead ? 1.5 : (1 + stage * 0.15);

  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (isDead && ref.current) {
      const flicker = Math.random() > 0.95 ? 0.1 : 0.5;
      matGlow.emissiveIntensity = flicker;
    }
    if (isReviving && ref.current) {
      matGlow.emissiveIntensity = 2 + Math.sin(state.clock.elapsedTime * 8) * 1.5;
    }
  });

  if (stage >= 5 && !isDead) {
    let Landmark = DefaultLandmark;
    if (district === 'AI District') Landmark = AILandmark;
    else if (district === 'Gaming') Landmark = GamingLandmark;
    else if (district === 'Robotics District') Landmark = RoboticsLandmark;
    else if (district === 'Space District') Landmark = SpaceLandmark;
    
    return (
      <group ref={ref}>
        <Landmark w={w} h={h} theme={theme} hovered={hovered} matBlack={matBlack} matGlow={matGlow} />
        {isReviving && (
          <group position={[0, h/2, 0]}>
            <mesh>
              <boxGeometry args={[w*2 + 0.4, h*1.5 + 0.4, w*2 + 0.4]} />
              <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
            </mesh>
          </group>
        )}
      </group>
    );
  }

  return (
    <group ref={ref} position={[0, h/2, 0]}>
      {/* Main Core */}
      <mesh material={isDead ? matDead : matBlack}>
        <boxGeometry args={[w, h, w]} />
        <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
      </mesh>

      {/* Neon Accents */}
      {!isDead && stage >= 2 && (
        <mesh material={matGlow} position={[0, 0, w/2 + 0.01]}>
          <planeGeometry args={[w * 0.1, h * 0.8]} />
        </mesh>
      )}
      {!isDead && stage >= 3 && (
        <mesh material={matGlow} position={[w/2 + 0.01, 0, 0]} rotation={[0, Math.PI/2, 0]}>
          <planeGeometry args={[w * 0.1, h * 0.8]} />
        </mesh>
      )}

      {/* Roof Structures */}
      {stage >= 3 && !isDead && (
        <group position={[0, h/2, 0]}>
          <mesh material={matBlack} position={[0, 0.2, 0]}>
            <cylinderGeometry args={[w*0.3, w*0.3, 0.4, 8]} />
          </mesh>
          <mesh material={matGlow} position={[0, 0.45, 0]}>
            <cylinderGeometry args={[w*0.1, w*0.1, 0.1, 8]} />
          </mesh>
        </group>
      )}

      {/* Reviving Scaffold */}
      {isReviving && (
        <group>
          <mesh>
            <boxGeometry args={[w + 0.4, h + 0.4, w + 0.4]} />
            <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
          </mesh>
          {/* Repair Lasers */}
          <mesh position={[w, h, w]} rotation={[0.5, -0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.8} />
          </mesh>
          <mesh position={[-w, h, -w]} rotation={[-0.5, 0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#e879f9" transparent opacity={0.8} />
          </mesh>
          {/* Drones */}
          <mesh position={[w + 1, h + 1, w + 1]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          <mesh position={[-w - 1, h + 1, -w - 1]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        </group>
      )}
    </group>
  );
}
`;

const oldSciFiBuildingStart = code.indexOf('function SciFiBuilding');
const htmlNodeStart = code.indexOf('function HtmlNode');

if (oldSciFiBuildingStart !== -1 && htmlNodeStart !== -1) {
  code = code.slice(0, oldSciFiBuildingStart) + newSciFiBuilding + '\n' + code.slice(htmlNodeStart);
}

// Update BuildingNode to pass district
code = code.replace(/<SciFiBuilding stage=\{project.stage\} isDead=\{isDead\} isReviving=\{isReviving\} theme=\{theme\} hovered=\{false\} \/>/, "<SciFiBuilding stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={false} />");
code = code.replace(/<SciFiBuilding stage=\{project.stage\} isDead=\{isDead\} isReviving=\{isReviving\} theme=\{theme\} hovered=\{hovered\} \/>/, "<SciFiBuilding stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={hovered} />");

fs.writeFileSync('src/components/City3D.tsx', code);
