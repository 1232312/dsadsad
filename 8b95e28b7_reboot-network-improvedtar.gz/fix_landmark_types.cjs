const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const typeReplacement = '{ w, h, theme, hovered, matBlack, matGlow }: { w: number, h: number, theme: { color: string, emissive: string }, hovered: boolean, matBlack: THREE.Material, matGlow: THREE.Material }';

code = code.replace(/function AILandmark\(\{ w, h, theme, hovered, matBlack, matGlow \}: any\)/g, "function AILandmark(" + typeReplacement + ")");
code = code.replace(/function GamingLandmark\(\{ w, h, theme, hovered, matBlack, matGlow \}: any\)/g, "function GamingLandmark(" + typeReplacement + ")");
code = code.replace(/function RoboticsLandmark\(\{ w, h, theme, hovered, matBlack, matGlow \}: any\)/g, "function RoboticsLandmark(" + typeReplacement + ")");
code = code.replace(/function SpaceLandmark\(\{ w, h, theme, hovered, matBlack, matGlow \}: any\)/g, "function SpaceLandmark(" + typeReplacement + ")");
code = code.replace(/function DefaultLandmark\(\{ w, h, theme, hovered, matBlack, matGlow \}: any\)/g, "function DefaultLandmark(" + typeReplacement + ")");

fs.writeFileSync('src/components/City3D.tsx', code);
