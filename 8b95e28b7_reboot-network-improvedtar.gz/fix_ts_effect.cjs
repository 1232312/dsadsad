const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

code = code.replace(/<EffectComposer disableNormalPass>/, '<EffectComposer disableNormalPass={true} enableNormalPass={false}>'); // let's just remove disableNormalPass
code = code.replace(/<EffectComposer disableNormalPass=\{true\} enableNormalPass=\{false\}>/, '<EffectComposer>');

fs.writeFileSync('src/components/City3D.tsx', code);
