const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

// Fix theme: any in AnimatedWindows
code = code.replace(/theme: any/g, "theme: { color: string, emissive: string }");

// Remove unused theme and hovered from Landmarks if they are not used. 
// Actually they are used in AILandmark? Wait, I didn't use them, I used matGlow which has the color.
// Let's just suppress the unused vars.
code = code.replace(/\{ w, h, theme, hovered, matBlack, matGlow \}/g, "{ w, h, matBlack, matGlow }");
code = code.replace(/Landmark w=\{w\} h=\{h\} theme=\{theme\} hovered=\{hovered\} matBlack=\{matBlack\} matGlow=\{matGlow\} \/>/, "Landmark w={w} h={h} matBlack={matBlack} matGlow={matGlow} />");

code = code.replace(/\{ w: number, h: number, theme: \{ color: string, emissive: string \}, hovered: boolean, matBlack: THREE.Material, matGlow: THREE.Material \}/g, "{ w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }");

fs.writeFileSync('src/components/City3D.tsx', code);
