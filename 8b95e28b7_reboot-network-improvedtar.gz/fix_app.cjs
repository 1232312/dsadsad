const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(/<AnimatePresence>\s*\{selectedProject && \(\s*\)\}\s*<\/AnimatePresence>/g, "");

fs.writeFileSync('src/App.tsx', code);
