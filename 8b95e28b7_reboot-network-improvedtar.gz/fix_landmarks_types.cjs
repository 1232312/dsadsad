const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const interfaceCode = `export interface LandmarkProps {
  w: number;
  h: number;
  matBlack: THREE.Material;
  matGlow: THREE.Material;
  theme?: { color: string; emissive: string };
  project?: Project;
  zoomLevel?: number;
}
`;

if (!code.includes('LandmarkProps')) {
  code = code.replace(/function AnimatedWindows/, interfaceCode + '\nfunction AnimatedWindows');
}

const replaceOldSignature = /\{ w: number, h: number, matBlack: THREE\.Material, matGlow: THREE\.Material \}/g;
code = code.replace(replaceOldSignature, 'LandmarkProps');

code = code.replace(/let Landmark = DefaultLandmark;/, "let Landmark: React.FC<LandmarkProps> = DefaultLandmark;");

fs.writeFileSync('src/components/City3D.tsx', code);
