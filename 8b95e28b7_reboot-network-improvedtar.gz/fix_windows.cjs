const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

const windowsComponent = `
function AnimatedWindows({ w, h, isDead, theme }: { w: number, h: number, isDead: boolean, theme: any }) {
  const windowCount = Math.floor(h * 2);
  const windows = useMemo(() => {
    return Array.from({ length: windowCount }).map((_, i) => ({
      y: (i / windowCount) * h - h/2 + 0.2,
      flickerOffset: Math.random() * Math.PI * 2,
      speed: 0.5 + Math.random(),
      isOn: Math.random() > 0.5
    }));
  }, [h, windowCount]);

  const matRef = useRef<THREE.MeshStandardMaterial>(null);

  useFrame((state) => {
    if (isDead && matRef.current) {
      // Glitchy abandoned windows
      matRef.current.emissiveIntensity = Math.random() > 0.95 ? 0.2 : 0;
    } else if (matRef.current) {
      // Slow pulse for active windows
      matRef.current.emissiveIntensity = 0.5 + Math.sin(state.clock.elapsedTime * 0.5) * 0.5;
    }
  });

  return (
    <group>
      {windows.map((win, i) => (
        win.isOn || isDead ? (
          <mesh key={i} position={[w/2 + 0.01, win.y, 0]} rotation={[0, Math.PI/2, 0]}>
            <planeGeometry args={[w * 0.4, 0.2]} />
            <meshStandardMaterial ref={matRef} color="#000000" emissive={isDead ? '#330000' : theme.emissive} />
          </mesh>
        ) : null
      ))}
      {windows.map((win, i) => (
        win.isOn || isDead ? (
          <mesh key={'b'+i} position={[-w/2 - 0.01, win.y, 0]} rotation={[0, -Math.PI/2, 0]}>
            <planeGeometry args={[w * 0.4, 0.2]} />
            <meshStandardMaterial color="#000000" emissive={isDead ? '#330000' : theme.emissive} />
          </mesh>
        ) : null
      ))}
    </group>
  );
}
`;

if (!code.includes('AnimatedWindows')) {
  const insertIndex = code.indexOf('function AILandmark');
  code = code.slice(0, insertIndex) + windowsComponent + '\n' + code.slice(insertIndex);
}

// Add AnimatedWindows to SciFiBuilding and Landmarks
code = code.replace(/\{(\/\* Neon Accents \*\/)\}/, "<AnimatedWindows w={w} h={h} isDead={isDead} theme={theme} />\n      {$1}");

fs.writeFileSync('src/components/City3D.tsx', code);
