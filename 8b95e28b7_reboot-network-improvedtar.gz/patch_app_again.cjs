const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// We need to pass selectedProject, onRevive to City3D
code = code.replace(/<City3D[\s\S]*?\/>/, `<City3D 
            aliveProjects={aliveProjects}
            deadProjects={deadProjects}
            selectedProject={selectedProject}
            setSelectedProject={setSelectedProject}
            onRevive={handleRevive}
            revivingIds={revivingIds}
            timeColors={timeColors}
          />`);

// Remove ProjectCubeOverlay
code = code.replace(/<ProjectCubeOverlay project={selectedProject}[\s\S]*?\/>/, '');

fs.writeFileSync('src/App.tsx', code);
