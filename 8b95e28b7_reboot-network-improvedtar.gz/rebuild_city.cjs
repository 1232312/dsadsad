const fs = require('fs');

const code = `import React, { useRef, useState, useEffect, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { CameraControls, Text, Edges, ContactShadows, Environment, Float, Html, Sparkles, Stars, Grid, Line } from '@react-three/drei';
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';

export interface Project {
  id: number | string;
  name: string;
  district: string;
  stage: number;
  status: string;
  founder?: string;
  timeline?: string;
}

const THEMES: Record<string, {color: string, emissive: string}> = {
  'AI District': { color: '#22d3ee', emissive: '#0891b2' },
  'Gaming': { color: '#e879f9', emissive: '#c026d3' },
  'Health': { color: '#34d399', emissive: '#059669' },
  'Finance': { color: '#fbbf24', emissive: '#d97706' },
  'Education': { color: '#60a5fa', emissive: '#2563eb' },
  'Art & Design': { color: '#f87171', emissive: '#dc2626' },
  'Robotics': { color: '#f97316', emissive: '#c2410c' },
  'Space': { color: '#ffffff', emissive: '#94a3b8' },
  'Open Source': { color: '#84cc16', emissive: '#4d7c0f' },
  'Marketplace': { color: '#38bdf8', emissive: '#0284c7' },
  'default': { color: '#a78bfa', emissive: '#7c3aed' }
};

const DISTRICT_CENTERS: Record<string, [number, number]> = {
  'AI District': [0, 0],
  'Gaming': [45, 30],
  'Health': [-45, 30],
  'Finance': [45, -30],
  'Education': [-45, -30],
  'Art & Design': [70, 0],
  'Robotics': [-70, 0],
  'Space': [0, -60],
  'Open Source': [0, 60],
  'Marketplace': [70, -60],
  'default': [70, 60]
};

function getProjectPosition(project: Project, aliveProjects: Project[], deadProjects: Project[]): THREE.Vector3 {
  const isDead = project.stage === 0 || project.status === 'Abandoned';
  if (isDead) {
    const i = deadProjects.findIndex(p => p.id === project.id);
    const cols = Math.ceil(Math.sqrt(deadProjects.length || 1));
    const x = (i % cols) * 12 - ((cols * 12) / 2);
    const z = Math.floor(i / cols) * 12 + 80;
    return new THREE.Vector3(x, 0, z);
  }

  const center = DISTRICT_CENTERS[project.district] || DISTRICT_CENTERS.default;
  const sameDistrict = aliveProjects.filter(p => p.district === project.district);
  const idx = sameDistrict.findIndex(p => p.id === project.id);
  
  const cols = Math.ceil(Math.sqrt(sameDistrict.length));
  const x = center[0] + ((idx % cols) - cols/2) * 15;
  const z = center[1] + (Math.floor(idx / cols) - cols/2) * 15;
  
  return new THREE.Vector3(x, 0, z);
}

function AnimatedWindows({ w, h, isDead, theme }: { w: number, h: number, isDead: boolean, theme: { color: string, emissive: string } }) {
  const windowCount = Math.floor(h * 3);
  const windows = useMemo(() => {
    return Array.from({ length: windowCount }).map((_, i) => ({
      y: (i / windowCount) * h - h/2 + 0.2,
      isOn: Math.random() > 0.5
    }));
  }, [h, windowCount]);

  const matRef = useRef<THREE.MeshStandardMaterial>(null);

  useFrame((state) => {
    if (isDead && matRef.current) {
      matRef.current.emissiveIntensity = Math.random() > 0.95 ? 0.2 : 0;
    } else if (matRef.current) {
      matRef.current.emissiveIntensity = 0.5 + Math.sin(state.clock.elapsedTime * 0.5) * 0.5;
    }
  });

  return (
    <group>
      {windows.map((win, i) => (
        win.isOn || isDead ? (
          <mesh key={i} position={[w/2 + 0.01, win.y, 0]} rotation={[0, Math.PI/2, 0]}>
            <planeGeometry args={[w * 0.4, 0.2]} />
            <meshStandardMaterial ref={matRef} color="#000000" emissive={isDead ? '#330000' : theme.emissive} />
          </mesh>
        ) : null
      ))}
      {windows.map((win, i) => (
        win.isOn || isDead ? (
          <mesh key={'b'+i} position={[-w/2 - 0.01, win.y, 0]} rotation={[0, -Math.PI/2, 0]}>
            <planeGeometry args={[w * 0.4, 0.2]} />
            <meshStandardMaterial color="#000000" emissive={isDead ? '#330000' : theme.emissive} />
          </mesh>
        ) : null
      ))}
    </group>
  );
}

function AILandmark({ w, h, matBlack, matGlow }: { w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.children[1].rotation.z = state.clock.elapsedTime * 0.5;
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[w*0.8, w*1.2, h, 8]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <mesh position={[0, h/2 + 1, 0]} material={matGlow} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[w*1.5, 0.1, 16, 64]} />
      </mesh>
      <mesh material={matGlow} position={[0, 0, w*0.8]}>
        <planeGeometry args={[0.2, h*0.8]} />
      </mesh>
    </group>
  );
}

function GamingLandmark({ w, h, matBlack, matGlow }: { w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.children.forEach((child, i) => {
        if (i > 0) child.rotation.y = Math.sin(state.clock.elapsedTime * 0.5 + i) * 0.1;
      });
    }
  });
  return (
    <group ref={ref} position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <boxGeometry args={[w*1.5, h*0.3, w*1.5]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <mesh material={matBlack} position={[0, h*0.3, 0]}>
        <boxGeometry args={[w*1.2, h*0.3, w*1.2]} />
      </mesh>
      <mesh material={matGlow} position={[0, h*0.6, 0]}>
        <boxGeometry args={[w*0.8, h*0.3, w*0.8]} />
      </mesh>
      <Float speed={3} floatIntensity={2}>
        <mesh material={matGlow} position={[w, h*0.5, w]}>
          <boxGeometry args={[0.5, 0.5, 0.5]} />
        </mesh>
        <mesh material={matGlow} position={[-w, h*0.8, -w]}>
          <boxGeometry args={[0.3, 0.3, 0.3]} />
        </mesh>
      </Float>
    </group>
  );
}

function RoboticsLandmark({ w, h, matBlack, matGlow }: { w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  const armRef = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (armRef.current) {
      armRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * Math.PI / 4;
      armRef.current.children[0].rotation.z = Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <boxGeometry args={[w*2, h*0.6, w*2]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <group ref={armRef} position={[0, h*0.3, 0]}>
        <mesh material={matBlack} position={[0, h*0.2, 0]}>
          <cylinderGeometry args={[0.2, 0.3, h*0.4]} />
        </mesh>
        <mesh material={matGlow} position={[0, h*0.4, 0]}>
          <sphereGeometry args={[0.3]} />
        </mesh>
      </group>
    </group>
  );
}

function SpaceLandmark({ w, h, matBlack, matGlow }: { w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  const satRef = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (satRef.current) {
      satRef.current.rotation.y = state.clock.elapsedTime * 0.8;
    }
  });
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[w*0.5, w*1.5, h, 4]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <mesh material={matGlow} position={[0, h/2, 0]}>
        <cylinderGeometry args={[0.1, 0.1, h*1.2]} />
      </mesh>
      <group ref={satRef} position={[0, h*0.6, 0]}>
        <mesh material={matGlow} position={[w*2, 0, 0]}>
          <sphereGeometry args={[0.2]} />
        </mesh>
      </group>
    </group>
  );
}

function DefaultLandmark({ w, h, matBlack, matGlow }: { w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  return (
    <group position={[0, h/2, 0]}>
      <mesh material={matBlack}>
        <cylinderGeometry args={[0.1, w*1.5, h*1.2, 4]} />
        <Edges scale={1.01} color="#222222" />
      </mesh>
      <Float speed={2}>
        <mesh material={matGlow} position={[0, h*0.7, 0]}>
          <octahedronGeometry args={[w*0.8]} />
        </mesh>
      </Float>
    </group>
  );
}

function Rooftop({ stage, w, h, matBlack, matGlow }: { stage: number, w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  if (stage === 2) {
    return (
      <group position={[0, h/2 + 0.2, 0]}>
        <mesh material={matBlack}>
          <boxGeometry args={[w*0.5, 0.4, w*0.5]} />
        </mesh>
        <mesh material={matGlow} position={[0, 0.2, 0]}>
          <boxGeometry args={[0.1, 0.1, 0.1]} />
        </mesh>
      </group>
    );
  }
  if (stage === 3) {
    return (
      <group position={[0, h/2 + 0.3, 0]}>
        <mesh material={matBlack}>
          <cylinderGeometry args={[w*0.4, w*0.4, 0.2, 8]} />
        </mesh>
        <mesh material={matBlack} position={[-0.2, 0.5, 0]}>
          <cylinderGeometry args={[0.02, 0.02, 1]} />
        </mesh>
        <mesh material={matGlow} position={[-0.2, 1, 0]}>
          <sphereGeometry args={[0.05]} />
        </mesh>
      </group>
    );
  }
  if (stage === 4) {
    return (
      <group position={[0, h/2 + 1, 0]}>
        <Float speed={2}>
          <mesh material={matGlow} rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[w*0.6, 0.05, 8, 32]} />
          </mesh>
        </Float>
        <mesh material={matBlack} position={[0, -0.5, 0]}>
          <coneGeometry args={[w*0.8, 1, 4]} />
        </mesh>
      </group>
    );
  }
  return null;
}

function SciFiBuilding({ stage, district, isDead, isReviving, theme, hovered }: { stage: number, district: string, isDead: boolean, isReviving: boolean, theme: { color: string, emissive: string }, hovered: boolean }) {
  const matBlack = useMemo(() => new THREE.MeshStandardMaterial({ color: '#0a0a0c', roughness: 0.2, metalness: 0.8 }), []);
  const matDead = useMemo(() => new THREE.MeshStandardMaterial({ color: '#050505', roughness: 0.9, metalness: 0.1 }), []);
  
  const emissiveColor = isDead ? '#ff0000' : theme.emissive;
  const matGlow = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#000000', 
    emissive: emissiveColor, 
    emissiveIntensity: hovered || isReviving ? 3 : (isDead ? 0.5 : 1.5)
  }), [emissiveColor, hovered, isReviving, isDead]);

  const h = isDead ? 0.5 : Math.max(1, stage * 1.8);
  const w = isDead ? 1.5 : (1 + stage * 0.15);
  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (isDead && ref.current) {
      const flicker = Math.random() > 0.95 ? 0.1 : 0.5;
      matGlow.emissiveIntensity = flicker;
    }
    if (isReviving && ref.current) {
      matGlow.emissiveIntensity = 2 + Math.sin(state.clock.elapsedTime * 8) * 1.5;
    }
  });

  if (stage >= 5 && !isDead) {
    let Landmark = DefaultLandmark;
    if (district === 'AI District') Landmark = AILandmark;
    else if (district === 'Gaming') Landmark = GamingLandmark;
    else if (district === 'Robotics') Landmark = RoboticsLandmark;
    else if (district === 'Space') Landmark = SpaceLandmark;
    
    return (
      <group ref={ref}>
        <Landmark w={w} h={h} matBlack={matBlack} matGlow={matGlow} />
        {isReviving && (
          <group position={[0, h/2, 0]}>
            <mesh>
              <boxGeometry args={[w*2 + 0.4, h*1.5 + 0.4, w*2 + 0.4]} />
              <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
            </mesh>
          </group>
        )}
      </group>
    );
  }

  return (
    <group ref={ref} position={[0, h/2, 0]}>
      <mesh material={isDead ? matDead : matBlack}>
        {stage === 4 ? (
          <boxGeometry args={[w*0.8, h, w*1.2]} />
        ) : (
          <boxGeometry args={[w, h, w]} />
        )}
        <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
      </mesh>

      {stage === 4 && !isDead && (
        <mesh material={matBlack} position={[w*0.8, 0, 0]}>
          <boxGeometry args={[w*0.5, h*0.8, w*0.8]} />
          <Edges scale={1.01} color="#222222" />
        </mesh>
      )}

      <AnimatedWindows w={w} h={h} isDead={isDead} theme={theme} />

      {!isDead && <Rooftop stage={stage} w={w} h={h} matBlack={matBlack} matGlow={matGlow} />}

      {isReviving && (
        <group>
          <mesh>
            <boxGeometry args={[w + 0.4, h + 0.4, w + 0.4]} />
            <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
          </mesh>
          <mesh position={[w, h, w]} rotation={[0.5, -0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.8} />
          </mesh>
          <mesh position={[-w, h, -w]} rotation={[-0.5, 0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#e879f9" transparent opacity={0.8} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function HtmlNode({ position, title, value, children }: { position: [number, number, number], title: string, value?: string, children?: React.ReactNode }) {
  return (
    <Html position={position} center className="pointer-events-auto z-50">
      <div className="bg-black/90 border border-fuchsia-500/30 p-3 rounded-lg backdrop-blur-xl min-w-[140px] shadow-[0_0_30px_rgba(232,121,249,0.15)] transform transition-transform hover:scale-105">
        <div className="text-[9px] text-fuchsia-400 font-mono uppercase tracking-[0.2em] mb-1.5 opacity-80">{title}</div>
        {value && <div className="text-sm text-white font-medium tracking-wide">{value}</div>}
        {children}
      </div>
    </Html>
  );
}

function EchoAIBrain({ project, isDead, onRevive, close }: { project: Project, isDead: boolean, onRevive: (id: string | number) => void, close: () => void }) {
  const brainRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (brainRef.current) {
      brainRef.current.rotation.y += 0.005;
      brainRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <group position={[0, 4, 0]}>
      <Float speed={2} floatIntensity={1}>
        <group ref={brainRef}>
          <mesh>
            <icosahedronGeometry args={[1.5, 2]} />
            <meshBasicMaterial color={isDead ? "#ff0000" : "#0891b2"} wireframe transparent opacity={0.4} />
          </mesh>
          <mesh>
            <icosahedronGeometry args={[0.8, 1]} />
            <meshBasicMaterial color={isDead ? "#880000" : "#22d3ee"} transparent opacity={0.6} />
          </mesh>
          <Sparkles count={50} scale={3} size={4} speed={0.5} color={isDead ? "#ff0000" : "#ffffff"} />
        </group>
      </Float>
      <HtmlNode position={[2.5, 1.5, 0]} title="Founder" value={project.founder || "Unknown"} />
      <HtmlNode position={[-2.5, 1, 1]} title="Status" value={project.status} />
      <HtmlNode position={[0, 3, 0]} title="Timeline" value={project.timeline || "Active"} />
      <HtmlNode position={[1.5, -2, 1]} title="District" value={project.district} />
      
      <Html position={[0, -3.5, 0]} center className="pointer-events-auto z-50">
        <div className="flex gap-4">
          {isDead && (
            <button 
              onClick={(e) => { e.stopPropagation(); onRevive(project.id); close(); }} 
              className="bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500 text-cyan-400 px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
            >
              Initiate Revival
            </button>
          )}
          <button 
            onClick={(e) => { e.stopPropagation(); close(); }} 
            className="bg-white/5 hover:bg-white/10 border border-white/20 text-white px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
          >
            Close Core
          </button>
        </div>
      </Html>
    </group>
  );
}

function BuildingNode({ project, position, onClick, isReviving, isDead, isSelected, onRevive, close }: { project: Project, position: [number, number, number], onClick: (p: Project) => void, isReviving: boolean, isDead: boolean, isSelected: boolean, onRevive: (id: string | number) => void, close: () => void }) {
  const [hovered, setHovered] = useState(false);
  const theme = THEMES[project.district] || THEMES.default;

  if (isSelected) {
    return (
      <group position={position}>
        <EchoAIBrain project={project} isDead={isDead} onRevive={onRevive} close={close} />
        <group opacity={0.1} transparent>
          <SciFiBuilding stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={false} />
        </group>
      </group>
    );
  }

  return (
    <group 
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        onClick(project);
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
        document.body.style.cursor = 'pointer';
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setHovered(false);
        document.body.style.cursor = 'auto';
      }}
    >
      <SciFiBuilding stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={hovered} />
      <Text
        position={[0, Math.max(1, project.stage * 1.8) + (hovered ? 1.5 : 0.5), 0]}
        fontSize={0.5}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.05}
        outlineColor="black"
        visible={hovered}
      >
        {project.name}
      </Text>
    </group>
  );
}

function DistrictFloor({ aliveProjects }: { aliveProjects: Project[] }) {
  const districts = Array.from(new Set(aliveProjects.map(p => p.district)));
  return (
    <group>
      {districts.map(d => {
        const center = DISTRICT_CENTERS[d] || DISTRICT_CENTERS.default;
        const theme = THEMES[d] || THEMES.default;
        return (
          <group key={d} position={[center[0], -0.05, center[1]]}>
            <mesh rotation={[-Math.PI/2, 0, 0]}>
              <circleGeometry args={[30, 32]} />
              <meshBasicMaterial color={theme.color} transparent opacity={0.02} />
            </mesh>
            <mesh rotation={[-Math.PI/2, 0, 0]}>
              <ringGeometry args={[29.5, 30, 64]} />
              <meshBasicMaterial color={theme.color} transparent opacity={0.15} />
            </mesh>
            <Text position={[0, 0.1, -30]} rotation={[-Math.PI/2, 0, 0]} fontSize={2} color={theme.color} opacity={0.6} transparent font="https://fonts.gstatic.com/s/orbitron/v25/yq5sZ5O8r_b6t9C8oKizRfk.woff">
              {d.toUpperCase()}
            </Text>
          </group>
        )
      })}
    </group>
  );
}

function GlowingRoads({ aliveProjects }: { aliveProjects: Project[] }) {
  const districts = Array.from(new Set(aliveProjects.map(p => p.district)));
  return (
    <group position={[0, 0.05, 0]}>
      {districts.map(d => {
        const theme = THEMES[d] || THEMES.default;
        const projects = aliveProjects.filter(p => p.district === d);
        return projects.map((p, i) => {
          if (i === 0) return null;
          const p1 = getProjectPosition(projects[i-1], aliveProjects, []);
          const p2 = getProjectPosition(p, aliveProjects, []);
          return (
            <Line 
              key={\`\${projects[i-1].id}-\${p.id}\`}
              points={[[p1.x, 0, p1.z], [p2.x, 0, p2.z]]}
              color={theme.color}
              lineWidth={1.5}
              transparent
              opacity={0.3}
            />
          );
        });
      })}
    </group>
  );
}

function CityTraffic() {
  const count = 50;
  const drones = useMemo(() => Array.from({ length: count }).map(() => ({
    x: (Math.random() - 0.5) * 200,
    y: 2 + Math.random() * 40,
    z: (Math.random() - 0.5) * 200,
    speed: 0.1 + Math.random() * 0.4,
    axis: Math.random() > 0.5 ? 'x' : 'z',
    color: Math.random() > 0.5 ? '#22d3ee' : '#e879f9',
    type: Math.random() > 0.8 ? 'heavy' : 'light'
  })), []);
  
  const ref = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (ref.current) {
      ref.current.children.forEach((child, i) => {
        const drone = drones[i];
        if (drone.axis === 'x') {
          child.position.x += drone.speed;
          if (child.position.x > 100) child.position.x = -100;
        } else {
          child.position.z += drone.speed;
          if (child.position.z > 100) child.position.z = -100;
        }
      });
    }
  });

  return (
    <group ref={ref}>
      {drones.map((d, i) => (
        <mesh key={i} position={[d.x, d.y, d.z]}>
          {d.type === 'heavy' ? (
             <boxGeometry args={[0.8, 0.2, 0.8]} />
          ) : (
             <cylinderGeometry args={[0.1, 0.1, 0.4, 4]} />
          )}
          <meshBasicMaterial color={d.color} />
        </mesh>
      ))}
    </group>
  );
}

function CityEnvironment({ aliveProjects, deadProjects, onProjectClick, revivingIds, selectedProject, onRevive, close }: { aliveProjects: Project[], deadProjects: Project[], onProjectClick: (p: Project) => void, revivingIds: Set<number | string>, selectedProject: Project | null, onRevive: (id: string | number) => void, close: () => void }) {
  const controlsRef = useRef<CameraControls>(null);

  useEffect(() => {
    if (selectedProject && controlsRef.current) {
      const pos = getProjectPosition(selectedProject, aliveProjects, deadProjects);
      controlsRef.current.smoothTime = 1.2;
      controlsRef.current.setLookAt(
        pos.x + 8, pos.y + 12, pos.z + 15,
        pos.x, pos.y + 3, pos.z,
        true
      );
    } else if (controlsRef.current) {
      controlsRef.current.smoothTime = 2.0;
      controlsRef.current.setLookAt(0, 50, 90, 0, 0, 0, true);
    }
  }, [selectedProject, aliveProjects, deadProjects]);

  return (
    <group>
      <CameraControls 
        ref={controlsRef} 
        maxPolarAngle={Math.PI / 2 - 0.05}
        minDistance={5}
        maxDistance={250}
        makeDefault
      />
      
      {aliveProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray()}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={false}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      <Float speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
        <Text 
          position={[0, 0.5, 60]} 
          fontSize={3} 
          color="#ff0000" 
          rotation={[-Math.PI/2, 0, 0]} 
          opacity={0.3} 
          transparent 
          outlineWidth={0.05} 
          outlineColor="black"
          font="https://fonts.gstatic.com/s/orbitron/v25/yq5sZ5O8r_b6t9C8oKizRfk.woff"
        >
          GRAVEYARD
        </Text>
      </Float>
      
      {deadProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray()}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={true}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      <DistrictFloor aliveProjects={aliveProjects} />
      <GlowingRoads aliveProjects={aliveProjects} />

      <Grid
        position={[0, -0.01, 0]}
        args={[300, 300]}
        cellSize={5}
        cellThickness={1}
        cellColor="#0891b2"
        sectionSize={25}
        sectionThickness={1.5}
        sectionColor="#22d3ee"
        fadeDistance={150}
        fadeStrength={1.5}
        opacity={0.2}
        transparent
      />
      
      <Grid
        position={[0, -0.02, 80]}
        args={[150, 100]}
        cellSize={5}
        cellThickness={1}
        cellColor="#660000"
        sectionSize={25}
        sectionThickness={1.5}
        sectionColor="#ff0000"
        fadeDistance={100}
        fadeStrength={2}
        opacity={0.3}
        transparent
      />
      
      <ContactShadows resolution={1024} scale={200} blur={2.5} opacity={0.6} far={20} color="#000000" />
      <Environment preset="night" />
      <CityTraffic />
      <Sparkles count={800} scale={250} size={1.5} speed={0.2} opacity={0.1} color="#22d3ee" />
      <Stars radius={150} depth={50} count={3000} factor={3} saturation={0} fade speed={0.5} />
    </group>
  );
}

export function City3D({ aliveProjects, deadProjects, selectedProject, setSelectedProject, onRevive, revivingIds, timeColors }: { 
  aliveProjects: Project[], 
  deadProjects: Project[], 
  selectedProject: Project | null,
  setSelectedProject: (p: Project | null) => void,
  onRevive: (id: string | number) => void,
  revivingIds: Set<number | string>, 
  timeColors: Record<string, string> 
}) {
  return (
    <div className="absolute inset-0 w-full h-full z-10 pointer-events-auto bg-[#020203]">
      <Canvas camera={{ position: [0, 50, 90], fov: 45 }}>
        <fog attach="fog" args={['#020203', 30, 200]} />
        <ambientLight intensity={0.2} />
        <directionalLight position={[15, 40, 10]} intensity={1.5} color={timeColors?.ambientLight || '#ffffff'} />
        <pointLight position={[0, 10, -10]} intensity={1.5} color="#22d3ee" distance={120} />
        <pointLight position={[0, 5, 80]} intensity={1.5} color="#ff0000" distance={100} />
        
        <CityEnvironment 
          aliveProjects={aliveProjects}
          deadProjects={deadProjects}
          onProjectClick={setSelectedProject}
          revivingIds={revivingIds}
          selectedProject={selectedProject}
          onRevive={onRevive}
          close={() => setSelectedProject(null)}
        />
        
        <EffectComposer disableNormalPass>
          <Bloom luminanceThreshold={0.5} mipmapBlur intensity={1.5} />
          <ChromaticAberration offset={new THREE.Vector2(0.0005, 0.0005)} />
          <Vignette eskil={false} offset={0.1} darkness={1.2} />
        </EffectComposer>
      </Canvas>
      
      {selectedProject && (
        <div className="absolute top-8 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="bg-black/80 border border-cyan-500/50 px-6 py-3 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.2)]">
            <h2 className="text-xl font-bold text-white tracking-widest uppercase">{selectedProject.name}</h2>
            <div className="text-xs text-cyan-400 font-mono tracking-widest text-center mt-1">ECHO AI CORE ACCESSED</div>
          </div>
        </div>
      )}
    </div>
  );
}
`
fs.writeFileSync('src/components/City3D.tsx', code);
