/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Cpu, Gamepad2, Activity, Wallet, GraduationCap, PenTool, Bot, Rocket, Code, Store, Lightbulb, Ghost, Sparkles, X, Clock, ArrowUpRight, Users, Zap, LayoutGrid, Snowflake, Sun, CloudLightning, TreePine, ZoomIn, ZoomOut, Network, Brain, Settings } from 'lucide-react';
import { CreateProjectService } from './lib/CreateProjectService';
import { City3D } from './components/City3D';
import { Network3D } from './components/Network3D';

// --- DATA ---
const DISTRICTS = [
  { name: 'AI District', icon: Cpu, color: 'text-cyan-400' },
  { name: 'Gaming', icon: Gamepad2, color: 'text-fuchsia-400' },
  { name: 'Health', icon: Activity, color: 'text-emerald-400' },
  { name: 'Finance', icon: Wallet, color: 'text-amber-400' },
  { name: 'Education', icon: GraduationCap, color: 'text-blue-400' },
  { name: 'Creator', icon: PenTool, color: 'text-pink-400' },
  { name: 'Robotics', icon: Bot, color: 'text-orange-400' },
  { name: 'Space', icon: Rocket, color: 'text-indigo-400' },
  { name: 'Open Source', icon: Code, color: 'text-teal-400' },
  { name: 'Marketplace', icon: Store, color: 'text-yellow-400' },
  { name: 'Idea Hub', icon: Lightbulb, color: 'text-lime-400' },
  { name: 'Graveyard', icon: Ghost, color: 'text-zinc-500' },
];

const SEASONS = ['Summer', 'Winter', 'Halloween', 'Christmas'];

const GENERATE_PROJECTS = () => {
  const list = [
    { id: 1, name: "Nexus AI", district: "AI District", stage: 4, status: "Successful", founder: "Alex_Chen", description: "Generative workflow automation for enterprises. Scales operations 10x without adding headcount.", timeline: "Started 2024. Series A in 2025." },
    { id: 2, name: "Neon Drift", district: "Gaming", stage: 2, status: "Growing", founder: "SarahJ", description: "Cyberpunk racing RPG with procedural city generation.", timeline: "Alpha release Q3 2025." },
    { id: 3, name: "VitalityOS", district: "Health", stage: 3, status: "Growing", founder: "DrMed", description: "Personalized health tracking integrating directly with blood diagnostics.", timeline: "Beta launched." },
    { id: 4, name: "Aura", district: "Graveyard", stage: 0, status: "Abandoned", founder: "Unknown", description: "Social network for lucid dreamers. People could share dreams in a 3D space.", reason: "Ran out of funding. Server costs were too high for the 3D environments.", timeline: "2023 - 2024" },
    { id: 5, name: "OpenBuild", district: "Open Source", stage: 5, status: "Legend", founder: "DevCollective", description: "The largest open-source component library. Used by 1M+ developers.", timeline: "2021 - Present" },
    { id: 6, name: "RoboChef", district: "Robotics", stage: 1, status: "Seed", founder: "KitchenTech", description: "Automated meal prep robot for small apartments.", timeline: "Prototyping phase." },
    { id: 7, name: "Orbital Data", district: "Space", stage: 0, status: "Abandoned", founder: "Stargazer", description: "Satellite data relay service for rural internet.", reason: "Regulatory blocks and high hardware costs.", timeline: "2022 - 2023" },
    { id: 8, name: "FinFlow", district: "Finance", stage: 4, status: "Successful", founder: "CapitalX", description: "Cross-border B2B payments made instant.", timeline: "Processing $100M+ monthly." },
    { id: 9, name: "EduVerse", district: "Education", stage: 2, status: "Growing", founder: "LearnCo", description: "VR classrooms for high school science experiments.", timeline: "Piloting in 50 schools." },
    { id: 10, name: "Artisanal", district: "Marketplace", stage: 1, status: "Seed", founder: "Crafty", description: "Marketplace for strictly handcrafted physical goods.", timeline: "Pre-launch." },
    { id: 11, name: "MindMeld", district: "Idea Hub", stage: 1, status: "Seed", founder: "Thinker99", description: "BCI (Brain-Computer Interface) concept for direct thought-to-text typing.", timeline: "Research phase." },
    { id: 12, name: "PixelForge", district: "Creator", stage: 3, status: "Growing", founder: "DesignPro", description: "AI-assisted pixel art generation tool for indie devs.", timeline: "10k MRR." },
  ];

  const prefixes = ["Quantum", "Aero", "Cyber", "Neuro", "Bio", "Synth", "Omni", "Data", "Meta", "Hyper", "Nova", "Echo", "Flux", "Aether"];
  const suffixes = ["Sync", "Logic", "Net", "Sphere", "Pulse", "Core", "Node", "Wave", "Flow", "Grid", "Link", "Forge", "Base"];

  for (let i = 13; i <= 64; i++) {
    const isGraveyard = Math.random() > 0.85;
    let stage = isGraveyard ? 0 : Math.floor(Math.random() * 4) + 1;
    if (Math.random() > 0.95 && !isGraveyard) stage = 5;

    const dIndex = Math.floor(Math.random() * 11); 
    const district = isGraveyard ? 'Graveyard' : DISTRICTS[dIndex].name;
    const name = prefixes[Math.floor(Math.random() * prefixes.length)] + suffixes[Math.floor(Math.random() * suffixes.length)];

    list.push({
      id: i,
      name,
      district,
      stage,
      status: isGraveyard ? 'Abandoned' : (stage === 1 ? 'Seed' : stage < 4 ? 'Growing' : 'Successful'),
      founder: `User_${Math.floor(Math.random() * 9000) + 1000}`,
      description: `A next-generation platform for the ${district} space. Exploring new boundaries in digital interaction.`,
      timeline: "Ongoing",
      reason: isGraveyard ? "Lack of product-market fit and depleted runway." : undefined
    });
  }
  return list;
};

const INITIAL_PROJECTS = GENERATE_PROJECTS();

// --- HELPERS ---

const useTimeOfDay = () => {
  const [hour, setHour] = useState(new Date().getHours());
  
  useEffect(() => {
    const interval = setInterval(() => {
      setHour(new Date().getHours());
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  return hour;
};

const getTimeColors = (hour: number) => {
  if (hour >= 6 && hour < 9) return { 
    bg: 'bg-[#1a0f14]', text: 'Dawn', 
    sky: 'bg-gradient-to-t from-orange-900/30 via-[#1a0f14] to-[#0a0a0a]',
    fog: 'bg-orange-500/10',
    windowOpacity: 0.6,
    ambientLight: 'rgba(255,150,100,0.1)'
  }; // Sunrise
  if (hour >= 9 && hour < 17) return { 
    bg: 'bg-[#0a1118]', text: 'Day',
    sky: 'bg-gradient-to-t from-blue-900/20 via-[#0a1118] to-[#050505]',
    fog: 'bg-blue-300/5',
    windowOpacity: 0.2,
    ambientLight: 'rgba(150,200,255,0.05)'
  }; // Day
  if (hour >= 17 && hour < 20) return { 
    bg: 'bg-[#1a0b0a]', text: 'Dusk',
    sky: 'bg-gradient-to-t from-purple-900/30 via-red-900/20 to-[#1a0b0a]',
    fog: 'bg-purple-500/10',
    windowOpacity: 0.8,
    ambientLight: 'rgba(200,100,255,0.1)'
  }; // Sunset
  return { 
    bg: 'bg-[#030304]', text: 'Night',
    sky: 'bg-gradient-to-t from-[#0a0a1a] via-[#030304] to-black',
    fog: 'bg-blue-900/10',
    windowOpacity: 1.0,
    ambientLight: 'rgba(50,50,150,0.15)'
  }; // Night
};


const getDistrictTheme = (districtName: string) => {
  const themes: any = {
    'AI District': { base: 'bg-cyan-950/80', border: 'border-cyan-500/40', window: 'bg-cyan-500', glow: 'shadow-[0_0_20px_rgba(34,211,238,0.2)]', text: 'text-cyan-400', activeWindow: 'bg-cyan-200 shadow-[0_0_8px_#22d3ee]', hex: '#22d3ee' },
    'Gaming': { base: 'bg-fuchsia-950/80', border: 'border-fuchsia-500/40', window: 'bg-fuchsia-500', glow: 'shadow-[0_0_20px_rgba(232,121,249,0.2)]', text: 'text-fuchsia-400', activeWindow: 'bg-fuchsia-200 shadow-[0_0_8px_#e879f9]', hex: '#e879f9' },
    'Health': { base: 'bg-emerald-950/80', border: 'border-emerald-500/40', window: 'bg-emerald-500', glow: 'shadow-[0_0_20px_rgba(52,211,153,0.2)]', text: 'text-emerald-400', activeWindow: 'bg-emerald-200 shadow-[0_0_8px_#34d399]', hex: '#34d399' },
    'Finance': { base: 'bg-amber-950/80', border: 'border-amber-500/40', window: 'bg-amber-500', glow: 'shadow-[0_0_20px_rgba(251,191,36,0.2)]', text: 'text-amber-400', activeWindow: 'bg-amber-200 shadow-[0_0_8px_#fbbf24]', hex: '#fbbf24' },
    'Education': { base: 'bg-blue-950/80', border: 'border-blue-500/40', window: 'bg-blue-500', glow: 'shadow-[0_0_20px_rgba(96,165,250,0.2)]', text: 'text-blue-400', activeWindow: 'bg-blue-200 shadow-[0_0_8px_#60a5fa]', hex: '#60a5fa' },
    'Creator': { base: 'bg-pink-950/80', border: 'border-pink-500/40', window: 'bg-pink-500', glow: 'shadow-[0_0_20px_rgba(244,114,182,0.2)]', text: 'text-pink-400', activeWindow: 'bg-pink-200 shadow-[0_0_8px_#f472b6]', hex: '#f472b6' },
    'Robotics': { base: 'bg-orange-950/80', border: 'border-orange-500/40', window: 'bg-orange-500', glow: 'shadow-[0_0_20px_rgba(251,146,60,0.2)]', text: 'text-orange-400', activeWindow: 'bg-orange-200 shadow-[0_0_8px_#fb923c]', hex: '#fb923c' },
    'Space': { base: 'bg-indigo-950/80', border: 'border-indigo-500/40', window: 'bg-indigo-500', glow: 'shadow-[0_0_20px_rgba(129,140,248,0.2)]', text: 'text-indigo-400', activeWindow: 'bg-indigo-200 shadow-[0_0_8px_#818cf8]', hex: '#818cf8' },
    'Open Source': { base: 'bg-teal-950/80', border: 'border-teal-500/40', window: 'bg-teal-500', glow: 'shadow-[0_0_20px_rgba(45,212,191,0.2)]', text: 'text-teal-400', activeWindow: 'bg-teal-200 shadow-[0_0_8px_#2dd4bf]', hex: '#2dd4bf' },
    'Marketplace': { base: 'bg-yellow-950/80', border: 'border-yellow-500/40', window: 'bg-yellow-500', glow: 'shadow-[0_0_20px_rgba(253,224,71,0.2)]', text: 'text-yellow-400', activeWindow: 'bg-yellow-200 shadow-[0_0_8px_#fde047]', hex: '#fde047' },
    'Idea Hub': { base: 'bg-lime-950/80', border: 'border-lime-500/40', window: 'bg-lime-500', glow: 'shadow-[0_0_20px_rgba(163,230,53,0.2)]', text: 'text-lime-400', activeWindow: 'bg-lime-200 shadow-[0_0_8px_#a3e635]', hex: '#a3e635' },
    'Graveyard': { base: 'bg-zinc-900/60', border: 'border-zinc-800', window: 'bg-zinc-800', glow: 'shadow-none', text: 'text-zinc-500', activeWindow: 'bg-zinc-700', hex: '#71717a' },
  };
  return themes[districtName] || themes['AI District'];
};

const getDistrictIcon = (districtName: string) => {
  const d = DISTRICTS.find(d => d.name === districtName);
  return d ? d.icon : Sparkles;
};

// --- COMPONENTS ---

const RebootIntro = ({ onComplete }: { onComplete: () => void }) => {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timings = [
      0,    // 0: Black screen (0.0s)
      1000, // 1: Heartbeat (1.0s)
      1000, // 2: Cyan light (2.0s)
      1000, // 3: Pulses / particles (3.0s)
      1000, // 4: Cubes (4.0s)
      1000, // 5: Rising buildings (5.0s)
      1000, // 6: Lights up (6.0s)
      1000, // 7: Reboot Core (7.0s)
      1000, // 8: Dead building (8.0s)
      1000, // 9: Repair drones (9.0s)
      1000, // 10: Pull back (10.0s)
      1000, // 11: Logo (11.0s)
      1000, // 12: Welcome back (12.0s)
      1000, // 13: Fly in (13.0s)
    ];
    let time = 0;
    timings.forEach((t, i) => {
      time += t;
      setTimeout(() => setPhase(i), time);
    });
    
    // Complete after fly in
    setTimeout(onComplete, time + 1500);
  }, [onComplete]);

  return (
    <motion.div 
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center overflow-hidden font-sans"
      animate={{ 
        scale: phase === 13 ? 2 : 1,
        opacity: phase === 13 ? 0 : 1
      }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
    >
      {/* City Container (Phases 4-10) */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        animate={{ 
          scale: phase >= 10 ? 0.3 : 1, 
          y: phase >= 10 ? 100 : 0,
          opacity: phase >= 11 ? 0.2 : 1
        }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      >
        {/* Heartbeat & Early phases */}
        {phase >= 1 && phase < 4 && (
          <motion.div 
            className="absolute w-32 h-32 rounded-full border border-white/5"
            animate={{ scale: [1, 1.5, 1], opacity: [0, 0.3, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          />
        )}
        
        {phase >= 2 && phase < 4 && (
          <motion.div 
            className="absolute w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_20px_#22d3ee]"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          />
        )}

        {phase >= 3 && phase < 4 && (
          <div className="absolute inset-0 flex items-center justify-center">
            {Array.from({length: 8}).map((_, i) => (
              <motion.div 
                key={i}
                className="absolute w-1 h-1 bg-cyan-300 rounded-full shadow-[0_0_10px_#67e8f9]"
                initial={{ 
                  x: Math.cos(i * Math.PI / 4) * 50, 
                  y: Math.sin(i * Math.PI / 4) * 50, 
                  opacity: 0 
                }}
                animate={{ x: 0, y: 0, opacity: [0, 1, 0] }}
                transition={{ duration: 1, ease: "easeInOut" }}
              />
            ))}
          </div>
        )}

        {/* Cubes & Buildings */}
        {phase >= 4 && (
          <motion.div 
            className="absolute flex items-end justify-center gap-2 md:gap-4 bottom-1/4"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            {[3, 5, 2, 6, 4, 7, 3, 5].map((h, i) => (
               <motion.div 
                 key={i}
                 className="w-4 md:w-8 bg-zinc-900 border border-zinc-800 relative flex flex-col justify-end p-1 gap-1"
                 initial={{ height: 16 }}
                 animate={{ height: phase >= 5 ? h * 24 + 16 : 16 }}
                 transition={{ duration: 1.5, ease: "easeInOut", delay: i * 0.1 }}
               >
                  {phase >= 6 && Array.from({length: h}).map((_, j) => (
                     <motion.div 
                       key={j}
                       className={`w-full h-2 rounded-[1px] ${['bg-cyan-500/80 shadow-[0_0_8px_#22d3ee]', 'bg-fuchsia-500/80 shadow-[0_0_8px_#e879f9]', 'bg-amber-500/80 shadow-[0_0_8px_#fbbf24]'][Math.floor(Math.random() * 3)]}`}
                       initial={{ opacity: 0 }}
                       animate={{ opacity: 1 }}
                       transition={{ duration: 0.5, delay: 0.5 + j * 0.2 + i * 0.1 }}
                     />
                  ))}
               </motion.div>
            ))}
          </motion.div>
        )}

        {/* Dead Building */}
        {phase >= 8 && (
          <motion.div 
            className="absolute bottom-1/4 w-32 h-48 bg-[#0a0a0c] border border-zinc-800 flex items-center justify-center z-50 overflow-hidden shadow-2xl"
            initial={{ y: 50, opacity: 0, scale: 0.8 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            {phase < 9 && <div className="absolute inset-0 bg-black/60 blur-[2px] z-10" />}
            
            {phase === 8 && (
              <div className="absolute z-20 flex flex-col items-center gap-2">
                <div className="text-red-500 text-2xl drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]">⚠</div>
                <div className="text-red-500 text-[9px] font-mono tracking-widest bg-red-500/10 px-2 py-1 rounded border border-red-500/30">ABANDONED</div>
              </div>
            )}

            {phase >= 9 && (
              <>
                <div className="absolute inset-0 border-[2px] border-dashed border-blue-500/30 z-20 opacity-50" />
                
                {/* Repair Drones */}
                <motion.div className="absolute top-4 left-4 w-1.5 h-1.5 bg-blue-400 rounded-full shadow-[0_0_10px_#60a5fa] z-30" animate={{ x: [0, 30, 0], y: [0, 20, 0] }} transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }} />
                <motion.div className="absolute top-12 right-4 w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_10px_#22d3ee] z-30" animate={{ x: [0, -30, 0], y: [0, -20, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }} />
                
                {/* Lasers */}
                <motion.div className="absolute top-4 left-4 w-[1px] h-12 bg-blue-400/40 origin-top z-20" animate={{ rotate: [-20, 20, -20] }} transition={{ duration: 0.5, repeat: Infinity }} />
                
                <motion.div 
                  className="absolute inset-0 bg-cyan-900/20 z-0"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1.5 }}
                />
                <div className="w-full h-full p-4 flex flex-col gap-2 justify-end z-10 relative">
                  {[1,2,3,4,5].map(i => (
                    <motion.div 
                      key={i}
                      className="w-full h-3 bg-cyan-400 shadow-[0_0_15px_#22d3ee] opacity-80 rounded-[1px]"
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ duration: 0.5, delay: i * 0.15 }}
                    />
                  ))}
                </div>
              </>
            )}
          </motion.div>
        )}
      </motion.div>

      {/* Reboot Core Text */}
      {phase >= 7 && phase < 10 && (
        <motion.div 
          className="absolute bottom-24 text-center font-mono z-40"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
        >
          <div className="text-cyan-400 text-sm tracking-[0.2em] mb-2">REBOOT CORE</div>
          <div className="text-gray-500 text-xs tracking-widest animate-pulse">INITIALIZING...</div>
        </motion.div>
      )}

      {/* Final Logo */}
      {phase >= 11 && (
        <motion.div 
          className="absolute flex flex-col items-center justify-center z-50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <div className="text-5xl font-bold tracking-tight text-white mb-4 flex items-center gap-4">
             <div className="w-3 h-3 bg-cyan-400 rounded-full shadow-[0_0_15px_#22d3ee]" />
             REBOOT
          </div>
          <div className="text-gray-400 text-sm md:text-base font-light tracking-wide">
            Every Idea Deserves A Second Chance
          </div>
        </motion.div>
      )}

      {/* Welcome Back Text */}
      {phase >= 12 && (
        <motion.div 
          className="absolute bottom-24 text-cyan-400 text-sm font-mono tracking-widest z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          "Welcome back."
        </motion.div>
      )}
    </motion.div>
  );
};

const Windows = ({ rows, cols, theme, seed, zoomLevel, timeColors }: any) => {
  const pseudoRandom = (i: number) => {
    const x = Math.sin(seed + i * 1.5) * 10000;
    return x - Math.floor(x);
  };

  // Only render windows if zoomed in enough
  if (zoomLevel < 2) return null;

  return (
    <div className="grid gap-[2px] p-[2px] w-full h-full relative z-10" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))` }}>
       {Array.from({length: rows * cols}).map((_, i) => {
         const r = pseudoRandom(i);
         const windowChance = timeColors ? timeColors.windowOpacity : 1.0;
         const isActive = r > (1 - windowChance) * 0.8; // adjust base threshold
         
         return (
           <div key={i} className={`
             ${isActive ? theme.activeWindow : theme.window} 
             ${isActive ? 'opacity-90' : 'opacity-[0.15]'} 
             rounded-[1px] relative overflow-hidden
           `}>
             {isActive && r > 0.95 && (
                <motion.div 
                   animate={{ opacity: [1, 0, 1] }} 
                   transition={{ duration: 2 + r * 3, repeat: Infinity, ease: 'linear' }}
                   className="absolute inset-0 bg-white"
                />
             )}
             {isActive && zoomLevel >= 3 && r > 0.6 && (
                <motion.div 
                   className="absolute bottom-0 w-[1.5px] h-[50%] bg-black/70 rounded-t-[1px]"
                   animate={{ x: [0, 4 + r * 3, 0] }}
                   transition={{ duration: 2 + r * 3, repeat: Infinity, ease: 'easeInOut' }}
                />
             )}
           </div>
         )
       })}
    </div>
  )
}

const DistrictAccent = ({ district, stage }: any) => {
  if (stage < 3) return null;
  
  if (district === 'AI District') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-t-sm">
        <motion.div 
          animate={{ y: ['100%', '-100%'] }} 
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="w-full h-1/2 bg-gradient-to-t from-transparent via-cyan-400/30 to-transparent"
        />
      </div>
    );
  }
  
  if (district === 'Finance') {
    return (
      <div className="absolute top-2 left-0 w-full h-1.5 bg-black/80 overflow-hidden flex items-center border-y border-amber-500/30 z-20">
        <motion.div 
          animate={{ x: ['100%', '-100%'] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="text-[4px] text-amber-400 font-mono whitespace-nowrap leading-none"
        >
          +$2.4M +1.1% -$50K
        </motion.div>
      </div>
    );
  }

  if (district === 'Gaming') {
    return (
      <motion.div 
        animate={{ borderColor: ['#ff00ff', '#00ffff', '#00ff00', '#ff00ff'] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-0 border-2 pointer-events-none opacity-50 z-20"
      />
    );
  }
  
  if (district === 'Health') {
     return (
       <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-20 pointer-events-none z-0">
          <Activity size={32} className="text-emerald-400" />
       </div>
     );
  }
  
  return null;
}

const renderBuildingBlocks = (project: any, theme: any, isHovered: boolean, isReviving: boolean, zoomLevel: number, season: string, timeColors: any) => {
  const stage = project.stage;
  const isGrave = stage === 0 || project.status === 'Abandoned';
  const seed = project.id;
  const Icon = getDistrictIcon(project.district);

  const getSeasonOverlay = () => {
    if (season === 'Winter') {
      return <div className="absolute top-0 left-0 right-0 h-1 bg-white/80 rounded-t-sm z-30 shadow-[0_2px_4px_rgba(255,255,255,0.4)]" />
    }
    if (season === 'Halloween') {
      return <div className="absolute -bottom-2 -left-2 -right-2 h-4 bg-orange-500/20 blur-md z-0 pointer-events-none" />
    }
    if (season === 'Christmas') {
      return (
         <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden border border-red-500/30">
            <motion.div animate={{ opacity: [0.3, 0.8, 0.3] }} transition={{ duration: 2, repeat: Infinity, ease: 'linear' }} className="absolute top-0 right-0 w-2 h-2 bg-green-500 rounded-full blur-[2px]" />
            <motion.div animate={{ opacity: [0.8, 0.3, 0.8] }} transition={{ duration: 2.5, repeat: Infinity, ease: 'linear' }} className="absolute top-4 left-0 w-1.5 h-1.5 bg-red-500 rounded-full blur-[1px]" />
         </div>
      )
    }
    return null;
  }

  const SponsorshipBadge = () => {
    if (stage < 4 || zoomLevel < 4 || seed % 3 !== 0) return null;
    const sponsors = ['NEXUS GRANT', 'AURA TECH', 'CYBERSEC', 'QUANTUM'];
    const sponsor = sponsors[seed % sponsors.length];
    return (
      <div className="absolute top-1/2 left-full ml-2 pointer-events-none z-40 hidden md:block">
        <motion.div 
          className="bg-black/80 border border-cyan-500/30 text-cyan-400 font-mono text-[8px] px-1.5 py-0.5 rounded shadow-[0_0_10px_rgba(34,211,238,0.2)] whitespace-nowrap"
          animate={{ opacity: [0.4, 0.8, 0.4] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear', delay: seed % 2 }}
        >
          {sponsor}
        </motion.div>
        <div className="absolute top-1/2 -left-2 w-2 h-px bg-cyan-500/50" />
      </div>
    );
  };

  const Antenna = () => {
    if (zoomLevel < 3) return null;
    return (
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 flex flex-col items-center">
        <div className="w-[1px] h-4 bg-white/40"></div>
        <motion.div 
           className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" 
           animate={{ opacity: [1, 0, 1] }} 
           transition={{ duration: 2, repeat: Infinity, ease: 'linear', delay: seed % 2 }}
        />
      </div>
    );
  };

  const Steam = () => {
    if (zoomLevel < 3 || season === 'Summer') return null;
    return (
      <motion.div 
         className="absolute bottom-full -right-2 w-6 h-6 bg-white/10 rounded-full blur-md pointer-events-none"
         animate={{ y: [0, -20], x: [0, 10], opacity: [0, 0.5, 0], scale: [0.5, 2] }}
         transition={{ duration: 4 + (seed % 3), repeat: Infinity, ease: 'easeOut', delay: seed % 3 }}
      />
    );
  };

  const renderBuildingCore = () => {
    if (isGrave) {
      return (
        <div className={`w-14 h-16 ${theme.base} border ${theme.border} relative overflow-hidden flex flex-col justify-end opacity-70 z-10`}>
          {getSeasonOverlay()}
          <div className="absolute top-2 left-2 w-4 h-6 border border-white/5 bg-black/50"></div>
          <div className="absolute top-4 right-1 w-3 h-3 border border-white/5 bg-black/80"></div>
          <div className="w-full h-8 bg-black/40 border-t border-white/10 flex items-center justify-center">
             {zoomLevel >= 3 && <Ghost size={14} className="text-zinc-700 opacity-60" />}
          </div>
        </div>
      )
    }

    if (stage === 1) { // Seed
      return (
        <div className="relative w-12 h-10 border border-dashed border-white/20 bg-white/5 flex items-end justify-center pb-1 z-10">
           {getSeasonOverlay()}
           <div className="w-8 h-4 bg-white/10 border border-white/20"></div>
        </div>
      )
    }

    if (stage === 2) { // Growing
      return (
        <div className={`w-14 h-20 ${theme.base} border ${theme.border} border-b-0 relative shadow-md z-10`}>
          {getSeasonOverlay()}
          <Steam />
          <div className="absolute top-0 left-0 w-full h-1 bg-white/20"></div>
          <Windows rows={4} cols={2} theme={theme} seed={seed} zoomLevel={zoomLevel} />
        </div>
      )
    }

    if (stage === 3) { // Startup
      return (
        <div className={`w-16 h-28 ${theme.base} border ${theme.border} border-b-0 relative flex flex-col items-center shadow-lg ${theme.glow} z-10`}>
          {getSeasonOverlay()}
          <Antenna />
          <Steam />
          <div className="w-12 h-3 border-b border-inherit bg-black/20"></div>
          <div className="w-full flex-1">
            <Windows rows={6} cols={3} theme={theme} seed={seed} zoomLevel={zoomLevel} timeColors={timeColors} />
          </div>
        </div>
      )
    }

    if (stage === 4) { // Successful
      return (
        <div className={`w-20 h-40 ${theme.base} border ${theme.border} border-b-0 relative flex flex-col items-center shadow-xl ${theme.glow} z-10`}>
          {getSeasonOverlay()}
          <SponsorshipBadge />
          <Antenna />
          <Steam />
          <div className="w-14 h-4 border-b border-inherit bg-black/20 relative z-20">
             {zoomLevel >= 3 && <DistrictAccent district={project.district} theme={theme} stage={stage} />}
          </div>
          <div className="w-full flex-1 relative z-10">
            <Windows rows={8} cols={4} theme={theme} seed={seed} zoomLevel={zoomLevel} timeColors={timeColors} />
          </div>
        </div>
      )
    }

    if (stage >= 5) { // Legend
      return (
        <div className={`w-24 h-56 ${theme.base} border border-white/30 border-b-0 relative flex flex-col items-center shadow-2xl ${theme.glow} z-10`}>
          {getSeasonOverlay()}
          <SponsorshipBadge />
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 w-16 h-64 blur-2xl pointer-events-none" style={{ background: `linear-gradient(to top, ${theme.hex}60, transparent)` }}></div>

          {zoomLevel >= 3 && (
            <motion.div 
               className={`absolute bottom-[calc(100%+1rem)] left-1/2 -translate-x-1/2 p-3 ${isHovered ? 'scale-110' : ''} transition-transform duration-300 z-30`}
               animate={{ y: [-4, 4, -4] }}
               transition={{ duration: 4 + (seed % 2), repeat: Infinity, ease: 'easeInOut' }}
            >
               <Icon size={32} style={{ color: theme.hex, filter: `drop-shadow(0 0 15px ${theme.hex})` }} />
               <div className="absolute inset-0 overflow-hidden rounded-full pointer-events-none">
                  <motion.div animate={{ y: ['-100%', '200%'] }} transition={{ duration: 2, repeat: Infinity, ease: 'linear' }} className="w-full h-[2px] bg-white/60 blur-[1px]" />
               </div>
            </motion.div>
          )}
          
          <div className={`absolute -left-2 top-12 w-2 h-1/2 ${theme.border} border-y border-l bg-black/30`}></div>
          <div className={`absolute -right-2 top-12 w-2 h-1/2 ${theme.border} border-y border-r bg-black/30`}></div>

          <div className="w-16 h-8 border-b border-inherit bg-white/10 relative z-20 overflow-hidden">
             {zoomLevel >= 3 && <DistrictAccent district={project.district} theme={theme} stage={stage} />}
          </div>
          <div className="w-full flex-1 p-[2px] relative z-10">
            <Windows rows={10} cols={5} theme={theme} seed={seed} zoomLevel={zoomLevel} />
          </div>
        </div>
      )
    }
    
    return null;
  };

  if (isReviving) {
     return (
        <div className="relative flex flex-col justify-end z-10">
           {/* Final building revealing bottom to top */}
           <motion.div 
             initial={{ clipPath: 'inset(100% 0 0 0)' }}
             animate={{ clipPath: 'inset(0% 0 0 0)' }}
             transition={{ duration: 4.5, ease: 'linear' }}
             className="relative z-10"
           >
              {renderBuildingCore()}
           </motion.div>

           {/* Scaffolding Overlay */}
           <motion.div 
             initial={{ opacity: 1 }}
             animate={{ opacity: 0 }}
             transition={{ duration: 1, delay: 4, ease: 'easeOut' }}
             className="absolute inset-0 border border-blue-500/50 bg-black/80 flex flex-col justify-end overflow-hidden shadow-[0_0_20px_rgba(59,130,246,0.3)] z-20"
           >
              {/* Scaffolding pattern */}
              <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(96, 165, 250, .4) 25%, rgba(96, 165, 250, .4) 26%, transparent 27%, transparent 74%, rgba(96, 165, 250, .4) 75%, rgba(96, 165, 250, .4) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(96, 165, 250, .4) 25%, rgba(96, 165, 250, .4) 26%, transparent 27%, transparent 74%, rgba(96, 165, 250, .4) 75%, rgba(96, 165, 250, .4) 76%, transparent 77%, transparent)', backgroundSize: '8px 8px' }}></div>
              
              <div className="absolute inset-0 flex flex-col justify-between p-1">
                 {[...Array(5)].map((_, i) => <div key={i} className="w-full h-[1px] bg-blue-500/40"></div>)}
              </div>
              
              {zoomLevel >= 3 && (
                <>
                  {/* Repair Drones */}
                  <motion.div 
                    className="absolute w-1.5 h-1.5 bg-cyan-400 shadow-[0_0_10px_#22d3ee] rounded-full z-30" 
                    animate={{ top: ['10%', '40%', '20%', '80%'], left: ['10%', '80%', '40%', '60%'], opacity: [0, 1, 0, 1] }} 
                    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }} 
                  />
                  <motion.div 
                    className="absolute w-1 h-1 bg-cyan-300 shadow-[0_0_10px_#67e8f9] rounded-full z-30" 
                    animate={{ top: ['80%', '20%', '60%', '10%'], right: ['10%', '60%', '20%', '80%'], opacity: [1, 0, 1, 0] }} 
                    transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }} 
                  />
                  
                  {/* Welding sparks */}
                  <div className="absolute bottom-[20%] left-[20%] w-[2px] h-[3px] bg-white/70 z-20" />
                  <motion.div 
                    className="absolute bottom-[22%] left-[21%] w-1 h-1 bg-yellow-300 rounded-full z-40" 
                    animate={{ opacity: [0, 1, 0, 1, 0], scale: [0.5, 1.5, 0.5, 1, 0] }} 
                    transition={{ duration: 0.3, repeat: Infinity, repeatDelay: Math.random() * 0.5 }} 
                  />
                  
                  <div className="absolute top-[40%] right-[30%] w-[2px] h-[3px] bg-white/70 z-20" />
                  <motion.div 
                    className="absolute top-[42%] right-[31%] w-1 h-1 bg-yellow-300 rounded-full z-40" 
                    animate={{ opacity: [0, 1, 0, 1, 0], scale: [0.5, 1.5, 0.5, 1, 0] }} 
                    transition={{ duration: 0.4, repeat: Infinity, repeatDelay: Math.random() * 0.8 }} 
                  />
                </>
              )}
              
              <div className="absolute bottom-2 left-2 right-2 h-1 bg-gray-800 rounded overflow-hidden z-20">
                 <motion.div className="h-full bg-cyan-400" initial={{ width: 0 }} animate={{ width: '100%' }} transition={{ duration: 4.5, ease: 'linear' }} />
              </div>

              {zoomLevel >= 2 && <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[8px] text-cyan-400 font-mono uppercase tracking-widest bg-black/90 px-1 py-0.5 rounded border border-cyan-500/30 z-30 shadow-[0_0_10px_#22d3ee]">Rebuilding</div>}
           </motion.div>
        </div>
     );
  }

  return renderBuildingCore();
}

const Building = ({ project, onClick, onRoadClick, isReviving, zoomLevel, season, timeColors }: any) => {
  const [isHovered, setIsHovered] = useState(false);
  const theme = getDistrictTheme(project.district);
  const isGrave = project.stage === 0 || project.status === 'Abandoned';

  return (
    <motion.div 
      className="relative flex flex-col items-center justify-end cursor-pointer z-10 mx-auto group w-32 h-full"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ y: -8, scale: 1.02 }}
      onClick={() => onClick(project)}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
    >
       {/* Drone */}
       <AnimatePresence>
         {isHovered && !isGrave && !isReviving && zoomLevel >= 4 && (
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1, rotate: 360, transformOrigin: '30px 30px' }}
             exit={{ opacity: 0 }}
             className="absolute -top-4 -left-6 w-1 h-1 rounded-full bg-white shadow-[0_0_8px_white] z-30 pointer-events-none"
             transition={{ opacity: { duration: 0.2 }, rotate: { duration: 3, repeat: Infinity, ease: 'linear' } }}
           />
         )}
       </AnimatePresence>

       {/* Tooltip */}
       <div className={`absolute bottom-[calc(100%+3rem)] left-1/2 -translate-x-1/2 bg-black/90 border border-white/10 p-3.5 rounded-lg w-52 z-50 backdrop-blur-md shadow-2xl flex flex-col gap-1.5 pointer-events-none transition-all duration-200 ${isHovered && zoomLevel >= 3 ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-2 scale-95'}`}>
         <div className="text-sm font-bold text-white truncate">{project.name}</div>
         <div className={`text-[10px] font-mono uppercase tracking-widest ${theme.text}`}>{project.district}</div>
         <div className="flex justify-between items-center mt-2 border-t border-white/10 pt-2">
           <span className="text-[10px] text-gray-400 font-mono">STAGE {project.stage}</span>
           <span className={`text-[10px] font-medium ${isGrave ? 'text-red-400' : 'text-gray-300'}`}>{project.status}</span>
         </div>
       </div>

       <div className="relative w-full flex flex-col items-center justify-end flex-1 pointer-events-none">
          {renderBuildingBlocks(project, theme, isHovered, isReviving, zoomLevel, season, timeColors)}
          
          {/* Rooftop Maintenance Drones */}
          {project.stage >= 4 && !isReviving && zoomLevel >= 3 && (
            <motion.div 
              className="absolute top-0 w-full h-8 pointer-events-none z-30"
            >
              <motion.div 
                className="absolute w-[1.5px] h-[1.5px] bg-red-400 rounded-full"
                animate={{ x: [-10, 10, -10], y: [-2, 2, -2] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
              <motion.div 
                className="absolute w-1 h-1 bg-white/50 rounded-full blur-[1px]"
                animate={{ x: [-10, 10, -10], y: [-2, 2, -2], opacity: [0.2, 0.8, 0.2] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
            </motion.div>
          )}

          {/* Road Connections */}
          {zoomLevel >= 2 && (
            <>
              <div onClick={(e) => { e.stopPropagation(); onRoadClick(project.id); }} className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[300%] h-[12px] z-10 cursor-pointer group flex items-center justify-center pointer-events-auto">
                <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent group-hover:via-fuchsia-400/50 transition-colors"></div>
              </div>
              <div onClick={(e) => { e.stopPropagation(); onRoadClick(project.id); }} className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[12px] h-[60px] z-10 cursor-pointer group flex items-center justify-center pointer-events-auto">
                <div className="w-[1px] h-full bg-gradient-to-t from-transparent via-white/10 to-transparent group-hover:via-fuchsia-400/50 transition-colors"></div>
              </div>
            </>
          )}
          
       {/* Ground Glow & Heartbeat */}
       <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-[140%] h-3 blur-md rounded-[100%] z-[1] transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-60'} ${isGrave ? 'bg-black' : theme.window.replace('bg-', 'bg-').replace('-400', '-900').replace('-500', '-900')}`}></div>
       
       {/* Heartbeat Pulse */}
       <AnimatePresence>
         {isHovered && (
           <motion.div 
             initial={{ opacity: 0, scale: 0.8 }}
             animate={{ opacity: [0.1, 0.4, 0.1], scale: [0.9, 1.1, 0.9] }}
             exit={{ opacity: 0 }}
             transition={{ 
               duration: isReviving ? 0.3 : (isGrave ? 3 : Math.max(0.5, 2 - project.stage * 0.3)), 
               repeat: Infinity, 
               ease: "easeInOut" 
             }}
             className={`absolute inset-0 pointer-events-none rounded-xl blur-xl z-0 ${isReviving ? 'bg-green-500/30' : (isGrave ? 'bg-red-900/10' : theme.base.replace('bg-', 'bg-').replace('/80', '/30'))}`}
           />
         )}
       </AnimatePresence>
    </div>

    {/* Label underneath */}
       {zoomLevel >= 2 && (
         <div className={`h-10 mt-3 flex flex-col items-center justify-start z-20 transition-opacity w-full ${zoomLevel >= 3 ? 'opacity-70 group-hover:opacity-100' : 'opacity-40'}`}>
            <div className={`font-bold text-gray-200 tracking-widest font-mono shadow-black drop-shadow-md truncate w-full text-center px-1 ${zoomLevel >= 4 ? 'text-[11px]' : 'text-[9px]'}`}>
               {project.name.toUpperCase()}
            </div>
            {zoomLevel >= 3 && (
              <div className={`text-[9px] mt-0.5 ${theme.text} opacity-80 font-mono tracking-widest uppercase`}>
                 {isReviving ? 'Rebuilding' : isGrave ? 'Abandoned' : `Stage ${project.stage}`}
              </div>
            )}
         </div>
       )}
    </motion.div>
  )
}

const CityHeader = ({ projects, revivingCount, season, setSeason, zoomLevel, setZoomLevel, timeColors, viewMode, setViewMode }: any) => {
  const living = projects.filter((p: any) => p.stage > 0 && p.status !== 'Abandoned').length;
  const newToday = 8;

  const SeasonIcon = () => {
    switch(season) {
      case 'Winter': return <Snowflake size={16} className="text-blue-300" />;
      case 'Summer': return <Sun size={16} className="text-yellow-400" />;
      case 'Halloween': return <Ghost size={16} className="text-orange-400" />;
      case 'Christmas': return <TreePine size={16} className="text-green-500" />;
      default: return <CloudLightning size={16} className="text-cyan-400" />;
    }
  };

  return (
    <div className="shrink-0 bg-[#05070b]/95 border-b border-white/10 py-4 relative overflow-hidden z-30 backdrop-blur-xl">
      <div className="absolute inset-0 opacity-30 bg-[linear-gradient(90deg,transparent,rgba(34,211,238,0.08),transparent)] pointer-events-none"></div>
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 relative z-10 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-5">
        <div>
          <h1 className="text-2xl md:text-3xl text-white font-semibold tracking-tight mb-2 flex items-center gap-4">
             <div className="w-2.5 h-2.5 bg-cyan-300 rounded-full shadow-[0_0_12px_rgba(103,232,249,0.75)]"></div>
             REBOOT CITY
          </h1>
          <div className="text-gray-500 text-[10px] md:text-xs font-mono uppercase tracking-[0.18em] flex flex-wrap items-center gap-3">
            <span>Idea Operating System</span>
            
            <div className="flex items-center gap-2 bg-white/5 px-2 py-1 rounded">
              <span className="opacity-50">LOCAL TIME:</span>
              <span className="text-white">{timeColors?.text || 'Day'}</span>
            </div>

            <div className="flex items-center gap-2 bg-white/5 px-2 py-1 rounded">
              <span className="opacity-50">SEASON:</span>
              <div className="flex gap-1">
                 {SEASONS.map(s => (
                   <button 
                     key={s} 
                     onClick={() => setSeason(s)} 
                     className={`px-2 py-0.5 rounded transition-colors ${season === s ? 'bg-white/20 text-white' : 'hover:bg-white/10'}`}
                   >
                     {s}
                   </button>
                 ))}
              </div>
            </div>
            
            <div className="flex items-center gap-2 bg-white/5 px-2 py-1 rounded ml-auto lg:ml-4">
               <span className="opacity-50 hidden md:inline">ZOOM:</span>
               <button onClick={() => setZoomLevel(Math.max(1, zoomLevel - 1))} className="p-1 hover:bg-white/10 rounded" disabled={zoomLevel <= 1}><ZoomOut size={14} className={zoomLevel <= 1 ? 'opacity-30' : ''}/></button>
               <span className="w-4 text-center">{zoomLevel}</span>
               <button onClick={() => setZoomLevel(Math.min(4, zoomLevel + 1))} className="p-1 hover:bg-white/10 rounded" disabled={zoomLevel >= 4}><ZoomIn size={14} className={zoomLevel >= 4 ? 'opacity-30' : ''} /></button>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-x-6 gap-y-4 text-sm bg-[#0b1018]/80 border border-white/10 p-3 rounded-lg backdrop-blur-xl w-full xl:w-auto">
           <div className="flex items-center gap-1 rounded-md border border-white/10 bg-black/25 p-1">
             {[
               { id: 'city', label: 'City', icon: LayoutGrid },
               { id: 'network', label: 'Network', icon: Network },
               { id: 'graveyard', label: 'Graveyard', icon: Ghost },
               { id: 'echo', label: 'Echo', icon: Brain },
               { id: 'settings', label: 'Settings', icon: Settings },
             ].map(({ id, label, icon: Icon }) => (
               <button
                 key={id}
                 onClick={() => setViewMode(id)}
                 title={`${label} Mode`}
                 className={`flex h-9 min-w-9 items-center justify-center gap-2 rounded px-3 text-[10px] font-mono uppercase tracking-widest transition-colors ${
                   viewMode === id ? 'bg-cyan-300 text-black shadow-[0_0_16px_rgba(103,232,249,0.22)]' : 'text-gray-400 hover:bg-white/10 hover:text-white'
                 }`}
               >
                 <Icon size={15} />
                 <span className="hidden xl:inline">{label}</span>
               </button>
             ))}
           </div>
           <div className="w-px h-10 bg-white/10 hidden md:block"></div>
           <div className="flex flex-col">
             <span className="text-gray-500 font-mono uppercase tracking-widest text-[9px] mb-1">Population</span>
             <span className="text-white font-semibold text-base md:text-lg">{living} <span className="text-xs md:text-sm font-normal text-gray-400">Living Projects</span></span>
           </div>
           <div className="w-px h-10 bg-white/10 hidden sm:block"></div>
           <div className="flex flex-col">
             <span className="text-gray-500 font-mono uppercase tracking-widest text-[9px] mb-1">In Recovery</span>
             <span className="text-yellow-400 font-semibold text-base md:text-lg">{revivingCount} <span className="text-xs md:text-sm font-normal text-yellow-400/50">Being Revived</span></span>
           </div>
           <div className="w-px h-10 bg-white/10 hidden sm:block"></div>
           <div className="flex flex-col">
             <span className="text-gray-500 font-mono uppercase tracking-widest text-[9px] mb-1">Inception</span>
             <span className="text-green-400 font-semibold text-base md:text-lg">{newToday} <span className="text-xs md:text-sm font-normal text-green-400/50">New Today</span></span>
           </div>
           <div className="w-px h-10 bg-white/10 hidden md:block"></div>
           <div className="flex flex-col">
             <span className="text-gray-500 font-mono uppercase tracking-widest text-[9px] mb-1">Atmosphere</span>
             <span className="text-cyan-400 font-semibold text-base md:text-lg flex items-center gap-2">
                <SeasonIcon />
                {season}
             </span>
           </div>
        </div>
      </div>
    </div>
  )
}

const CityAtmosphere = ({ season, timeColors }: any) => {
  return (
    <div className={`absolute inset-0 pointer-events-none overflow-hidden z-0 ${timeColors?.sky || ''}`}>
       <div className={`absolute inset-0 ${timeColors?.fog || ''} mix-blend-screen opacity-50 z-10 pointer-events-none transition-colors duration-1000`}></div>
       <div className="absolute inset-0 z-20 mix-blend-color pointer-events-none transition-colors duration-1000" style={{ backgroundColor: timeColors?.ambientLight || 'transparent' }}></div>
       {/* Holographic Billboards */}
       <div className="absolute top-[20%] left-[5%] w-64 h-32 border border-cyan-500/20 bg-cyan-900/10 rounded overflow-hidden transform rotate-12 perspective-1000 hidden xl:block opacity-40 mix-blend-screen">
          <div className="absolute inset-0 bg-[linear-gradient(0deg,transparent_24%,rgba(34,211,238,0.2)_25%,rgba(34,211,238,0.2)_26%,transparent_27%)] bg-[length:4px_4px]" />
          <motion.div animate={{ opacity: [0.3, 0.8, 0.1, 0.9, 0.3] }} transition={{ duration: 4, repeat: Infinity, ease: 'linear' }} className="w-full h-full flex items-center justify-center font-mono text-cyan-400 text-2xl font-bold tracking-widest text-center">
             NEXUS<br/>CORP
          </motion.div>
       </div>
       <div className="absolute top-[35%] right-[5%] w-48 h-64 border border-fuchsia-500/20 bg-fuchsia-900/10 rounded overflow-hidden transform -rotate-6 perspective-1000 hidden xl:block opacity-40 mix-blend-screen">
          <div className="absolute inset-0 bg-[linear-gradient(0deg,transparent_24%,rgba(232,121,249,0.2)_25%,rgba(232,121,249,0.2)_26%,transparent_27%)] bg-[length:4px_4px]" />
          <motion.div animate={{ opacity: [0.2, 0.6, 0.05, 0.7, 0.2] }} transition={{ duration: 6, repeat: Infinity, ease: 'linear', delay: 1 }} className="w-full h-full flex flex-col items-center justify-center font-mono text-fuchsia-400 font-bold tracking-widest text-center">
             <div className="text-4xl mb-4">▲</div>
             <div>AURA<br/>TECH</div>
          </motion.div>
       </div>

       {/* Soft Fog Movement */}
       <motion.div 
         className="absolute w-[200vw] h-[100vh] bg-gradient-to-t from-transparent via-cyan-900/5 to-transparent blur-[80px] z-[1] pointer-events-none"
         animate={{ x: ['-20%', '5%', '-20%'], y: ['10%', '0%', '10%'] }}
         transition={{ duration: 60, repeat: Infinity, ease: 'easeInOut' }}
         style={{ bottom: '0', left: '-50%' }}
       />

       {/* Flying City Drones */}
       {Array.from({length: 8}).map((_, i) => (
         <motion.div
           key={`city-drone-${i}`}
           className="absolute w-1 h-1 bg-cyan-300 rounded-full shadow-[0_0_8px_#22d3ee] z-10"
           initial={{ 
             x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
             y: Math.random() * 400 + 100,
             opacity: 0
           }}
           animate={{
             x: `+=${Math.random() > 0.5 ? 400 : -400}`,
             y: `+=${Math.random() * 100 - 50}`,
             opacity: [0, 0.8, 0]
           }}
           transition={{ duration: 15 + Math.random() * 20, repeat: Infinity, ease: 'linear', delay: Math.random() * 10 }}
         />
       ))}

       {/* Floating Ambient Particles */}
       {Array.from({length: 15}).map((_, i) => (
         <motion.div
           key={`particle-${i}`}
           className="absolute w-0.5 h-0.5 bg-white/30 rounded-full z-10"
           initial={{ 
             x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
             y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800)
           }}
           animate={{
             y: `-=${50 + Math.random() * 50}`,
             opacity: [0, 0.5, 0]
           }}
           transition={{ duration: 10 + Math.random() * 10, repeat: Infinity, ease: 'linear', delay: Math.random() * 5 }}
         />
       ))}

       <motion.div 
         className="absolute w-[150vw] h-[80vh] bg-cyan-900/10 blur-[120px] rounded-[100%]"
         animate={{ x: ['-20%', '20%', '-20%'], y: [0, 30, 0] }}
         transition={{ duration: 40, repeat: Infinity, ease: 'easeInOut' }}
         style={{ top: '10%', left: '-25%' }}
       />
       <motion.div 
         className={`absolute w-[120vw] h-[60vh] blur-[100px] rounded-[100%] ${season === 'Halloween' ? 'bg-orange-900/20' : season === 'Christmas' ? 'bg-red-900/10' : 'bg-purple-900/10'}`}
         animate={{ x: ['20%', '-20%', '20%'], y: [30, -20, 30] }}
         transition={{ duration: 50, repeat: Infinity, ease: 'easeInOut' }}
         style={{ top: '30%', right: '-10%' }}
       />
       
       {season === 'Winter' && Array.from({length: 40}).map((_, i) => (
         <motion.div
           key={`snow-${i}`}
           className="absolute w-1 h-1 bg-white/80 rounded-full"
           initial={{ 
             x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
             y: -20
           }}
           animate={{
             y: typeof window !== 'undefined' ? window.innerHeight : 800,
             x: `+=${Math.random() > 0.5 ? 50 : -50}`
           }}
           transition={{ duration: 10 + Math.random() * 15, repeat: Infinity, ease: 'linear' }}
         />
       ))}

       {season !== 'Winter' && Array.from({length: 12}).map((_, i) => (
         <motion.div
           key={i}
           className="absolute w-1 h-1 bg-white/60 rounded-full shadow-[0_0_5px_white]"
           initial={{ 
             x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
             y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800) 
           }}
           animate={{
             x: [null, Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000) + (Math.random() > 0.5 ? 200 : -200)],
             y: [null, Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800) + (Math.random() > 0.5 ? 100 : -100)]
           }}
           transition={{ duration: 25 + Math.random() * 20, repeat: Infinity, ease: 'linear' }}
         />
       ))}
    </div>
  )
}

const DroneController = ({ zoomLevel }: { zoomLevel: number }) => {
  const [drones, setDrones] = useState<{id: number, startX: number, startY: number, endX: number, endY: number, duration: number}[]>([]);

  useEffect(() => {
    if (zoomLevel < 2) {
      setDrones([]);
      return;
    }

    const spawnDrone = () => {
      const startX = Math.random() * 100;
      const startY = Math.random() * 100;
      const directionX = Math.random() > 0.5 ? 1 : -1;
      const endX = startX + directionX * (20 + Math.random() * 30);
      const endY = startY + (Math.random() - 0.5) * 20;
      
      const newDrone = {
        id: Date.now() + Math.random(),
        startX,
        startY,
        endX,
        endY,
        duration: 10 + Math.random() * 10
      };

      setDrones(prev => [...prev.slice(-15), newDrone]);
    };

    const interval = setInterval(spawnDrone, 2000);
    return () => clearInterval(interval);
  }, [zoomLevel]);

  if (zoomLevel < 2) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-[45] overflow-hidden">
      <AnimatePresence>
        {drones.map(drone => {
          const angle = Math.atan2(drone.endY - drone.startY, drone.endX - drone.startX) * (180 / Math.PI);
          return (
            <motion.div
              key={drone.id}
              initial={{ opacity: 0, left: `${drone.startX}%`, top: `${drone.startY}%` }}
              animate={{ 
                opacity: [0, 1, 1, 0], 
                left: `${drone.endX}%`, 
                top: `${drone.endY}%` 
              }}
              transition={{ duration: drone.duration, ease: 'linear' }}
              onAnimationComplete={() => {
                setDrones(prev => prev.filter(d => d.id !== drone.id));
              }}
              className="absolute w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_10px_#22d3ee]"
            >
              <div 
                className="absolute top-1/2 right-1/2 h-[1px] w-16 bg-gradient-to-r from-transparent to-cyan-400/80 origin-right" 
                style={{ 
                  transform: `translateY(-50%) rotate(${angle}deg)` 
                }}
              />
            </motion.div>
          )
        })}
      </AnimatePresence>
    </div>
  );
};

const Sidebar = ({ activeDistrict, setActiveDistrict, onSearch, onNewProject }: any) => {
  return (
    <div className="hidden md:flex w-64 border-r border-white/5 bg-[#08080a]/90 backdrop-blur-2xl p-5 flex-col gap-2 overflow-y-auto shrink-0 z-40 relative">
      <button 
        onClick={onNewProject}
        className="mb-4 w-full bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 font-semibold py-2 rounded-lg transition-all shadow-[0_0_10px_rgba(34,211,238,0.1)] hover:shadow-[0_0_20px_rgba(34,211,238,0.3)] flex items-center justify-center gap-2"
      >
        <span className="text-xl leading-none -mt-1">+</span>
        <span>Initialize Project</span>
      </button>
      <div className="mb-6 relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        <input 
          type="text" 
          placeholder="Search city..." 
          onChange={(e) => onSearch(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-9 pr-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 transition-colors"
        />
      </div>

      <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-2 px-2">Districts</div>
      
      <button 
        onClick={() => setActiveDistrict('All')}
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${activeDistrict === 'All' ? 'bg-white/10 text-white shadow-inner' : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'}`}
      >
        <LayoutGrid size={16} />
        <span className="text-sm font-medium">All Projects</span>
      </button>
      
      <div className="h-px bg-white/5 my-2 mx-2"></div>

      {DISTRICTS.map(d => {
        const Icon = d.icon;
        const isActive = activeDistrict === d.name;
        return (
          <button 
            key={d.name}
            onClick={() => setActiveDistrict(d.name)}
            className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 ${isActive ? 'bg-white/10 text-white shadow-inner' : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'}`}
          >
            <Icon size={16} className={isActive ? d.color : 'opacity-60 group-hover:opacity-100'} />
            <span className="text-sm font-medium tracking-wide">{d.name}</span>
          </button>
        )
      })}
    </div>
  )
}

const HolographicDataCore = ({ project, isGraveyard, isHoveringRevive, expandedNode, setExpandedNode }: any) => {
  const color = isHoveringRevive ? 'rgba(34, 197, 94, 0.4)' : isGraveyard ? 'rgba(239, 68, 68, 0.2)' : 'rgba(34, 211, 238, 0.2)';
  const solidColor = isHoveringRevive ? '#22c55e' : isGraveyard ? '#ef4444' : '#22d3ee';
  
  const nodes = [
    { id: 'health', x: 50, y: 15, color: '#22c55e', label: 'Health', text: isGraveyard ? 'Status: CRITICAL. System offline.' : 'Status: NOMINAL. All systems optimal.' },
    { id: 'attention', x: 15, y: 50, color: '#eab308', label: 'Attention', text: 'Minor memory leaks detected in sub-routines.' },
    { id: 'failure', x: 85, y: 50, color: '#ef4444', label: 'Failure Point', text: isGraveyard ? 'Core failure at Node 7.' : 'No critical failures detected.' },
    { id: 'community', x: 30, y: 85, color: '#3b82f6', label: 'Community', text: 'Active users: 12,042. Sentiment: Positive.' },
    { id: 'ai', x: 70, y: 85, color: '#a855f7', label: 'AI Suggestion', text: 'Optimize asset loading for 14% performance gain.' },
  ];

  return (
    <div className="relative w-full h-64 flex flex-col justify-center items-center mb-6 overflow-hidden perspective-1000">
      {/* Background Neural Particles */}
      {Array.from({length: 12}).map((_, i) => (
        <motion.div
           key={`p-${i}`}
           className="absolute w-1 h-1 bg-white/50 rounded-full"
           animate={{
             x: [0, (Math.random() - 0.5) * 100],
             y: [0, (Math.random() - 0.5) * 100],
             opacity: [0, 0.8, 0]
           }}
           transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}

      <motion.div 
        animate={{ rotateY: [0, 360] }}
        transition={{ rotateY: { duration: 20, repeat: Infinity, ease: 'linear' } }}
        className="relative w-48 h-48"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full overflow-visible">
           {/* Pathways */}
           <circle cx="50" cy="50" r="40" fill="none" stroke={color} strokeWidth="0.5" strokeDasharray="2 2" className="opacity-50" />
           <path d="M 50 15 Q 50 50 15 50" fill="none" stroke={color} strokeWidth="0.5" className="opacity-40" />
           <path d="M 50 15 Q 50 50 85 50" fill="none" stroke={color} strokeWidth="0.5" className="opacity-40" />
           <path d="M 15 50 Q 50 50 30 85" fill="none" stroke={color} strokeWidth="0.5" className="opacity-40" />
           <path d="M 85 50 Q 50 50 70 85" fill="none" stroke={color} strokeWidth="0.5" className="opacity-40" />
           <path d="M 30 85 Q 50 50 70 85" fill="none" stroke={color} strokeWidth="0.5" className="opacity-40" />
           
           {/* Nodes */}
           {nodes.map(n => (
             <g key={n.id} onClick={() => setExpandedNode(expandedNode === n.id ? null : n.id)} className="cursor-pointer">
               <motion.circle 
                 cx={n.x} cy={n.y} r="4" 
                 fill={n.color} 
                 style={{ filter: `drop-shadow(0 0 8px ${n.color})` }}
                 whileHover={{ r: 6 }}
                 animate={{ opacity: [0.6, 1, 0.6] }}
                 transition={{ duration: 2, repeat: Infinity, delay: Math.random() }}
               />
               <circle cx={n.x} cy={n.y} r="8" fill="transparent" />
             </g>
           ))}

           {/* Central Core */}
           <motion.circle 
             cx="50" cy="50" r="8" 
             fill={solidColor} 
             style={{ filter: `drop-shadow(0 0 15px ${solidColor})` }} 
             animate={{ scale: [0.9, 1.1, 0.9], opacity: [0.7, 1, 0.7] }}
             transition={{ duration: isHoveringRevive ? 0.5 : 3, repeat: Infinity, ease: 'easeInOut' }}
           />
        </svg>
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#08080a] via-transparent to-[#08080a] z-10 pointer-events-none" />
      <div className="absolute bottom-0 text-center z-20 font-mono text-[10px] text-cyan-500/50 tracking-widest uppercase pointer-events-none">
         ECHO HOLOGRAPHIC NEURAL CORE
      </div>
    </div>
  )
}

const DiagnosticsTerminal = ({ project }: { project: any }) => {
  const diagnosticsList = [
    { code: '0x404_BURNOUT', label: 'Founder Burnout', recovery: 'RECOMMENDATION // Distribute workload to community nodes. Implement 4-day sprint cycles.' },
    { code: '0x101_FUNDS_DRY', label: 'Funding Exhausted', recovery: 'RECOMMENDATION // Pivot to open-source model. Seek micro-grants from Network DAOs.' },
    { code: '0x202_GHOST_TOWN', label: 'Low Community Interest', recovery: 'RECOMMENDATION // Re-align feature set with current sector demands. Initiate viral loop protocol.' },
    { code: '0x505_TECH_DEBT', label: 'Technical Debt', recovery: 'RECOMMENDATION // Refactor core architecture. Deprecate legacy dependencies.' },
    { code: '0x303_NO_SHIP', label: 'Prototype Never Released', recovery: 'RECOMMENDATION // Lower scope threshold by 40%. Deploy v1 to testing servers immediately.' },
    { code: '0x606_NO_FIT', label: 'Poor Product Market Fit', recovery: 'RECOMMENDATION // Analyze competing grid nodes. Run user simulation algorithms.' }
  ];

  // Pick a stable pseudo-random diagnostic based on project ID
  const diag = diagnosticsList[project.id % diagnosticsList.length];

  return (
    <div className="bg-[#0a0a0c] border border-red-500/30 rounded-lg p-4 font-mono text-xs text-red-400 relative overflow-hidden group mb-8">
       <motion.div 
         className="absolute top-0 left-0 w-full h-full bg-red-500/5 z-0 pointer-events-none"
         animate={{ opacity: [0, 0.5, 0, 0.2, 0] }}
         transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
       />
       <div className="absolute top-0 left-0 w-full h-[1px] bg-red-500/50 shadow-[0_0_10px_#ef4444]" />
       
       <div className="flex items-center gap-2 mb-3 pb-2 border-b border-red-500/20 relative z-10">
          <Activity size={14} className="animate-pulse" />
          <span className="tracking-widest uppercase font-bold text-red-500">SYSTEM FAILURE LOG</span>
       </div>
       
       <div className="space-y-2 relative z-10 opacity-80 group-hover:opacity-100 transition-opacity">
         <div className="flex justify-between items-center">
            <span>ERR_CODE:</span>
            <span className="bg-red-950 px-2 py-0.5 rounded border border-red-900/50">{diag.code}</span>
         </div>
         <div className="flex justify-between items-center">
            <span>DIAGNOSIS:</span>
            <span className="text-red-300 font-bold">{diag.label}</span>
         </div>
         <div className="flex justify-between items-center">
            <span>STATUS:</span>
            <span className="animate-pulse text-white bg-red-600 px-1">CRITICAL</span>
         </div>
         <div className="mt-3 pt-3 border-t border-red-500/10">
           <span className="block text-[10px] text-red-500/50 mb-1">USER_LOG //</span>
           <span className="text-gray-400 leading-relaxed font-sans text-sm">{project.reason}</span>
         </div>
         <div className="mt-3 pt-3 border-t border-red-500/10">
           <span className="block text-[10px] text-cyan-500/70 mb-1">AI_ANALYSIS //</span>
           <span className="text-cyan-300 font-mono text-xs leading-relaxed">{diag.recovery}</span>
         </div>
       </div>
    </div>
  )
}

const ProjectCubeOverlay = ({ project, onClose, onRevive, onUpgrade, onAccess }: any) => {
  const [activeFace, setActiveFace] = useState('front');
  const [isHoveringRevive, setIsHoveringRevive] = useState(false);
  const [expandedNode, setExpandedNode] = useState<string | null>(null);
  if (!project) return null;
  
  const isGraveyard = project.stage === 0;

  const faceTransforms: Record<string, string> = {
    front: 'rotateY(0deg) translateZ(150px)',
    right: 'rotateY(90deg) translateZ(150px)',
    back: 'rotateY(180deg) translateZ(150px)',
    left: 'rotateY(-90deg) translateZ(150px)',
    top: 'rotateX(90deg) translateZ(150px)',
    bottom: 'rotateX(-90deg) translateZ(150px)'
  };

  const inverseTransforms: Record<string, string> = {
    front: 'rotateY(0deg)',
    right: 'rotateY(-90deg)',
    back: 'rotateY(-180deg)',
    left: 'rotateY(90deg)',
    top: 'rotateX(-90deg)',
    bottom: 'rotateX(90deg)'
  };

  const navItems = [
    { id: 'front', label: 'Overview' },
    { id: 'right', label: 'Timeline' },
    { id: 'back', label: 'Founder' },
    { id: 'left', label: 'Diagnostics' },
    { id: 'top', label: 'Revive' },
    { id: 'bottom', label: 'Community' },
  ];

  const renderFaceContent = (id: string) => {
    switch(id) {
      case 'front':
        return (
          <div className="flex flex-col h-full justify-center text-center px-6">
            <h2 className={`text-4xl font-bold mb-4 tracking-tight ${isGraveyard ? 'text-red-400 drop-shadow-[0_0_15px_rgba(255,0,0,0.4)]' : 'text-cyan-400 drop-shadow-[0_0_15px_rgba(34,211,238,0.4)]'}`}>
              {project.name}
            </h2>
            <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest bg-white/5 px-3 py-1.5 rounded-full border border-white/10 mx-auto mb-6">
              {project.district}
            </div>
            <p className="text-gray-300 font-light leading-relaxed text-sm">
              {project.description}
            </p>
          </div>
        );
      case 'left':
        return (
          <div className="flex flex-col h-full justify-center">
             {isGraveyard && project.reason ? (
               <DiagnosticsTerminal project={project} />
             ) : (
               <div className="text-center text-cyan-400">
                  <Activity size={32} className="mx-auto mb-4 opacity-50" />
                  <div className="font-mono text-sm uppercase tracking-widest mb-2">Systems Nominal</div>
                  <div className="text-xs text-cyan-500/70">No critical failures detected</div>
               </div>
             )}
          </div>
        );
      case 'right':
        return (
          <div className="flex flex-col h-full justify-center">
             <div className="space-y-6">
                <div className="flex items-center gap-4 text-sm text-gray-300">
                  <div className="w-10 h-10 rounded-full bg-cyan-900/30 flex items-center justify-center border border-cyan-500/30">
                    <Clock size={18} className="text-cyan-400" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-mono text-cyan-500/50">Timeline</div>
                    <div className="font-light">{project.timeline}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-300">
                  <div className="w-10 h-10 rounded-full bg-cyan-900/30 flex items-center justify-center border border-cyan-500/30">
                    <Activity size={18} className="text-cyan-400" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-mono text-cyan-500/50">Lifecycle</div>
                    <div className="font-medium bg-white/5 px-2 py-0.5 rounded inline-block mt-1">{project.status}</div>
                  </div>
                </div>
             </div>
          </div>
        );
      case 'back':
        return (
           <div className="flex flex-col h-full justify-center items-center text-center">
              <div className="h-20 w-20 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 border border-gray-500 flex items-center justify-center text-3xl font-bold shadow-inner text-white mb-6">
                {project.founder.charAt(0)}
              </div>
              <div className="text-[10px] text-gray-400 uppercase tracking-widest font-mono mb-2">Original Architect</div>
              <div className="text-2xl text-white font-medium mb-4">{project.founder}</div>
              <p className="text-gray-400 text-sm italic">"Building the future, one node at a time."</p>
           </div>
        );
      case 'top':
        return (
           <div className="flex flex-col h-full justify-center items-center">
              {isGraveyard ? (
                <>
                  <div className="text-red-400 mb-6 text-center">
                    <Zap size={48} className="mx-auto mb-4 opacity-50" />
                    <div className="font-mono text-sm uppercase tracking-widest mb-2">System Offline</div>
                    <div className="text-xs text-red-500/70">Awaiting revival sequence</div>
                  </div>
                  <button 
                    onClick={() => { onRevive(project.id); onClose(); }} 
                    onMouseEnter={() => setIsHoveringRevive(true)}
                    onMouseLeave={() => setIsHoveringRevive(false)}
                    className="w-full py-4 rounded-xl bg-red-500/10 border border-red-500/50 text-red-400 font-semibold hover:bg-green-500/20 hover:border-green-500/50 hover:text-green-400 hover:shadow-[0_0_30px_rgba(34,197,94,0.4)] transition-all duration-300 flex items-center justify-center gap-2 group"
                  >
                    <Zap size={18} className="group-hover:scale-110 transition-transform" />
                    Initiate Revival Protocol
                  </button>
                </>
              ) : project.stage < 4 ? (
                <>
                  <div className="text-cyan-400 mb-6 text-center">
                    <Activity size={48} className="mx-auto mb-4 opacity-50" />
                    <div className="font-mono text-sm uppercase tracking-widest mb-2">Construction Phase: Stage {project.stage}</div>
                    <div className="text-xs text-cyan-500/70">Ready for next expansion</div>
                  </div>
                  <button 
                    onClick={() => { onUpgrade(project.id); onClose(); }} 
                    className="w-full py-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-semibold hover:bg-cyan-500/20 hover:border-cyan-500/50 hover:shadow-[0_0_20px_rgba(0,240,255,0.2)] transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <Zap size={18} />
                    Construct Next Phase
                  </button>
                </>
              ) : (
                <>
                  <div className="text-cyan-400 mb-6 text-center">
                    <Activity size={48} className="mx-auto mb-4 opacity-50" />
                    <div className="font-mono text-sm uppercase tracking-widest mb-2">System Online</div>
                    <div className="text-xs text-cyan-500/70">Maximum scale achieved</div>
                  </div>
                  <button onClick={() => onAccess(project.id)} className="w-full py-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-semibold hover:bg-cyan-500/20 hover:border-cyan-500/50 hover:shadow-[0_0_20px_rgba(0,240,255,0.2)] transition-all duration-300 flex items-center justify-center gap-2">
                    <ArrowUpRight size={18} />
                    Access Project
                  </button>
                </>
              )}
           </div>
        );
      case 'bottom':
        return (
          <div className="flex flex-col h-full justify-center items-center text-center">
             <Users size={48} className="text-blue-400 mb-6 opacity-50" />
             <div className="text-2xl font-bold text-white mb-2">12,042</div>
             <div className="text-[10px] text-blue-400 uppercase tracking-widest font-mono mb-4">Active Citizens</div>
             <div className="bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs px-4 py-2 rounded-lg">
                Sentiment: POSITIVE
             </div>
          </div>
        );
      default:
        return null;
    }
  };

  const renderFace = (id: string, transform: string) => (
    <div 
      className={`absolute inset-0 w-full h-full bg-[#08080a]/90 backdrop-blur-3xl border flex flex-col ${activeFace === id ? (isGraveyard ? 'border-red-500/50 shadow-[0_0_50px_rgba(239,68,68,0.1)]' : 'border-cyan-400 shadow-[0_0_50px_rgba(34,211,238,0.2)]') : 'border-white/10 opacity-40 cursor-pointer hover:border-white/30'} transition-all duration-700 overflow-hidden group`}
      style={{ transform, backfaceVisibility: 'hidden' }}
      onClick={() => { if(activeFace !== id) setActiveFace(id); }}
    >
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
      {activeFace !== id && <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />}
      
      <div className={`p-3 border-b ${isGraveyard ? 'border-red-500/20 bg-red-900/10' : 'border-cyan-500/20 bg-cyan-900/10'} flex justify-between items-center z-10 relative`}>
         <span className={`font-mono text-[10px] tracking-[0.2em] uppercase ${isGraveyard ? 'text-red-400' : 'text-cyan-400'}`}>{id} // {navItems.find(n => n.id === id)?.label || 'System'}</span>
         {activeFace === id && <div className={`w-1.5 h-1.5 rounded-full shadow-[0_0_10px_currentColor] animate-pulse ${isGraveyard ? 'bg-red-400 text-red-400' : 'bg-cyan-400 text-cyan-400'}`} />}
      </div>
      
      <div className="p-8 flex-1 flex flex-col overflow-y-auto relative z-10 custom-scrollbar pointer-events-auto">
         {renderFaceContent(id)}
      </div>
    </div>
  );

  const nodes = [
    { id: 'health', x: 50, y: 15, color: '#22c55e', label: 'Health', text: isGraveyard ? 'Status: CRITICAL. System offline.' : 'Status: NOMINAL. All systems optimal.' },
    { id: 'attention', x: 15, y: 50, color: '#eab308', label: 'Attention', text: 'Minor memory leaks detected in sub-routines.' },
    { id: 'failure', x: 85, y: 50, color: '#ef4444', label: 'Failure Point', text: isGraveyard ? (project.reason || 'Core failure at Node 7.') : 'No critical failures detected.' },
    { id: 'community', x: 30, y: 85, color: '#3b82f6', label: 'Community', text: 'Active users: 12,042. Sentiment: Positive.' },
    { id: 'ai', x: 70, y: 85, color: '#a855f7', label: 'AI Suggestion', text: 'Optimize asset loading for 14% performance gain.' },
  ];
  const activeNodeData = nodes.find(n => n.id === expandedNode);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-xl"
    >
      <button onClick={onClose} className="absolute top-8 right-8 p-3 bg-white/5 border border-white/10 rounded-full text-white hover:bg-white/20 hover:scale-110 transition-all z-[110]">
        <X size={24} />
      </button>

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(34,211,238,0.05),transparent_70%)] pointer-events-none" />

      {/* The Holographic Brain (Echo) */}
      <div className="absolute left-8 md:left-24 top-1/2 -translate-y-1/2 w-64 md:w-80 flex flex-col z-[110]">
        <HolographicDataCore 
          project={project} 
          isGraveyard={isGraveyard} 
          isHoveringRevive={isHoveringRevive} 
          expandedNode={expandedNode}
          setExpandedNode={setExpandedNode}
        />
        <AnimatePresence>
         {activeNodeData && (
           <motion.div 
             initial={{ opacity: 0, height: 0, y: -10 }}
             animate={{ opacity: 1, height: 'auto', y: 0 }}
             exit={{ opacity: 0, height: 0, y: -10 }}
             className="mt-4 overflow-hidden"
           >
             <div className="bg-[#111115]/90 backdrop-blur-md border border-white/10 p-4 rounded-xl font-mono text-xs flex flex-col gap-2 shadow-2xl" style={{ borderLeftColor: activeNodeData.color, borderLeftWidth: 2 }}>
                <div className="flex items-center gap-2 mb-1">
                   <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: activeNodeData.color }} />
                   <span className="uppercase tracking-widest text-white/80 font-bold" style={{ color: activeNodeData.color }}>{activeNodeData.label} Node</span>
                </div>
                <div className="text-gray-300 font-sans leading-relaxed text-sm">
                   {activeNodeData.text}
                </div>
             </div>
           </motion.div>
         )}
        </AnimatePresence>
      </div>

      {/* The Interactive Data Cube */}
      <div className="w-[300px] h-[300px] md:w-[300px] md:h-[300px] perspective-[1200px] relative z-50 ml-0 md:ml-64 mt-12 md:mt-0">
        <motion.div 
          className="w-full h-full relative"
          style={{ transformStyle: 'preserve-3d' }}
          animate={{ 
            transform: `translateZ(-150px) ${inverseTransforms[activeFace]}`,
            y: [-10, 10, -10]
          }}
          transition={{ 
            transform: { duration: 1.2, type: 'spring', stiffness: 40, damping: 20 },
            y: { duration: 6, repeat: Infinity, ease: 'easeInOut' }
          }}
        >
          {renderFace('front', faceTransforms.front)}
          {renderFace('right', faceTransforms.right)}
          {renderFace('back', faceTransforms.back)}
          {renderFace('left', faceTransforms.left)}
          {renderFace('top', faceTransforms.top)}
          {renderFace('bottom', faceTransforms.bottom)}
        </motion.div>
      </div>

      {/* Navigation Controls */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex gap-2 md:gap-4 bg-[#08080a]/80 backdrop-blur-md p-2 rounded-full border border-white/10 z-[110] shadow-2xl">
         {navItems.map(item => (
           <button 
             key={item.id}
             onClick={() => setActiveFace(item.id)}
             className={`px-4 py-2 rounded-full text-xs font-mono uppercase tracking-widest transition-all ${activeFace === item.id ? (isGraveyard ? 'bg-red-500/20 text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.3)]' : 'bg-cyan-500/20 text-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.3)]') : 'text-gray-500 hover:text-white hover:bg-white/5'}`}
           >
             {item.label}
           </button>
         ))}
      </div>
    </motion.div>
  )
}

const EchoAI = ({ isBooting, activeDistrict, selectedProject, revivingIds }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{sender: 'ai' | 'user', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [tutorialStep, setTutorialStep] = useState(0);

  useEffect(() => {
    if (!isBooting && tutorialStep === 0) {
      setTimeout(() => {
        setIsOpen(true);
        setMessages([{ sender: 'ai', text: 'SIGNAL DETECTED. I am Echo, your Holographic Neural Core. Welcome to Reboot.' }]);
        setTimeout(() => {
          setMessages(prev => [...prev, { sender: 'ai', text: 'TUTORIAL: This city represents all your projects. Active ones are in the Success District. Dead ones are in the Graveyard.' }]);
        }, 1500);
        setTimeout(() => {
          setMessages(prev => [...prev, { sender: 'ai', text: 'TUTORIAL: Try clicking on a building in the Graveyard (the lower section) to analyze it.' }]);
          setTutorialStep(1);
        }, 3000);
      }, 1000);
    }
  }, [isBooting, tutorialStep]);

  useEffect(() => {
    if (tutorialStep === 1 && selectedProject && selectedProject.stage === 0) {
      setMessages(prev => [...prev, { sender: 'ai', text: `TUTORIAL: Good. You selected ${selectedProject.name}. Look at the holographic data core above to see why it failed. When you are ready, click 'Initiate Revival Protocol'.` }]);
      setTutorialStep(2);
    }
  }, [selectedProject, tutorialStep]);

  useEffect(() => {
    if (tutorialStep === 2 && revivingIds.size > 0) {
      setMessages(prev => [...prev, { sender: 'ai', text: 'TUTORIAL: Revival protocol initiated! Construction drones have been deployed.' }]);
      setTimeout(() => {
        setMessages(prev => [...prev, { sender: 'ai', text: 'TUTORIAL: You can explore different districts using the sidebar on the left. The time of day and seasons also change the city atmosphere. End of tutorial. I will remain here if you need system diagnostics.' }]);
        setTutorialStep(3);
      }, 4000);
    }
  }, [revivingIds, tutorialStep]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    setMessages(prev => [...prev, { sender: 'user', text: input }]);
    setInput('');
    setTimeout(() => {
       setMessages(prev => [...prev, { sender: 'ai', text: 'Processing grid data... Diagnostic systems indicate all nodes are functioning. Please select a dead project to initiate revival protocol.' }]);
    }, 1000);
  };

  return (
    <div className="absolute bottom-8 right-8 flex flex-col items-end gap-4 z-[70]">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="w-80 h-96 bg-[#08080a]/90 backdrop-blur-xl border border-cyan-500/30 rounded-xl overflow-hidden shadow-[0_0_30px_rgba(34,211,238,0.15)] flex flex-col"
          >
            <div className="p-3 bg-cyan-900/20 border-b border-cyan-500/20 flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs tracking-widest uppercase">
                <Sparkles size={14} />
                Echo // Grid Assistant
              </div>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white"><X size={14} /></button>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-3">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-lg text-sm ${m.sender === 'user' ? 'bg-cyan-500/20 text-cyan-100 border border-cyan-500/30' : 'bg-white/5 text-gray-300 border border-white/10'}`}>
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSend} className="p-3 border-t border-white/10 bg-black/40">
              <input 
                type="text" 
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Query system..." 
                className="w-full bg-transparent border-none outline-none text-sm text-white placeholder-gray-600 font-mono"
              />
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <button onClick={() => setIsOpen(!isOpen)} className="h-14 w-14 rounded-full bg-cyan-400 hover:bg-cyan-300 text-black flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:shadow-[0_0_30px_rgba(0,240,255,0.5)] transition-all duration-300 hover:scale-105 group relative">
        <div className="absolute inset-0 rounded-full border border-white/50 scale-110 opacity-0 group-hover:opacity-100 group-hover:scale-125 transition-all duration-500"></div>
        <Sparkles size={24} className="group-hover:rotate-12 transition-transform" />
      </button>
    </div>
  );
};


const CreateProjectModal = ({ onClose, onCreate }: any) => {
  const [name, setName] = useState('');
  const [founder, setFounder] = useState('');
  const [description, setDescription] = useState('');
  const [district, setDistrict] = useState('AI District');

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!name || !founder) return;
    onCreate({
      name,
      founder,
      description: description || 'A new initiative in the city.',
      district,
      stage: 1,
      status: 'Seed',
      timeline: 'Just started',
    });
    onClose();
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[#08080a] border border-cyan-500/30 rounded-xl p-8 max-w-md w-full shadow-[0_0_50px_rgba(34,211,238,0.1)] relative"
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors">
          <X size={20} />
        </button>
        
        <h2 className="text-2xl font-bold text-white mb-1 tracking-tight">Initialize Protocol</h2>
        <p className="text-sm text-cyan-500/70 font-mono tracking-widest uppercase mb-8">Register New Project</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] text-gray-400 font-mono uppercase tracking-widest mb-1">Project Name</label>
            <input 
              type="text" 
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/50 transition-colors"
              placeholder="e.g. Project Nexus"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] text-gray-400 font-mono uppercase tracking-widest mb-1">Lead Architect (Founder)</label>
            <input 
              type="text" 
              value={founder}
              onChange={e => setFounder(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/50 transition-colors"
              placeholder="e.g. Ada Lovelace"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] text-gray-400 font-mono uppercase tracking-widest mb-1">Sector Assignment</label>
            <select 
              value={district}
              onChange={e => setDistrict(e.target.value)}
              className="w-full bg-[#111115] border border-white/10 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-cyan-500/50 transition-colors"
            >
              {DISTRICTS.map(d => (
                <option key={d.name} value={d.name}>{d.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[10px] text-gray-400 font-mono uppercase tracking-widest mb-1">Mission Statement</label>
            <textarea 
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/50 transition-colors h-24 resize-none"
              placeholder="Describe the initiative..."
            />
          </div>
          
          <button 
            type="submit"
            className="w-full mt-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Zap size={18} />
            Deploy to Grid
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
};



const ProjectDashboard = ({ project, onClose }: any) => {
  if (!project) return null;
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[300] bg-[#030304] text-white flex flex-col font-sans"
    >
      <div className="flex items-center justify-between p-6 border-b border-white/10 bg-black/50 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <Activity size={32} className="text-cyan-400" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white">{project.name} <span className="text-cyan-500 font-mono text-sm ml-2 px-2 py-1 bg-cyan-500/10 rounded">SYSTEM ACTIVE</span></h1>
            <div className="text-sm text-gray-400 font-mono tracking-widest uppercase mt-1">{project.district} // Lead: {project.founder}</div>
          </div>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white">
          <X size={24} />
        </button>
      </div>

      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <div className="bg-white/5 border border-white/10 rounded-xl p-8 backdrop-blur-sm">
              <h2 className="text-lg font-mono tracking-widest uppercase text-cyan-400 mb-4">Mission Statement</h2>
              <p className="text-xl text-gray-300 leading-relaxed">{project.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
               <div className="bg-white/5 border border-white/10 rounded-xl p-6 backdrop-blur-sm">
                 <h3 className="text-xs font-mono tracking-widest uppercase text-gray-500 mb-2">Stage</h3>
                 <div className="text-3xl font-bold text-white">{project.status}</div>
               </div>
               <div className="bg-white/5 border border-white/10 rounded-xl p-6 backdrop-blur-sm">
                 <h3 className="text-xs font-mono tracking-widest uppercase text-gray-500 mb-2">Timeline</h3>
                 <div className="text-lg font-medium text-white">{project.timeline}</div>
               </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-8 backdrop-blur-sm min-h-[300px] flex items-center justify-center relative overflow-hidden">
               <div className="absolute inset-0 bg-[linear-gradient(0deg,transparent_24%,rgba(34,211,238,0.1)_25%,rgba(34,211,238,0.1)_26%,transparent_27%)] bg-[length:4px_4px]" />
               <div className="text-center relative z-10">
                 <Activity size={48} className="mx-auto text-cyan-500/50 mb-4 animate-pulse" />
                 <div className="font-mono text-gray-400 tracking-widest uppercase">Live Metrics Terminal</div>
                 <div className="text-sm text-gray-500 mt-2">Connecting to data stream...</div>
               </div>
            </div>
          </div>
          
          <div className="space-y-4">
             <div className="bg-cyan-900/20 border border-cyan-500/30 rounded-xl p-6">
                <h3 className="font-mono text-cyan-400 tracking-widest uppercase mb-4 text-sm flex items-center gap-2"><Cpu size={16} /> Compute Nodes</h3>
                <div className="space-y-3">
                   {[1, 2, 3].map(i => (
                     <div key={i} className="flex items-center justify-between bg-black/40 rounded p-3 border border-cyan-500/20">
                       <span className="font-mono text-xs text-gray-400">Node_{i}</span>
                       <span className="text-cyan-400 text-sm">Active</span>
                     </div>
                   ))}
                </div>
             </div>
             
             <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                <h3 className="font-mono text-gray-400 tracking-widest uppercase mb-4 text-sm flex items-center gap-2"><Users size={16} /> Team Roster</h3>
                <div className="space-y-3">
                   <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold">{project.founder.charAt(0)}</div>
                     <div>
                       <div className="text-sm text-white">{project.founder}</div>
                       <div className="text-[10px] text-cyan-400 uppercase tracking-widest font-mono">Lead Architect</div>
                     </div>
                   </div>
                   <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-gray-400 font-bold">A</div>
                     <div>
                       <div className="text-sm text-white">AI Agent</div>
                       <div className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">Support</div>
                     </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const CollaborationNetworkModal = ({ project, allProjects, onClose }: any) => {
  if (!project) return null;
  // Generate some connected projects based on realistic traits
  const connectedProjects = allProjects.filter((p: any) => 
    p.id !== project.id && (p.district === project.district || p.founder === project.founder)
  ).slice(0, 4);
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[250] flex items-center justify-center bg-black/90 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[#08080a] border border-fuchsia-500/30 rounded-xl p-8 max-w-2xl w-full shadow-[0_0_50px_rgba(232,121,249,0.1)] relative"
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors">
          <X size={20} />
        </button>
        
        <div className="flex items-center gap-4 mb-8">
           <div className="w-12 h-12 bg-fuchsia-500/20 border border-fuchsia-500/50 rounded-lg flex items-center justify-center text-fuchsia-400">
             <Code size={24} />
           </div>
           <div>
             <h2 className="text-2xl font-bold text-white tracking-tight">Collaboration Network</h2>
             <p className="text-sm text-fuchsia-500/70 font-mono tracking-widest uppercase">Linked Infrastructure</p>
           </div>
        </div>
        
        <div className="mb-6">
           <div className="text-lg text-white font-medium mb-1">{project.name}</div>
           <div className="text-xs text-gray-500 font-mono tracking-widest uppercase mb-4">Core Node ({project.district})</div>
           
           <div className="flex justify-center mb-4">
             <div className="w-px h-8 bg-gradient-to-b from-fuchsia-500 to-transparent"></div>
           </div>
           
           <h3 className="text-xs text-fuchsia-400 font-mono tracking-widest uppercase mb-3">Connected Nodes</h3>
           <div className="grid gap-3 max-h-64 overflow-y-auto pr-2">
             {connectedProjects.map((p: any) => {
               const isSharedFounder = p.founder === project.founder;
               const linkType = isSharedFounder ? 'Shared Founder' : 'Tech Bridge';
               return (
                 <div key={p.id} className="bg-white/5 border border-white/10 rounded-lg p-4 flex items-center justify-between hover:bg-white/10 transition-colors cursor-default">
                   <div>
                     <div className="text-white font-medium">{p.name}</div>
                     <div className="text-xs text-gray-400 mt-1">{p.district} // Founder: {p.founder}</div>
                   </div>
                   <div className="text-[10px] bg-fuchsia-500/10 text-fuchsia-400 px-2 py-1 rounded font-mono uppercase tracking-widest border border-fuchsia-500/20">
                     {linkType}
                   </div>
                 </div>
               )
             })}
             {connectedProjects.length === 0 && (
               <div className="text-gray-500 text-sm italic py-4 text-center">No active connections detected.</div>
             )}
           </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default function App() {
  const [projects, setProjects] = useState<any[]>(INITIAL_PROJECTS);
  const [activeDistrict, setActiveDistrict] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [revivingIds, setRevivingIds] = useState<Set<any>>(new Set());
  const [isBooting, setIsBooting] = useState(false);
  const [isCreatingProject, setIsCreatingProject] = useState(false);
  const [accessedProject, setAccessedProject] = useState<any>(null);
  const [collabProject, setCollabProject] = useState<any>(null);
  const [season, setSeason] = useState('Summer');
  const [zoomLevel, setZoomLevel] = useState(3); // 1 to 4
  const [viewMode, setViewMode] = useState<'city' | 'network' | 'graveyard' | 'echo' | 'settings'>('city');

  const timeHour = useTimeOfDay();
  const timeColors = getTimeColors(timeHour);

  useEffect(() => {
    async function loadProjects() {
      const fbProjects = await CreateProjectService.getProjects();
      if (fbProjects.length > 0) {
        setProjects(prev => {
          const newProjects = [...prev];
          fbProjects.forEach(fp => {
            if (!newProjects.find(p => p.id === fp.id)) {
              newProjects.push(fp);
            }
          });
          return newProjects;
        });
      }
    }
    loadProjects();
  }, []);

  const handleRevive = (id: any) => {
    setRevivingIds(prev => new Set(prev).add(id));
    setSelectedProject(null);
    
    let currentStage = 1;
    const stages = ['Seed', 'Series A', 'Series B', 'Scale'];
    
    const interval = setInterval(async () => {
       setProjects(current => current.map(p => 
          p.id === id ? { ...p, stage: currentStage, status: stages[currentStage - 1] || 'Scale', reason: undefined } : p
       ));
       currentStage++;
       
       if (currentStage > 4) {
         clearInterval(interval);
         if (typeof id === 'string') {
            await CreateProjectService.updateProject(id, { stage: 4, status: 'Scale', reason: '' });
         }
         setRevivingIds(prev => {
             const next = new Set(prev);
             next.delete(id);
             return next;
         });
       }
    }, 1500);
  }

  
  const handleUpgrade = (id: any) => {
    setRevivingIds(prev => new Set(prev).add(id));
    setSelectedProject(null);
    
    setTimeout(async () => {
       let nextStage = 0;
       let nextStatus = '';
       setProjects(current => current.map(p => {
          if (p.id === id && p.stage < 4) {
             const stages = ['Seed', 'Series A', 'Series B', 'Scale', 'Legend'];
             nextStage = p.stage + 1;
             nextStatus = stages[nextStage - 1] || 'Scale';
             return { ...p, stage: nextStage, status: nextStatus };
          }
          return p;
       }));

       if (typeof id === 'string' && nextStage > 0) {
           await CreateProjectService.updateProject(id, { stage: nextStage, status: nextStatus });
       }

       setRevivingIds(prev => {
           const next = new Set(prev);
           next.delete(id);
           return next;
       });
    }, 2000);
  }

  const filteredProjects = projects.filter(p => {
    const matchesDistrict = activeDistrict === 'All' || p.district === activeDistrict;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.founder.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDistrict && matchesSearch;
  });

  const aliveProjects = filteredProjects.filter(p => p.stage > 0 && p.status !== 'Abandoned');
  const deadProjects = filteredProjects.filter(p => p.stage === 0 || p.status === 'Abandoned');

  const activeTheme = activeDistrict !== 'All' ? getDistrictTheme(activeDistrict) : null;

  return (
    <div className={`h-screen ${timeColors.bg} text-white flex flex-col font-sans overflow-hidden selection:bg-cyan-500/30 transition-colors duration-1000`}>
      <AnimatePresence>
        {isBooting && <RebootIntro onComplete={() => setIsBooting(false)} />}
        {accessedProject && (
          <ProjectDashboard project={projects.find(p => p.id === accessedProject)} onClose={() => setAccessedProject(null)} />
        )}
        {collabProject && (
          <CollaborationNetworkModal project={projects.find(p => p.id === collabProject)} allProjects={projects} onClose={() => setCollabProject(null)} />
        )}
        {isCreatingProject && (
          <CreateProjectModal 
            onClose={() => setIsCreatingProject(false)} 
            onCreate={async (newProj: any) => {
              const projData = { ...newProj, stage: 0, status: 'Blueprint' };
              const savedProj = await CreateProjectService.createProject(projData);
              setProjects(prev => [...prev, savedProj]);
              setActiveDistrict(savedProj.district);
              setTimeout(() => {
                 handleRevive(savedProj.id);
              }, 500);
            }} 
          />
        )}
      </AnimatePresence>

      <CityHeader 
        projects={projects} 
        revivingCount={revivingIds.size + 12} 
        season={season}
        setSeason={setSeason}
        zoomLevel={zoomLevel}
        setZoomLevel={setZoomLevel}
        timeColors={timeColors}
        viewMode={viewMode}
        setViewMode={(mode: 'city' | 'network' | 'graveyard' | 'echo' | 'settings') => {
          setViewMode(mode);
          setSelectedProject(null);
        }}
      />

      <div className="flex-1 flex overflow-hidden relative">
        <button 
          onClick={() => setIsCreatingProject(true)}
          className="md:hidden absolute bottom-6 right-6 z-50 bg-cyan-500 hover:bg-cyan-400 text-black p-4 rounded-full shadow-[0_0_20px_rgba(34,211,238,0.4)] flex items-center justify-center transition-transform active:scale-95"
        >
          <Zap size={24} />
        </button>
        <Sidebar 
          activeDistrict={activeDistrict} 
          setActiveDistrict={(d: string) => { setActiveDistrict(d); setSelectedProject(null); }} 
          onSearch={setSearchQuery} 
          onNewProject={() => setIsCreatingProject(true)}
        />
        
        {/* Main City Viewport */}
        <div className="flex-1 overflow-auto relative bg-transparent">
          {viewMode === 'city' ? (
            <City3D 
              aliveProjects={aliveProjects}
              deadProjects={[]}
              selectedProject={selectedProject}
              setSelectedProject={setSelectedProject}
              onRevive={handleRevive}
              revivingIds={revivingIds}
              timeColors={timeColors}
            />
          ) : viewMode === 'graveyard' ? (
            <City3D 
              aliveProjects={[]}
              deadProjects={deadProjects}
              selectedProject={selectedProject}
              setSelectedProject={setSelectedProject}
              onRevive={handleRevive}
              revivingIds={revivingIds}
              timeColors={{ ...timeColors, bg: 'bg-[#020203]', sky: 'bg-gradient-to-t from-zinc-950 via-[#030406] to-black', fog: 'bg-zinc-500/5', ambientLight: 'rgba(120,120,140,0.05)' }}
            />
          ) : viewMode === 'settings' ? (
            <div className="h-full min-h-[620px] bg-[#05070b] flex items-center justify-center">
              <div className="border border-white/10 bg-white/[0.03] rounded-lg p-8 max-w-md text-center">
                <Settings className="mx-auto text-cyan-300 mb-4" size={28} />
                <h2 className="text-white text-xl font-semibold mb-2">System Settings</h2>
                <p className="text-gray-400 text-sm leading-6">Visual preferences and ecosystem controls remain connected here while the new operating-system layout settles in.</p>
              </div>
            </div>
          ) : (
            <Network3D
              aliveProjects={aliveProjects}
              deadProjects={viewMode === 'echo' ? [] : deadProjects}
              selectedProject={selectedProject}
              setSelectedProject={setSelectedProject}
              viewMode={viewMode}
            />
          )}
        </div>
        
        
      </div>

      <EchoAI 
        isBooting={isBooting} 
        activeDistrict={activeDistrict} 
        selectedProject={selectedProject} 
        revivingIds={revivingIds} 
      />
    </div>
  );
}
