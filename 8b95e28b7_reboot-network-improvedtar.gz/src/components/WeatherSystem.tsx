import React, { useMemo } from 'react';

export default function WeatherSystem({ energy }: { energy: number }) {
  // energy is 0 to 100
  // When energy is low, maybe it's just a few particles
  // When energy is high, it's intense digital rain
  
  const particleCount = Math.floor(20 + (energy / 100) * 80);
  
  const particles = useMemo(() => {
    return Array.from({ length: particleCount }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      animationDuration: `${Math.random() * 2 + 1}s`,
      animationDelay: `-${Math.random() * 2}s`,
      opacity: Math.random() * 0.5 + 0.2,
      size: Math.random() * 3 + 1,
    }));
  }, [particleCount]);

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 1, overflow: 'hidden' }}>
      {particles.map(p => (
        <div
          key={p.id}
          className="digital-drop"
          style={{
            position: 'absolute',
            top: '-10%',
            left: p.left,
            width: p.size,
            height: p.size * 10,
            background: `linear-gradient(to bottom, transparent, rgba(0, 255, 255, ${p.opacity}))`,
            animation: `fall ${p.animationDuration} linear infinite`,
            animationDelay: p.animationDelay,
          }}
        />
      ))}
      <style>{`
        @keyframes fall {
          to {
            transform: translateY(120vh);
          }
        }
      `}</style>
    </div>
  );
}
