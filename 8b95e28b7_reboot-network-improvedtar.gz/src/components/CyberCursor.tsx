import { useEffect, useRef } from 'react';

export default function CyberCursor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    const onResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    window.addEventListener('resize', onResize);

    const mouse = { x: width / 2, y: height / 2, targetX: width / 2, targetY: height / 2 };
    let isClicking = false;

    const onMouseMove = (e: MouseEvent) => {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
    };
    const onMouseDown = () => { isClicking = true; };
    const onMouseUp = () => { isClicking = false; };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);

    let rafId: number;

    const trail: { x: number; y: number; age: number }[] = [];

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Lerp
      mouse.x += (mouse.targetX - mouse.x) * 0.3;
      mouse.y += (mouse.targetY - mouse.y) * 0.3;

      // Add trail
      trail.push({ x: mouse.x, y: mouse.y, age: 0 });
      if (trail.length > 20) trail.shift();

      // Draw trail
      ctx.beginPath();
      for (let i = 0; i < trail.length; i++) {
        const p = trail[i];
        p.age++;
        if (i === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
      }
      ctx.strokeStyle = `rgba(0, 255, 255, 0.3)`;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();

      // Draw main cursor
      ctx.beginPath();
      const radius = isClicking ? 6 : 12;
      ctx.arc(mouse.x, mouse.y, radius, 0, Math.PI * 2);
      ctx.strokeStyle = '#00FFFF';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      
      ctx.beginPath();
      ctx.arc(mouse.x, mouse.y, 2, 0, Math.PI * 2);
      ctx.fillStyle = '#00FFFF';
      ctx.fill();

      // Draw crosshairs
      const size = isClicking ? 12 : 24;
      ctx.beginPath();
      ctx.moveTo(mouse.x - size, mouse.y);
      ctx.lineTo(mouse.x + size, mouse.y);
      ctx.moveTo(mouse.x, mouse.y - size);
      ctx.lineTo(mouse.x, mouse.y + size);
      ctx.strokeStyle = 'rgba(0, 255, 255, 0.5)';
      ctx.lineWidth = 0.5;
      ctx.stroke();

      rafId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        pointerEvents: 'none',
        zIndex: 99999,
      }}
    />
  );
}
