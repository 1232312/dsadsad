import React, { useMemo, useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useAnimationFrame } from 'framer-motion';
import type { Idea } from '../lib/firebase';
import EchoBrain from './EchoBrain';
import CyberHeart from './CyberHeart';

const CATEGORY_COLORS: Record<string, string> = {
  ai: '#00FFFF',
  apps: '#FF00CC',
  games: '#FFE000',
  business: '#00FF88',
  education: '#AA44FF',
  art: '#FF6600',
};

const calculateRelevance = (idea: Idea, featured: Idea) => {
  let score = 0;
  if (idea.category === featured.category) score += 4;
  if (idea.status === featured.status) score += 2;
  const sharedTags = idea.tags?.filter(t => featured.tags?.includes(t)) || [];
  score += sharedTags.length * 1.5;
  return score;
};

export default function OrbitSystem({ ideas, featuredId, onSelect }: { ideas: Idea[]; featuredId: string; onSelect: (i: Idea) => void }) {
  const featured = ideas.find(i => i.id === featuredId);
  const [hoveredOrb, setHoveredOrb] = useState<string | null>(null);
  
  const orbsRef = useRef(new Map());
  
  const orbsData = useMemo(() => {
    if (!featured) return [];
    
    const withRelevance = ideas.filter(i => i.id !== featuredId).map(idea => ({
      idea,
      relevance: calculateRelevance(idea, featured)
    }));
    
    withRelevance.sort((a, b) => b.relevance - a.relevance);
    const topIdeas = withRelevance.slice(0, 35);
    
    return topIdeas.map((item, index) => {
      const { idea, relevance } = item;
      // Higher relevance -> closer to center
      const radius = Math.max(140, 380 - (relevance * 22)) + (Math.random() * 40 - 20);
      const angleDeg = (index / topIdeas.length) * 360 + Math.random() * 20;
      // Higher relevance -> faster speed
      const baseSpeed = 8 + (relevance * 2.5);
      const direction = Math.random() > 0.5 ? 1 : -1;
      
      return {
        id: idea.id,
        idea,
        radius,
        initialAngle: angleDeg,
        speed: baseSpeed * direction,
        color: CATEGORY_COLORS[idea.category] || '#00FFFF',
        relevance,
        isRelated: relevance > 3
      };
    });
  }, [ideas, featuredId, featured]);
  
  const previousOrbsDataRef = useRef<Array<Record<string, unknown>> | null>(null);
  if (previousOrbsDataRef.current !== orbsData) {
    previousOrbsDataRef.current = orbsData;
    const map = new Map();
    orbsData.forEach(orb => {
      const existing = orbsRef.current.get(orb.id);
      map.set(orb.id, {
        ...orb,
        angle: existing ? existing.angle : orb.initialAngle,
        el: existing ? existing.el : null,
        innerEl: existing ? existing.innerEl : null,
        tooltipEl: existing ? existing.tooltipEl : null,
        isHovered: existing ? existing.isHovered : false
      });
    });
    orbsRef.current = map;
  }

  // Sync hover state to ref
  useEffect(() => {
    const map = orbsRef.current;
    for (const [id, orb] of map.entries()) {
      orb.isHovered = (id === hoveredOrb);
    }
  }, [hoveredOrb]);

  useAnimationFrame((time, delta) => {
    if (!orbsRef.current) return;
    const dt = delta / 1000;
    const orbs = Array.from(orbsRef.current.values());
    
    // Update angles
    for (const orb of orbs) {
      orb.angle += orb.speed * dt;
      orb.angle = ((orb.angle % 360) + 360) % 360;
    }
    
    // Detect passes
    const activeGlows = new Set();
    for (let i = 0; i < orbs.length; i++) {
      for (let j = i + 1; j < orbs.length; j++) {
        const a1 = orbs[i].angle;
        const a2 = orbs[j].angle;
        let diff = Math.abs(a1 - a2);
        if (diff > 180) diff = 360 - diff;
        
        // Flash if passing within a small angular window
        if (diff < 3) {
          activeGlows.add(orbs[i].id);
          activeGlows.add(orbs[j].id);
        }
      }
    }
    
    // Apply updates
    for (const orb of orbs) {
      if (orb.el) {
        orb.el.style.transform = `rotate(${orb.angle}deg)`;
      }
      if (orb.innerEl) {
        if (orb.isHovered) {
          orb.innerEl.style.boxShadow = `0 0 30px ${orb.color}, 0 0 60px ${orb.color}`;
          orb.innerEl.style.transform = `translate(-50%, -50%) scale(1.5)`;
          orb.innerEl.style.background = orb.color;
        } else if (activeGlows.has(orb.id)) {
          orb.innerEl.style.boxShadow = `0 0 20px #fff, 0 0 40px ${orb.color}`;
          orb.innerEl.style.transform = `translate(-50%, -50%) scale(1.3)`;
          orb.innerEl.style.background = '#fff';
        } else {
          orb.innerEl.style.boxShadow = `0 0 15px ${orb.color}, 0 0 30px ${orb.color}`;
          orb.innerEl.style.transform = `translate(-50%, -50%) scale(1)`;
          orb.innerEl.style.background = orb.color;
        }
      }
      if (orb.tooltipEl) {
        // Counter-rotate the tooltip to keep text upright
        orb.tooltipEl.style.transform = `rotate(${-orb.angle}deg)`;
      }
    }
  });

  if (!featured) return null;

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', top: '50%', left: '50%', width: 0, height: 0 }}>
        
        {/* Core AI Brain & Heartbeat */}
        <div style={{ position: 'absolute', top: -50, left: -32, zIndex: 10 }}>
           <EchoBrain size={64} />
        </div>
        <div style={{ position: 'absolute', top: 5, left: -20, zIndex: 11 }}>
           <CyberHeart status={featured.status} vitality={featured.potential_score + (featured.revival_count * 10)} size={40} />
        </div>

        {/* Orbit Rings */}
        {orbsData.map(orb => (
          <div
            key={`ring-${orb.id}`}
            style={{
              position: 'absolute',
              width: orb.radius * 2,
              height: orb.radius * 2,
              left: -orb.radius,
              top: -orb.radius,
              borderRadius: '50%',
              border: `1px solid ${orb.color}`,
              opacity: 0.1,
              pointerEvents: 'none'
            }}
          />
        ))}

        <AnimatePresence>
          {orbsData.map((orb) => {
            const isHovered = hoveredOrb === orb.id;
            
            return (
              <motion.div
                key={orb.id}
                initial={{ opacity: 0, width: orb.radius * 2, height: orb.radius * 2, left: -orb.radius, top: -orb.radius }}
                animate={{ 
                  opacity: 1,
                  width: orb.radius * 2, 
                  height: orb.radius * 2, 
                  left: -orb.radius, 
                  top: -orb.radius
                }}
                exit={{ opacity: 0 }}
                transition={{ 
                  width: { duration: 1.5, ease: 'easeInOut' },
                  height: { duration: 1.5, ease: 'easeInOut' },
                  left: { duration: 1.5, ease: 'easeInOut' },
                  top: { duration: 1.5, ease: 'easeInOut' },
                  opacity: { duration: 1 }
                }}
                style={{ 
                  position: 'absolute', 
                  borderRadius: '50%',
                }}
              >
                {/* We need a separate ref div to handle rotate because Framer Motion might clear it otherwise */}
                <div 
                  ref={(el) => {
                    const mapOrb = orbsRef.current.get(orb.id);
                    if (mapOrb) mapOrb.el = el;
                  }}
                  style={{ position: 'absolute', inset: 0, borderRadius: '50%' }}
                >
                  {/* Connection line for related ideas or hovered ones */}
                  {(orb.isRelated || isHovered) && (
                    <motion.svg 
                      animate={{ left: orb.radius, height: orb.radius }}
                      transition={{ duration: 1.5, ease: 'easeInOut' }}
                      style={{ position: 'absolute', top: 0, width: 2, overflow: 'visible', transform: 'translateX(-1px)' }}
                    >
                      <motion.line 
                        x1="1" 
                        y1="0"
                        x2="1" 
                        y2="0" animate={{ y1: orb.radius }}
                        transition={{ duration: 1.5, ease: 'easeInOut' }}
                        stroke={orb.color} 
                        strokeWidth={isHovered ? 2 : 1} 
                        strokeDasharray={isHovered ? "0" : "4 4"}
                        opacity={isHovered ? 1 : 0.4}
                        filter={`drop-shadow(0 0 ${isHovered ? '8px' : '3px'} ${orb.color})`}
                      />
                    </motion.svg>
                  )}

                  {/* Orb */}
                  <div
                    ref={(el) => {
                      const mapOrb = orbsRef.current.get(orb.id);
                      if (mapOrb) mapOrb.innerEl = el;
                    }}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: '50%',
                      transform: 'translate(-50%, -50%) scale(1)',
                      width: 14,
                      height: 14,
                      borderRadius: '50%',
                      background: orb.color,
                      boxShadow: `0 0 15px ${orb.color}, 0 0 30px ${orb.color}`,
                      cursor: 'pointer',
                      pointerEvents: 'auto',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'transform 0.15s ease-out, background 0.15s ease-out, box-shadow 0.15s ease-out'
                    }}
                    onMouseEnter={() => setHoveredOrb(orb.id)}
                    onMouseLeave={() => setHoveredOrb(null)}
                    onClick={() => onSelect(orb.idea)}
                  >
                    <div style={{ width: 4, height: 4, background: '#fff', borderRadius: '50%' }} />
                    
                    {isHovered && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        style={{
                          position: 'absolute',
                          top: 25,
                          width: 0, height: 0,
                          display: 'flex', justifyContent: 'center', alignItems: 'center'
                        }}
                      >
                        <div
                          ref={(el) => {
                            const mapOrb = orbsRef.current.get(orb.id);
                            if (mapOrb) mapOrb.tooltipEl = el;
                          }}
                          style={{
                            background: 'rgba(0,0,0,0.85)',
                            border: `1px solid ${orb.color}50`,
                            padding: '6px 12px',
                            borderRadius: 6,
                            whiteSpace: 'nowrap',
                            color: '#fff',
                            fontSize: 12,
                            fontFamily: "'Share Tech Mono', monospace",
                            pointerEvents: 'none',
                            zIndex: 100,
                            boxShadow: `0 10px 30px rgba(0,0,0,0.8), 0 0 20px ${orb.color}20`
                          }}
                        >
                          {orb.idea.title}
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>

              </motion.div>
            )
          })}
        </AnimatePresence>

        {/* Central "Featured" Interface Glow/Aura */}
        <motion.div
          style={{
            position: 'absolute',
            top: '50%', left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 160, height: 160,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${CATEGORY_COLORS[featured.category] || '#00FFFF'}40 0%, transparent 70%)`,
            filter: 'blur(10px)',
            pointerEvents: 'none'
          }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>
    </div>
  );
}
