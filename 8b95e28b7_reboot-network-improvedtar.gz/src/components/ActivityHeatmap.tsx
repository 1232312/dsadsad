import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { useAuth } from '../lib/auth';

export default function ActivityHeatmap() {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [tooltip, setTooltip] = useState<{ x: number, y: number, date: string, count: number } | null>(null);

  useEffect(() => {
    if (!user || !svgRef.current) return;

    const fetchData = async () => {
      try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const thirtyDaysAgo = new Date(today);
        thirtyDaysAgo.setDate(today.getDate() - 29);

        const q = query(
          collection(db, 'ideas'),
          where('author_id', '==', user.uid),
          where('created_at', '>=', Timestamp.fromDate(thirtyDaysAgo))
        );
        const snap = await getDocs(q);
        
        const counts = new Map<string, number>();
        snap.forEach(doc => {
          const d = doc.data();
          if (d.created_at) {
            const date = d.created_at.toDate();
            // local time string YYYY-MM-DD
            const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
            counts.set(key, (counts.get(key) || 0) + 1);
          }
        });

        const data: { date: Date, count: number }[] = [];
        for (let i = 0; i < 30; i++) {
          const d = new Date(thirtyDaysAgo);
          d.setDate(thirtyDaysAgo.getDate() + i);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
          data.push({ date: d, count: counts.get(key) || 0 });
        }

        drawHeatmap(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const drawHeatmap = (data: { date: Date, count: number }[]) => {
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    // Also remove any stray tooltips attached to body
    d3.select('body').selectAll('.heatmap-tooltip-d3').remove();
    
    const cellSize = 10;
    const cellMargin = 3;
    
    const minDate = data[0].date;
    const timeWeek = d3.timeWeek.floor;
    const minWeek = timeWeek(minDate);
    
    // Number of columns: weeks between minDate and maxDate
    const maxDate = data[data.length - 1].date;
    const numCols = d3.timeWeek.count(minWeek, maxDate) + 1;
    
    const width = numCols * (cellSize + cellMargin);
    const height = 7 * (cellSize + cellMargin);
    
    svg.attr('width', width).attr('height', height);
    
    const colorScale = d3.scaleThreshold<number, string>()
      .domain([1, 2, 4, 6])
      .range(['rgba(255,255,255,0.03)', '#00FFFF', '#00FF88', '#FF00CC', '#FFE000']);

    svg.selectAll('rect')
       .data(data)
       .enter()
       .append('rect')
       .attr('width', cellSize)
       .attr('height', cellSize)
       .attr('x', d => {
          const currentWeek = timeWeek(d.date);
          const col = d3.timeWeek.count(minWeek, currentWeek);
          return col * (cellSize + cellMargin);
       })
       .attr('y', d => d.date.getDay() * (cellSize + cellMargin))
       .attr('rx', 2)
       .attr('fill', d => d.count === 0 ? 'rgba(255,255,255,0.03)' : colorScale(d.count))
       .attr('stroke', d => d.count > 0 ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.05)')
       .attr('stroke-width', 0.5)
       .on('mouseover', (event, d) => {
         const rect = containerRef.current?.getBoundingClientRect();
         if (rect) {
           setTooltip({
             x: event.clientX - rect.left,
             y: event.clientY - rect.top,
             date: d.date.toDateString(),
             count: d.count
           });
         }
       })
       .on('mouseout', () => {
         setTooltip(null);
       });
  };

  if (!user) return null;

  return (
    <div ref={containerRef} style={{ position: 'relative', marginTop: 14, padding: '14px 16px', borderRadius: 10, background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 9, fontFamily: "'Share Tech Mono', monospace", color: 'rgba(255,255,255,0.2)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
          Your Activity (30d)
        </span>
      </div>
      {loading ? (
        <div style={{ height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 14, height: 14, border: '2px solid rgba(0,255,255,0.2)', borderTopColor: '#00FFFF', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
        </div>
      ) : (
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <svg ref={svgRef} style={{ overflow: 'visible' }} />
        </div>
      )}
      
      {tooltip && (
        <div style={{
          position: 'absolute',
          left: tooltip.x,
          top: tooltip.y - 12,
          background: 'rgba(2, 2, 12, 0.95)',
          color: '#fff',
          padding: '8px 12px',
          borderRadius: 8,
          fontSize: 10,
          fontFamily: "'Share Tech Mono', monospace",
          pointerEvents: 'none',
          zIndex: 100,
          border: '1px solid rgba(0, 255, 255, 0.3)',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.8), 0 0 12px rgba(0, 255, 255, 0.1)',
          transform: 'translate(-50%, -100%)',
          whiteSpace: 'nowrap',
          textAlign: 'center',
          animation: 'fadeUp 0.15s ease-out both'
        }}>
          <div style={{ color: 'rgba(255,255,255,0.5)', marginBottom: 4, letterSpacing: '0.05em' }}>{tooltip.date}</div>
          <div style={{ color: '#00FFFF', fontWeight: 'bold', fontSize: 12 }}>{tooltip.count} IDEA{tooltip.count !== 1 ? 'S' : ''}</div>
          <div style={{
            position: 'absolute', bottom: -5, left: '50%', transform: 'translateX(-50%) rotate(45deg)',
            width: 10, height: 10, background: 'rgba(2, 2, 12, 0.95)',
            borderRight: '1px solid rgba(0, 255, 255, 0.3)',
            borderBottom: '1px solid rgba(0, 255, 255, 0.3)',
          }} />
        </div>
      )}
    </div>
  );
}
