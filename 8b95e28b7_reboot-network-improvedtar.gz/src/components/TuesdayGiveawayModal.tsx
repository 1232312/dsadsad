import React from 'react';
import { Gift, Lock, X } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TuesdayGiveawayModalProps {
  onClose: () => void;
  userCount: number;
}

export function TuesdayGiveawayModal({ onClose, userCount }: TuesdayGiveawayModalProps) {
  const handleInitiateDrop = () => {
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF00CC', '#10B981', '#3B82F6', '#FFE000', '#00FFFF']
    });
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 100,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'rgba(2,2,12,0.8)', backdropFilter: 'blur(10px)'
    }}>
      <div style={{
        background: 'rgba(20,10,25,0.95)', border: '1px solid rgba(255,0,204,0.5)',
        borderRadius: 24, padding: 40, maxWidth: 400, width: '90%', textAlign: 'center',
        boxShadow: '0 20px 50px rgba(0,0,0,0.8), 0 0 40px rgba(255,0,204,0.2)',
        position: 'relative', animation: 'fadeUp 0.3s ease-out'
      }}>
        <button 
          onClick={onClose}
          style={{ position: 'absolute', top: 20, right: 20, color: 'rgba(255,255,255,0.5)', cursor: 'pointer', background: 'none', border: 'none' }}
        >
          <X size={24} />
        </button>
        <div style={{ width: 80, height: 80, margin: '0 auto 20px', borderRadius: '50%', background: 'rgba(255,0,204,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FF00CC' }}>
          <Gift size={40} />
        </div>
        <h2 style={{ fontSize: 24, fontWeight: 700, color: '#fff', marginBottom: 10 }}>Random Tuesday Giveaway</h2>
        {userCount >= 100000 ? (
          <>
            <div style={{ display: 'inline-block', padding: '6px 12px', background: 'rgba(16,185,129,0.1)', borderRadius: 20, marginBottom: 20 }}>
              <span style={{ fontSize: 12, color: '#10B981', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 'bold' }}>Unlocked: {userCount.toLocaleString()} Users</span>
            </div>
            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, lineHeight: 1.6 }}>
              System has reached 100k active users. You may now initiate the Tuesday Giveaway drop.
            </p>
            <button 
              onClick={handleInitiateDrop}
              style={{
              marginTop: 30, width: '100%', padding: '14px', borderRadius: 12,
              background: 'linear-gradient(135deg, #10B981 0%, #3B82F6 100%)', border: 'none',
              color: '#fff', fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
              boxShadow: '0 10px 20px rgba(16,185,129,0.3)'
            }}>
              <Gift size={18} /> Initiate Drop
            </button>
          </>
        ) : (
          <>
            <div style={{ display: 'inline-block', padding: '6px 12px', background: 'rgba(255,255,255,0.1)', borderRadius: 20, marginBottom: 20 }}>
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Locked till 100k Users ({userCount.toLocaleString()}/100,000)</span>
            </div>
            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, lineHeight: 1.6 }}>
              Wait until the system reaches 100,000 active users to initiate the drop.
            </p>
            <button style={{
              marginTop: 30, width: '100%', padding: '14px', borderRadius: 12,
              background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
              color: 'rgba(255,255,255,0.3)', fontWeight: 600, cursor: 'not-allowed',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10
            }}>
              <Lock size={18} /> Initiate Giveaway (Locked)
            </button>
          </>
        )}
      </div>
    </div>
  );
}
