import React, { useEffect, useState, useMemo } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db, Idea } from '../lib/firebase';
import { Activity, Volume2, VolumeX, GripHorizontal } from 'lucide-react';
import { audioManager } from '../lib/audio';
import { motion } from 'framer-motion';

export default function EcosystemVitalityHUD() {
  const [vitality, setVitality] = useState<number | null>(null);
  const [activeCount, setActiveCount] = useState(0);
  const [volume, setVolume] = useState(() => audioManager.getVolume());
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'ideas'),
      where('status', 'in', ['in_progress', 'revived'])
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      let total = 0;
      snapshot.forEach(doc => {
        const data = doc.data() as Idea;
        total += (data.potential_score || 0) + ((data.revival_count || 0) * 10);
      });
      setVitality(total);
      setActiveCount(snapshot.size);
    });

    return () => unsubscribe();
  }, []);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    audioManager.setVolume(newVol);
  };

  const toggleMute = () => {
    if (volume > 0) {
      setVolume(0);
      audioManager.setVolume(0);
    } else {
      setVolume(0.3);
      audioManager.setVolume(0.3);
    }
  };

  const bars = useMemo(() => Array.from({ length: 16 }), []);

  if (vitality === null) return null;
  const intensity = Math.min(1, vitality / 2000); 

  return (
    <>
      <style>
        {`
          .vitality-slider {
            -webkit-appearance: none;
          }
          .vitality-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 8px;
            height: 12px;
            background: #00FF88;
            cursor: pointer;
            border-radius: 2px;
            box-shadow: 0 0 5px rgba(0,255,136,0.5);
          }
          .vitality-slider::-moz-range-thumb {
            width: 8px;
            height: 12px;
            background: #00FF88;
            cursor: pointer;
            border-radius: 2px;
            border: none;
            box-shadow: 0 0 5px rgba(0,255,136,0.5);
          }
        `}
      </style>
      <motion.div 
        drag
        dragMomentum={false}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        style={{
          position: 'fixed', bottom: 24, left: 24, zIndex: 45,
          display: 'flex', flexDirection: 'column', gap: 6,
          padding: '14px 18px', borderRadius: 12,
          background: 'rgba(10, 10, 18, 0.6)',
          border: '1px solid rgba(0, 255, 136, 0.15)',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.3), inset 0 0 20px rgba(0, 255, 136, 0.05)',
          pointerEvents: 'auto',
          cursor: isHovered ? 'grab' : 'default',
        }}
        whileDrag={{ cursor: 'grabbing', scale: 1.02 }}
      >
        <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)', opacity: isHovered ? 1 : 0, transition: 'opacity 0.2s', display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: 20 }}>
          <GripHorizontal size={14} color="rgba(0, 255, 136, 0.5)" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Activity size={14} color="#00FF88" style={{ animation: `pulse-op ${1 + (1-intensity)*1.5}s infinite` }} />
            <span style={{ fontSize: 10, fontFamily: "'Share Tech Mono', monospace", color: 'rgba(0,255,136,0.8)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              Global Vitality
            </span>
          </div>
          
          <div 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 6,
              opacity: isHovered ? 1 : 0.3,
              transition: 'opacity 0.2s ease',
              pointerEvents: isHovered ? 'auto' : 'none'
            }}
            onPointerDown={(e) => e.stopPropagation()}
          >
            <button 
              onClick={toggleMute}
              style={{ 
                background: 'none', border: 'none', padding: 0, cursor: 'pointer', 
                color: 'rgba(0,255,136,0.8)', display: 'flex' 
              }}
            >
              {volume > 0 ? <Volume2 size={12} /> : <VolumeX size={12} />}
            </button>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.05" 
              value={volume}
              onChange={handleVolumeChange}
              className="vitality-slider"
              style={{
                width: 50,
                height: 2,
                appearance: 'none',
                background: 'rgba(0,255,136,0.3)',
                outline: 'none',
                cursor: 'pointer'
              }}
            />
          </div>
        </div>

        {/* SVG Bars for Heartbeat */}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 28, marginTop: 8 }}>
          {bars.map((_, i) => {
            const isCenter = i >= 6 && i <= 9;
            const delay = i * 0.05;
            const baseDuration = isCenter ? 0.4 : 0.8;
            const duration = baseDuration + (1 - intensity) * 0.5;
            return (
              <div key={i} style={{
                width: 4,
                background: '#00FF88',
                borderRadius: 2,
                animation: `eq-bar-${isCenter ? 'high' : 'low'} ${duration}s ease-in-out infinite alternate`,
                animationDelay: `${delay}s`,
                opacity: 0.8
              }} />
            )
          })}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 8, borderTop: '1px solid rgba(0,255,136,0.1)', paddingTop: 8 }}>
          <span style={{ fontSize: 18, fontWeight: 700, color: '#fff', fontFamily: "'Share Tech Mono', monospace" }}>
            {vitality.toLocaleString()} <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 400 }}>vT</span>
          </span>
          <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontFamily: "'Share Tech Mono', monospace" }}>
            {activeCount} ACTV
          </span>
        </div>
      </motion.div>
      <style>{`
        @keyframes eq-bar-low {
          0% { height: 15%; background: rgba(0,255,136,0.3); }
          100% { height: 45%; background: rgba(0,255,136,0.8); }
        }
        @keyframes eq-bar-high {
          0% { height: 30%; background: #00FF88; }
          100% { height: 100%; background: #00FFFF; filter: drop-shadow(0 0 6px #00FFFF); }
        }
        @keyframes pulse-op {
          0%, 100% { opacity: 0.4; transform: scale(0.9); }
          50% { opacity: 1; transform: scale(1.1); filter: drop-shadow(0 0 5px #00FF88); }
        }
      `}</style>
    </>
  );
}
