import * as React from "react";
import { useMemo, useRef, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { CameraControls, Html, Line, Stars, Text } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing";
import * as THREE from "three";

export interface Project {
  id: number | string;
  name: string;
  district: string;
  stage: number;
  status: string;
  founder?: string;
  timeline?: string;
}

const THEMES: Record<string, { color: string; emissive: string }> = {
  "AI District": { color: "#a78bfa", emissive: "#7c3aed" },
  Gaming: { color: "#67e8f9", emissive: "#0891b2" },
  Health: { color: "#34d399", emissive: "#047857" },
  Finance: { color: "#67e8f9", emissive: "#075985" },
  Education: { color: "#93c5fd", emissive: "#1d4ed8" },
  Creator: { color: "#e5e7eb", emissive: "#64748b" },
  Robotics: { color: "#fb923c", emissive: "#c2410c" },
  Space: { color: "#cbd5e1", emissive: "#475569" },
  "Open Source": { color: "#34d399", emissive: "#047857" },
  Marketplace: { color: "#67e8f9", emissive: "#075985" },
  "Idea Hub": { color: "#a78bfa", emissive: "#7c3aed" },
  Graveyard: { color: "#71717a", emissive: "#3f3f46" },
  default: { color: "#22d3ee", emissive: "#0891b2" },
};

const DISTRICT_ORDER = [
  "AI District",
  "Open Source",
  "Marketplace",
  "Robotics",
  "Gaming",
  "Finance",
  "Education",
  "Creator",
  "Health",
  "Space",
  "Idea Hub",
  "Graveyard",
];

function themeFor(district: string) {
  return THEMES[district] || THEMES.default;
}

function projectPosition(project: Project, index: number, all: Project[]) {
  const districtIndex = Math.max(0, DISTRICT_ORDER.indexOf(project.district));
  const angle = (districtIndex / DISTRICT_ORDER.length) * Math.PI * 2 - Math.PI / 2;
  const peers = all.filter((item) => item.district === project.district);
  const peerIndex = peers.findIndex((item) => item.id === project.id);
  const ring = 19 + (peerIndex % 4) * 5 + Math.floor(peerIndex / 4) * 1.6;
  const jitter = ((index * 37) % 11 - 5) * 0.42;
  return new THREE.Vector3(
    Math.cos(angle + jitter * 0.02) * ring + Math.sin(peerIndex) * 3,
    ((peerIndex % 3) - 1) * 2.2,
    Math.sin(angle + jitter * 0.02) * ring + Math.cos(peerIndex * 1.7) * 3
  );
}

function EchoCore() {
  const group = useRef<THREE.Group>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  const midRef = useRef<THREE.Mesh>(null);
  const outerRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Mesh>(null);
  const ring2Ref = useRef<THREE.Mesh>(null);
  const ring3Ref = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);
  const gridRef = useRef<THREE.Group>(null);

  const particlePositions = useMemo(() => {
    const arr = new Float32Array(300 * 3);
    for (let i = 0; i < 300; i++) {
      const r = 4.2 + Math.random() * 4.8;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos((Math.random() * 2) - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      arr[i * 3 + 2] = r * Math.cos(phi);
    }
    return arr;
  }, []);

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime;

    if (group.current) {
      group.current.rotation.y = t * 0.12;
    }

    if (innerRef.current) {
      innerRef.current.rotation.x = -t * 0.25;
      innerRef.current.rotation.y = t * 0.35;
      const pulse = 1.0 + Math.sin(t * 2.8) * 0.12;
      innerRef.current.scale.setScalar(pulse);
      if (innerRef.current.material && !Array.isArray(innerRef.current.material)) {
        const mat = innerRef.current.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 1.6 + Math.sin(t * 2.8) * 0.4;
      }
    }

    if (midRef.current) {
      midRef.current.rotation.x = t * 0.4;
      midRef.current.rotation.z = -t * 0.15;
      if (midRef.current.material && !Array.isArray(midRef.current.material)) {
        const mat = midRef.current.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 1.1 + Math.cos(t * 1.8) * 0.25;
      }
    }

    if (outerRef.current) {
      outerRef.current.rotation.y = -t * 0.18;
      outerRef.current.rotation.z = t * 0.25;
      if (outerRef.current.material && !Array.isArray(outerRef.current.material)) {
        const mat = outerRef.current.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 0.8 + Math.sin(t * 1.2) * 0.2;
      }
    }

    if (ring1Ref.current) ring1Ref.current.rotation.z = t * 0.65;
    if (ring2Ref.current) ring2Ref.current.rotation.z = -t * 0.5;
    if (ring3Ref.current) ring3Ref.current.rotation.z = t * 0.35;

    if (particlesRef.current) {
      particlesRef.current.rotation.y = -t * 0.08;
      particlesRef.current.rotation.x = t * 0.04;
    }

    if (gridRef.current) {
      gridRef.current.children.forEach((child, i) => {
        child.rotation.z = t * (0.08 * (i + 1) * (i % 2 === 0 ? 1 : -1));
        if (child instanceof THREE.Mesh && child.material && !Array.isArray(child.material)) {
          const mat = child.material as THREE.MeshBasicMaterial;
          mat.opacity = 0.12 + Math.sin(t * 1.8 + i) * 0.05;
        }
      });
    }
  });

  return (
    <group>
      <group ref={group}>
        {/* Inner solid glowing core */}
        <mesh ref={innerRef}>
          <icosahedronGeometry args={[1.9, 3]} />
          <meshStandardMaterial
            color="#a78bfa"
            emissive="#7c3aed"
            emissiveIntensity={1.5}
            transparent
            opacity={0.82}
            roughness={0.1}
            metalness={0.9}
          />
        </mesh>

        {/* Middle wireframe core */}
        <mesh ref={midRef}>
          <icosahedronGeometry args={[2.9, 2]} />
          <meshStandardMaterial
            color="#10131c"
            emissive="#67e8f9"
            emissiveIntensity={1.0}
            wireframe
            transparent
            opacity={0.65}
          />
        </mesh>

        {/* Outer wireframe core */}
        <mesh ref={outerRef}>
          <icosahedronGeometry args={[3.9, 1]} />
          <meshStandardMaterial
            color="#10131c"
            emissive="#a78bfa"
            emissiveIntensity={0.8}
            wireframe
            transparent
            opacity={0.35}
          />
        </mesh>

        {/* Orbiting energy rings at multiple angles */}
        <mesh ref={ring1Ref} rotation={[0.6, 0.1, 0.2]}>
          <torusGeometry args={[4.7, 0.038, 12, 120]} />
          <meshStandardMaterial color="#67e8f9" emissive="#67e8f9" emissiveIntensity={1.4} />
        </mesh>
        <mesh ref={ring2Ref} rotation={[-0.7, 0.3, -0.4]}>
          <torusGeometry args={[5.5, 0.028, 12, 120]} />
          <meshStandardMaterial color="#a78bfa" emissive="#a78bfa" emissiveIntensity={1.2} />
        </mesh>
        <mesh ref={ring3Ref} rotation={[1.2, -0.4, 0.5]}>
          <torusGeometry args={[6.3, 0.022, 12, 120]} />
          <meshStandardMaterial color="#f472b6" emissive="#f472b6" emissiveIntensity={1.0} />
        </mesh>

        {/* Core particle field */}
        <points ref={particlesRef}>
          <bufferGeometry>
            <bufferAttribute attach="attributes-position" args={[particlePositions, 3]} />
          </bufferGeometry>
          <pointsMaterial color="#67e8f9" size={0.12} transparent opacity={0.8} sizeAttenuation />
        </points>
      </group>

      {/* Ground hologram projection base */}
      <group ref={gridRef} position={[0, -6.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <mesh>
          <ringGeometry args={[0.2, 5.8, 32]} />
          <meshBasicMaterial color="#7c3aed" wireframe transparent opacity={0.14} />
        </mesh>
        <mesh>
          <ringGeometry args={[5.6, 5.7, 64]} />
          <meshBasicMaterial color="#67e8f9" transparent opacity={0.32} />
        </mesh>
        <mesh>
          <ringGeometry args={[4.0, 4.1, 32]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.25} />
        </mesh>
        <mesh>
          <ringGeometry args={[1.6, 1.65, 16]} />
          <meshBasicMaterial color="#67e8f9" transparent opacity={0.4} />
        </mesh>
      </group>

      <Text position={[0, -5.5, 0]} fontSize={1.05} color="#e5faff" anchorX="center" anchorY="middle">
        ECHO CORE
      </Text>
    </group>
  );
}

function HolographicBuilding({
  color,
  selected,
  hovered,
  index = 0,
}: {
  color: string;
  selected: boolean;
  hovered: boolean;
  index?: number;
}) {
  const ref = useRef<THREE.Group>(null);
  const scanLineRef = useRef<THREE.Mesh>(null);
  const pulseRingRef = useRef<THREE.Mesh>(null);
  const dataParticlesRef = useRef<THREE.Group>(null);
  const scaleVal = useRef<number>(1.0);

  useFrame((state, delta) => {
    const targetScale = selected ? 1.25 : hovered ? 1.15 : 1.0;
    scaleVal.current = THREE.MathUtils.lerp(scaleVal.current, targetScale, 10 * delta);

    if (ref.current) {
      ref.current.scale.setScalar(scaleVal.current);
      const bobOffset = index * 0.37;
      ref.current.position.y = Math.sin(state.clock.elapsedTime * 1.2 + bobOffset) * 0.12;
    }

    const bHeight = selected ? 3.2 : 2.2;

    if (scanLineRef.current) {
      const speed = 1.3;
      scanLineRef.current.position.y = (state.clock.elapsedTime * speed) % bHeight;
    }

    if (pulseRingRef.current) {
      const t = (state.clock.elapsedTime * 1.4 + index * 0.2) % 1.0;
      pulseRingRef.current.scale.set(0.6 + t * 2.2, 0.6 + t * 2.2, 1);
      if (pulseRingRef.current.material && !Array.isArray(pulseRingRef.current.material)) {
        const mat = pulseRingRef.current.material as THREE.MeshBasicMaterial;
        mat.opacity = (1.0 - t) * (selected ? 0.95 : hovered ? 0.75 : 0.3);
      }
    }

    if (dataParticlesRef.current) {
      dataParticlesRef.current.children.forEach((child, idx) => {
        const t = (state.clock.elapsedTime * 0.75 + idx * 0.33 + index * 0.12) % 1.0;
        child.position.y = 0.4 + t * 3.4;
        const spread = 0.22;
        child.position.x = Math.sin(t * Math.PI * 2 + idx) * spread;
        child.position.z = Math.cos(t * Math.PI * 2 + idx) * spread;
        if (child instanceof THREE.Mesh && child.material && !Array.isArray(child.material)) {
          const mat = child.material as THREE.MeshBasicMaterial;
          mat.opacity = (1.0 - t) * (selected || hovered ? 0.85 : 0.35);
        }
      });
    }
  });

  const bHeight = selected ? 3.2 : 2.2;

  return (
    <group ref={ref}>
      {/* Semi-transparent solid building shape */}
      <mesh position={[0, bHeight / 2, 0]}>
        <boxGeometry args={[1.1, bHeight, 1.1]} />
        <meshStandardMaterial
          color="#050608"
          emissive={color}
          emissiveIntensity={selected ? 1.6 : hovered ? 1.1 : 0.42}
          transparent
          opacity={0.8}
        />
      </mesh>

      {/* Outer wireframe layer */}
      <mesh position={[0, bHeight / 2, 0]}>
        <boxGeometry args={[1.16, bHeight + 0.04, 1.16]} />
        <meshStandardMaterial
          color={color}
          wireframe
          transparent
          opacity={selected ? 0.65 : hovered ? 0.48 : 0.18}
        />
      </mesh>

      {/* Roof detail */}
      <mesh position={[0, bHeight + 0.55, 0]}>
        <coneGeometry args={[0.9, 1.1, 4]} />
        <meshStandardMaterial
          color="#090b12"
          emissive={color}
          emissiveIntensity={selected ? 1.8 : hovered ? 1.2 : 0.48}
          transparent
          opacity={0.75}
        />
      </mesh>

      {/* Holographic moving scanline */}
      <mesh ref={scanLineRef} position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[1.22, 1.22]} />
        <meshBasicMaterial color={color} transparent opacity={selected || hovered ? 0.85 : 0.3} side={THREE.DoubleSide} />
      </mesh>

      {/* Horizontal glowing details */}
      {[-0.38, 0, 0.38].map((x) => (
        <mesh key={x} position={[x, bHeight / 2, 0.59]}>
          <boxGeometry args={[0.1, bHeight * 0.85, 0.02]} />
          <meshBasicMaterial color={color} transparent opacity={selected || hovered ? 0.9 : 0.4} />
        </mesh>
      ))}

      {/* Expanding pulse ring at base */}
      <mesh ref={pulseRingRef} position={[0, 0.05, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.8, 0.9, 24]} />
        <meshBasicMaterial color={color} transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>

      {/* Rising data particles */}
      <group ref={dataParticlesRef}>
        {Array.from({ length: 3 }).map((_, idx) => (
          <mesh key={idx}>
            <sphereGeometry args={[0.07, 8, 8]} />
            <meshBasicMaterial color={color} transparent opacity={0} />
          </mesh>
        ))}
      </group>

      {/* Vertical selected laser beam */}
      {selected && (
        <mesh position={[0, 10, 0]}>
          <cylinderGeometry args={[0.02, 0.45, 20, 16, 1, true]} />
          <meshBasicMaterial color={color} transparent opacity={0.25} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

function Pulse({ points, color, offset }: { points: THREE.Vector3[]; color: string; offset: number }) {
  const ref = useRef<THREE.Mesh>(null);

  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3(points);
  }, [points]);

  useFrame((state) => {
    const t = (state.clock.elapsedTime * 0.28 + offset) % 1.0;
    const point = curve.getPointAt(t);
    if (ref.current) {
      ref.current.position.copy(point);
      const pulseScale = 1.0 + Math.sin(state.clock.elapsedTime * 4.5) * 0.22;
      ref.current.scale.setScalar(pulseScale);
    }
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.22, 12, 12]} />
      <meshBasicMaterial color={color} transparent opacity={0.88} />
    </mesh>
  );
}

function LinkConnection({
  from,
  to,
  active,
  strength,
  color,
  index,
}: {
  from: THREE.Vector3;
  to: THREE.Vector3;
  active: boolean;
  strength: number;
  color: string;
  index: number;
}) {
  const lineRef = useRef<any>(null);

  const points = useMemo(() => {
    if (active) {
      const mid = new THREE.Vector3().addVectors(from, to).multiplyScalar(0.5);
      const dist = from.distanceTo(to);
      mid.y += dist * 0.12 + 1.6;
      const curve = new THREE.QuadraticBezierCurve3(from, mid, to);
      return curve.getPoints(24);
    }
    return [from, to];
  }, [from, to, active]);

  useFrame((state) => {
    if (lineRef.current && lineRef.current.material) {
      const pulse = 0.5 + Math.sin(state.clock.elapsedTime * 2.5 + index * 0.4) * 0.25;
      lineRef.current.material.opacity = active ? (0.22 + pulse * 0.32) * strength : 0.08 + pulse * 0.04;
    }
  });

  return (
    <>
      <Line
        ref={lineRef}
        points={points}
        color={active ? color : "#486174"}
        lineWidth={active ? strength * 1.8 : strength * 0.6}
        transparent
        opacity={active ? 0.4 : 0.1}
      />
      {active && (
        <>
          {/* Subtle glowing endpoints */}
          <mesh position={from}>
            <sphereGeometry args={[0.24, 8, 8]} />
            <meshBasicMaterial color={color} transparent opacity={0.65} />
          </mesh>
          <mesh position={to}>
            <sphereGeometry args={[0.24, 8, 8]} />
            <meshBasicMaterial color={color} transparent opacity={0.65} />
          </mesh>
          {/* Flowing energy pulse */}
          <Pulse points={points} color={color} offset={(index % 4) / 4} />
        </>
      )}
    </>
  );
}

function EchoBrainCluster({ project }: { project: Project }) {
  const color = themeFor(project.district).color;
  const group = useRef<THREE.Group>(null);
  const sections = ["Overview", "Timeline", "Founder", "Technology", "Community", "Roadmap", "Failures", "AI Suggestions", "Revive"];

  useFrame((state) => {
    if (group.current) {
      group.current.rotation.y = state.clock.elapsedTime * 0.22;
      group.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.12) * 0.05;
    }
  });

  const nodePositions = useMemo(() => {
    const positions: THREE.Vector3[] = [new THREE.Vector3(0, 0, 0)];
    for (let i = 1; i <= 8; i++) {
      const phi = Math.acos(-1 + (2 * (i - 1)) / 8);
      const theta = Math.sqrt(8 * Math.PI) * phi;
      const radius = 3.8;
      positions.push(
        new THREE.Vector3(
          Math.cos(theta) * Math.sin(phi) * radius,
          Math.sin(theta) * Math.sin(phi) * radius * 0.85,
          Math.cos(phi) * radius
        )
      );
    }
    return positions;
  }, []);

  const connections = useMemo(() => {
    const list: Array<{ from: number; to: number }> = [];
    for (let i = 1; i <= 8; i++) {
      list.push({ from: 0, to: i });
    }
    for (let i = 1; i <= 8; i++) {
      const next = i === 8 ? 1 : i + 1;
      list.push({ from: i, to: next });
    }
    return list;
  }, []);

  return (
    <group ref={group} position={[0, 10, 0]}>
      {connections.map((conn, index) => {
        const fromPos = nodePositions[conn.from];
        const toPos = nodePositions[conn.to];
        return (
          <React.Fragment key={index}>
            <Line
              points={[fromPos, toPos]}
              color={color}
              lineWidth={1.25}
              transparent
              opacity={0.38}
            />
            <ClusterSynapse from={fromPos} to={toPos} color={color} offset={(index % 4) * 0.25} />
          </React.Fragment>
        );
      })}

      {nodePositions.map((pos, i) => {
        const label = sections[i] || "Node";
        const isCenter = i === 0;

        return (
          <group key={i} position={pos}>
            {isCenter ? (
              <>
                <mesh>
                  <sphereGeometry args={[0.9, 24, 24]} />
                  <meshStandardMaterial color="#090b12" emissive="#67e8f9" emissiveIntensity={2.2} />
                </mesh>
                <mesh scale={1.15}>
                  <icosahedronGeometry args={[0.9, 1]} />
                  <meshStandardMaterial color="#67e8f9" emissive="#67e8f9" emissiveIntensity={1.3} wireframe transparent opacity={0.6} />
                </mesh>
              </>
            ) : (
              <>
                <mesh>
                  <sphereGeometry args={[0.4, 16, 16]} />
                  <meshStandardMaterial color="#090b12" emissive={color} emissiveIntensity={1.45} />
                </mesh>
                <mesh scale={1.25}>
                  <sphereGeometry args={[0.4, 8, 8]} />
                  <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} wireframe transparent opacity={0.5} />
                </mesh>
              </>
            )}

            <Html center distanceFactor={isCenter ? 14 : 16} position={[0, isCenter ? -1.4 : -0.7, 0]}>
              <div
                className={`pointer-events-none select-none rounded border bg-black/90 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider shadow-lg backdrop-blur-md whitespace-nowrap ${
                  isCenter
                    ? "border-cyan-400/40 text-cyan-200 shadow-cyan-500/10 text-[10px] font-bold"
                    : "border-white/10 text-slate-300"
                }`}
                style={isCenter ? {} : { borderColor: `${color}30` }}
              >
                {label}
              </div>
            </Html>
          </group>
        );
      })}

      <Html center distanceFactor={18} position={[0, -4.5, 0]}>
        <div className="pointer-events-none select-none text-center whitespace-nowrap">
          <h2 className="text-xl font-bold tracking-[0.15em] text-white uppercase drop-shadow-[0_0_12px_rgba(255,255,255,0.45)]">
            {project.name}
          </h2>
          <p className="mt-1 font-mono text-[9px] tracking-widest text-cyan-400/80 uppercase">
            {project.district} / ECHO NEURAL CLUSTER
          </p>
        </div>
      </Html>
    </group>
  );
}

function ClusterSynapse({ from, to, color, offset }: { from: THREE.Vector3; to: THREE.Vector3; color: string; offset: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    const t = (state.clock.elapsedTime * 0.52 + offset) % 1.0;
    const pos = new THREE.Vector3().lerpVectors(from, to, t);
    if (ref.current) {
      ref.current.position.copy(pos);
    }
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.075, 8, 8]} />
      <meshBasicMaterial color={color} transparent opacity={0.92} />
    </mesh>
  );
}

function ProjectNetworkNode({
  project,
  position,
  selected,
  setSelectedProject,
  index = 0,
}: {
  project: Project;
  position: THREE.Vector3;
  selected: boolean;
  setSelectedProject: (project: Project | null) => void;
  index?: number;
}) {
  const [hovered, setHovered] = useState(false);
  const theme = themeFor(project.district);

  // Curved line to center core
  const linePoints = useMemo(() => {
    const mid = new THREE.Vector3().copy(position).multiplyScalar(0.5);
    mid.y += 2.0;
    return [new THREE.Vector3(0, 0, 0), mid, position];
  }, [position]);

  return (
    <group
      position={position}
      onPointerOver={(event) => {
        event.stopPropagation();
        setHovered(true);
      }}
      onPointerOut={() => setHovered(false)}
      onClick={(event) => {
        event.stopPropagation();
        setSelectedProject(project);
      }}
    >
      <Line
        points={linePoints}
        color={selected ? theme.color : "#486174"}
        lineWidth={selected ? 1.5 : 0.8}
        transparent
        opacity={selected ? 0.76 : hovered ? 0.35 : 0.08}
      />
      <HolographicBuilding color={theme.color} selected={selected} hovered={hovered} index={index} />
      {(selected || hovered) && (
        <Html center distanceFactor={selected ? 26 : 38} position={[0, selected ? 4.8 : 3.4, 0]}>
          <div className="pointer-events-none whitespace-nowrap rounded border border-white/10 bg-black/75 px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest text-white shadow-[0_0_18px_rgba(34,211,238,0.22)] backdrop-blur-sm">
            <span style={{ color: theme.color }}>{project.district}</span> / {project.name}
          </div>
        </Html>
      )}
    </group>
  );
}

function NetworkScene({
  projects,
  selectedProject,
  setSelectedProject,
  viewMode,
}: {
  projects: Project[];
  selectedProject: Project | null;
  setSelectedProject: (project: Project | null) => void;
  viewMode: "network" | "echo";
}) {
  const positions = useMemo(() => new Map(projects.map((project, index) => [project.id, projectPosition(project, index, projects)])), [projects]);
  const visibleProjects = projects.slice(0, 56);

  const controlsRef = useRef<CameraControls>(null);
  const sceneGroupRef = useRef<THREE.Group>(null);

  useEffect(() => {
    if (controlsRef.current) {
      if (selectedProject) {
        controlsRef.current.setLookAt(
          0, 15, 18,
          0, 9, 0,
          true
        );
      } else {
        controlsRef.current.setLookAt(
          0, 34, 48,
          0, 0, 0,
          true
        );
      }
    }
  }, [selectedProject]);

  useFrame((state, delta) => {
    if (sceneGroupRef.current) {
      if (!selectedProject) {
        sceneGroupRef.current.rotation.y = state.clock.elapsedTime * 0.025;
      } else {
        sceneGroupRef.current.rotation.y = THREE.MathUtils.lerp(sceneGroupRef.current.rotation.y, 0, 4 * delta);
      }
    }
  });

  const links = useMemo(() => {
    const pairs: Array<{ a: Project; b: Project; active: boolean; strength: number }> = [];
    visibleProjects.forEach((project, index) => {
      const sameDistrict = visibleProjects.find((item) => item.id !== project.id && item.district === project.district);
      if (sameDistrict && index % 2 === 0) {
        pairs.push({
          a: project,
          b: sameDistrict,
          active: index % 6 === 0,
          strength: 1.5 + (index % 3) * 0.5
        });
      }
      if (index % 9 === 0 && visibleProjects[index + 5]) {
        pairs.push({
          a: project,
          b: visibleProjects[index + 5],
          active: true,
          strength: 2.0
        });
      }
    });
    return pairs.slice(0, 34);
  }, [visibleProjects]);

  const ambientParticlesRef = useRef<THREE.Points>(null);
  const ambientParticleCount = 450;
  const ambientPositions = useMemo(() => {
    const arr = new Float32Array(ambientParticleCount * 3);
    for (let i = 0; i < ambientParticleCount; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 140;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 100;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 140;
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (ambientParticlesRef.current) {
      ambientParticlesRef.current.rotation.y = state.clock.elapsedTime * 0.01;
      ambientParticlesRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.003) * 0.03;
    }
  });

  return (
    <>
      <color attach="background" args={["#020308"]} />

      <hemisphereLight args={["#1b1c3a", "#020308", 0.95]} />
      <directionalLight position={[0, 35, 10]} intensity={1.5} color="#f1f5f9" />
      <pointLight position={[30, 15, 20]} intensity={25} color="#06b6d4" />
      <pointLight position={[-30, -5, -25]} intensity={18} color="#a855f7" />
      <pointLight position={[5, -20, 30]} intensity={12} color="#ec4899" />

      <fog attach="fog" args={["#020308", 25, 110]} />
      <Stars radius={110} depth={40} count={900} factor={4} saturation={0.5} fade speed={1.2} />

      <points ref={ambientParticlesRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[ambientPositions, 3]} />
        </bufferGeometry>
        <pointsMaterial color="#67e8f9" size={0.14} transparent opacity={0.45} sizeAttenuation />
      </points>

      <group ref={sceneGroupRef}>
        <EchoCore />

        {links.map((link, index) => {
          const a = positions.get(link.a.id) || new THREE.Vector3();
          const b = positions.get(link.b.id) || new THREE.Vector3();
          const theme = themeFor(link.a.district);
          return (
            <LinkConnection
              key={`${link.a.id}-${link.b.id}-${index}`}
              from={a}
              to={b}
              active={link.active}
              strength={link.strength}
              color={theme.color}
              index={index}
            />
          );
        })}

        {visibleProjects.map((project, idx) => {
          const pos = positions.get(project.id) || new THREE.Vector3();
          const selected = selectedProject?.id === project.id;
          return (
            <ProjectNetworkNode
              key={project.id}
              project={project}
              position={pos}
              selected={selected}
              setSelectedProject={setSelectedProject}
              index={idx}
            />
          );
        })}
      </group>

      {(viewMode === "echo" || selectedProject) && selectedProject && (
        <EchoBrainCluster project={selectedProject} />
      )}

      <CameraControls ref={controlsRef} makeDefault minDistance={14} maxDistance={90} dollySpeed={0.6} />

      <EffectComposer>
        <Bloom intensity={1.15} luminanceThreshold={0.15} luminanceSmoothing={0.65} />
        <Vignette eskil={false} offset={0.28} darkness={0.8} />
      </EffectComposer>
    </>
  );
}

export function Network3D({
  aliveProjects,
  deadProjects,
  selectedProject,
  setSelectedProject,
  viewMode = "network",
}: {
  aliveProjects: Project[];
  deadProjects: Project[];
  selectedProject: Project | null;
  setSelectedProject: (project: Project | null) => void;
  viewMode?: "network" | "echo";
}) {
  const [hintDismissed, setHintDismissed] = useState(false);
  const projects = useMemo(() => [...aliveProjects, ...deadProjects], [aliveProjects, deadProjects]);

  return (
    <div
      className="relative h-full min-h-[620px] overflow-hidden"
      style={{ background: "radial-gradient(circle at center, #090a18 0%, #010204 100%)" }}
    >
      <Canvas camera={{ position: [0, 34, 48], fov: 52 }} gl={{ antialias: true, alpha: true }}>
        <NetworkScene projects={projects} selectedProject={selectedProject} setSelectedProject={setSelectedProject} viewMode={viewMode} />
      </Canvas>
      {!hintDismissed && (
        <button
          onClick={() => setHintDismissed(true)}
          className="absolute bottom-5 left-1/2 z-20 -translate-x-1/2 rounded border border-cyan-400/25 bg-black/70 px-4 py-2 text-[10px] font-mono uppercase tracking-[0.2em] text-cyan-100 backdrop-blur transition hover:border-cyan-300/60 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
        >
          Click nodes to unfold Echo Brain
        </button>
      )}
    </div>
  );
}
