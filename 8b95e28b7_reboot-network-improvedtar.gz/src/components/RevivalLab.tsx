import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Idea } from '../lib/firebase';
import { Heart, ShieldAlert, Zap } from 'lucide-react';
import { db } from '../lib/firebase';
import { doc, updateDoc, increment } from 'firebase/firestore';

const MONO = "'Share Tech Mono', monospace";

type SystemStats = { energy: number; stability: number; logic: number; community: number; };

export default function RevivalLab({ idea, onComplete }: { idea: Idea; onComplete: () => void }) {
  const [phase, setPhase] = useState<'intro' | 'lab' | 'success'>('intro');
  const [stats, setStats] = useState<SystemStats>({ energy: 24, stability: 18, logic: 6, community: 41 });
  const difficulty = Math.max(0.4, 1 - ((idea.upvotes || 0) / 100));
  const [activeTask, setActiveTask] = useState<'none' | 'virus' | 'energy' | 'circuit' | 'memory' | 'sort'>('none');

  useEffect(() => {
    if (phase === 'intro') {
      setTimeout(() => setPhase('lab'), 2000);
    }
  }, [phase]);

  // Check win condition
  useEffect(() => {
    if (phase === "lab") {
      if (stats.energy >= 100 && stats.stability >= 100 && stats.logic >= 100 && stats.community >= 100) {
        setPhase("flatline");
        setActiveTask("none");
      }
    }
  }, [stats, phase]);

  useEffect(() => {
    if (phase === "flatline") {
      let beats = 0;
      const t = setInterval(() => {
        if (beats < 3) {
          audioManager.play("select");
          beats++;
        }
      }, 1000);
      setTimeout(() => { clearInterval(t); setPhase("success"); }, 4000);
      return () => clearInterval(t);
    }
  }, [phase]);

  useEffect(() => {
    if (phase === "success") {
      updateDoc(doc(db, "ideas", idea.id), {
        status: "reviving",
        revival_count: increment(1)
      }).catch(console.error);
      setTimeout(onComplete, 6000);
    }
  }, [phase, idea.id, onComplete]);
  // Task Spawner
  useEffect(() => {
    if (phase !== 'lab') return;
    if (activeTask !== 'none') return;

    const t = setTimeout(() => {
      const tasks = ['virus', 'circuit', 'memory', 'energy'];
      const next = tasks[Math.floor(Math.random() * tasks.length)] as "virus" | "circuit" | "memory" | "energy";
      setActiveTask(next);
    }, 1500);
    return () => clearTimeout(t);
  }, [phase, activeTask]);

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 10000,
      background: '#0B0B0B', color: '#00E5FF', fontFamily: MONO,
      overflow: 'hidden', display: 'flex', flexDirection: 'column'
    }}>
      <AnimatePresence>
        {phase === 'intro' && (
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 3, opacity: 0, filter: 'blur(20px)' }}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
            style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >
            <div style={{ width: 100, height: 100, borderRadius: '50%', background: '#00E5FF', filter: 'blur(20px)' }} />
          </motion.div>
        )}
      </AnimatePresence>

      {phase !== 'intro' && (
        <>
          <div style={{ position: 'absolute', top: 24, right: 32, zIndex: 20, textAlign: 'right' }}>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: '0.1em' }}>PROJECTS REVIVED TODAY</div>
            <div style={{ color: '#00E5FF', fontSize: 20, fontWeight: 'bold' }}>2,483</div>
          </div>
          <div style={{ padding: '24px', textAlign: 'center', zIndex: 10 }}>
            <motion.h1 
              initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
              style={{ fontSize: 24, color: '#fff', margin: 0, letterSpacing: '0.1em' }}
            >
              {idea.title}
            </motion.h1>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} style={{ fontSize: 12, color: 'rgba(0, 229, 255, 0.5)' }}>
              REVIVAL LAB INITIALIZED
            </motion.div>
          </div>

          <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Core phase={phase} />
            <AnimatePresence>
              {activeTask === "virus" && <VirusTask onComplete={() => { setStats(s => ({...s, stability: Math.min(100, s.stability + 30 * difficulty)})); setActiveTask("none"); }} />}
              {activeTask === "circuit" && <CircuitTask onComplete={() => { setStats(s => ({...s, logic: Math.min(100, s.logic + 35 * difficulty)})); setActiveTask("none"); }} />}
              {activeTask === "memory" && <MemoryTask onComplete={() => { setStats(s => ({...s, community: Math.min(100, s.community + 30 * difficulty)})); setActiveTask("none"); }} />}
              {activeTask === "energy" && <EnergyTask onComplete={() => { setStats(s => ({...s, energy: Math.min(100, s.energy + 35 * difficulty)})); setActiveTask("none"); }} />}
            </AnimatePresence>
          </div>

          <div style={{ 
            padding: '24px 40px', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(16px)',
            borderTop: '1px solid rgba(0, 229, 255, 0.1)', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24, zIndex: 10
          }}>
            <StatBar label="Energy" value={stats.energy} color="#00E5FF" />
            <StatBar label="Stability" value={stats.stability} color="#8B5CF6" />
            <StatBar label="Logic" value={stats.logic} color="#22FF88" />
            <StatBar label="Community" value={stats.community} color="#FF3B5C" />
          </div>
        </>
      )}

      <AnimatePresence>
        {phase === 'success' && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 2 }}
            style={{ position: 'absolute', inset: 0, background: 'rgba(0, 229, 255, 0.1)', zIndex: 50, pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 2, duration: 1 }}
              style={{ fontSize: 48, color: '#fff', textShadow: '0 0 30px #00E5FF', fontWeight: 'bold' }}
            >
              PROJECT REBOOTED
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatBar({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 12 }}>
        <span style={{ color: 'rgba(255,255,255,0.7)' }}>{label}</span>
        <span style={{ color }}>{Math.floor(value)}%</span>
      </div>
      <div style={{ height: 4, background: 'rgba(255,255,255,0.1)', borderRadius: 2, overflow: 'hidden' }}>
        <motion.div 
          initial={{ width: 0 }} animate={{ width: `${value}%` }}
          style={{ height: '100%', background: color, boxShadow: `0 0 10px ${color}` }}
        />
      </div>
    </div>
  );
}

function Core({ phase }: { phase: string }) {
  const isFlatline = phase === "flatline";
  const isSuccess = phase === "success";

  return (
    <motion.div 
      style={{ position: "relative", width: 200, height: 200, display: "flex", alignItems: "center", justifyContent: "center" }}
      animate={isSuccess ? { scale: [1, 1.2, 1], filter: "brightness(2)" } : (isFlatline ? { scale: [1, 1.3, 1] } : {})}
      transition={
        isSuccess ? { duration: 1, repeat: Infinity } : 
        (isFlatline ? { duration: 1, repeat: 3, repeatDelay: 1 } : {})
      }
    >
      {[1, 2, 3].map(i => (
        <motion.div
          key={i}
          animate={{ rotate: isFlatline ? 0 : (i % 2 === 0 ? 360 : -360) }}
          transition={{ duration: 10 * i, ease: "linear", repeat: Infinity }}
          style={{
            position: "absolute", inset: -20 * i,
            border: `1px ${phase === "lab" ? "dashed" : "solid"} rgba(0, 229, 255, ${isFlatline ? 0.05 : (0.1 + i * 0.1)})`,
            borderRadius: "50%",
            borderColor: isSuccess ? "#00E5FF" : (phase === "lab" ? "rgba(255, 59, 92, 0.5)" : "#00E5FF")
          }}
        />
      ))}
      <motion.div
        animate={
          isFlatline ? { scale: [1, 1.2, 1], boxShadow: ["none", "0 0 50px rgba(255,0,0,0.8)", "none"] } :
          (phase === "lab" ? { 
            scale: [1, 1.05, 1],
            boxShadow: ["0 0 20px rgba(255,59,92,0.2)", "0 0 40px rgba(255,59,92,0.6)", "0 0 20px rgba(255,59,92,0.2)"]
          } : {
            scale: [1, 1.1, 1],
            boxShadow: ["0 0 40px rgba(0,229,255,0.4)", "0 0 80px rgba(0,229,255,0.8)", "0 0 40px rgba(0,229,255,0.4)"]
          })
        }
        transition={
          isFlatline ? { duration: 1, repeat: 3, repeatDelay: 1 } :
          { duration: phase === "lab" ? 2 : 1, repeat: Infinity, ease: "easeInOut" }
        }
        style={{
          width: 120, height: 120, borderRadius: "50%",
          background: isFlatline ? "#000" : (isSuccess ? "radial-gradient(circle, #fff 0%, #00E5FF 50%, transparent 100%)" : "radial-gradient(circle, #FF3B5C 0%, transparent 70%)"),
          display: "flex", alignItems: "center", justifyContent: "center"
        }}
      >
        <motion.div animate={isFlatline ? { scale: [1, 1.3, 1] } : {}} transition={isFlatline ? { duration: 1, repeat: 3, repeatDelay: 1 } : {}}>
          <Heart size={32} color={isFlatline ? "#FF3B5C" : (isSuccess ? "#fff" : "rgba(255,255,255,0.5)")} />
        </motion.div>
      </motion.div>
    </motion.div>
  );
}

function VirusTask({ onComplete }: { onComplete: () => void }) {
  const [viruses, setViruses] = useState([1, 2, 3]);
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', top: 40, left: 0, right: 0, textAlign: 'center', color: '#FF3B5C', fontSize: 14 }}>DESTROY CORRUPTION</div>
      <AnimatePresence>
        {viruses.map(v => (
          <motion.div
            key={v}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1, x: Math.random() * 400 - 200, y: Math.random() * 400 - 200 }}
            exit={{ opacity: 0, scale: 2 }}
            style={{
              position: 'absolute', top: '50%', left: '50%',
              width: 30, height: 30, background: '#FF3B5C',
              border: '2px solid #fff', cursor: 'crosshair', pointerEvents: 'auto',
              boxShadow: '0 0 15px #FF3B5C', display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}
            onClick={() => {
              setViruses(curr => {
                const next = curr.filter(id => id !== v);
                if (next.length === 0) setTimeout(onComplete, 500);
                return next;
              });
            }}
          >
            <ShieldAlert size={16} color="#fff" />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

function CircuitTask({ onComplete }: { onComplete: () => void }) {
  return (
    <div style={{ position: 'absolute', bottom: 100, left: '50%', transform: 'translateX(-50%)', width: 300 }}>
      <div style={{ textAlign: 'center', color: '#22FF88', marginBottom: 12 }}>REPAIR CIRCUIT (DRAG)</div>
      <div style={{ height: 4, background: 'rgba(255,255,255,0.1)', position: 'relative' }}>
        <motion.div
          drag="x" dragConstraints={{ left: 0, right: 280 }} dragElastic={0} dragMomentum={false}
          onDrag={(e, info) => {
            if (info.point.x > window.innerWidth / 2 + 100) onComplete();
          }}
          style={{
            position: 'absolute', top: -10, left: 0,
            width: 24, height: 24, background: '#22FF88',
            borderRadius: '50%', cursor: 'grab', boxShadow: '0 0 10px #22FF88'
          }}
        />
        <div style={{ position: 'absolute', right: 0, top: -6, width: 16, height: 16, border: '2px solid #22FF88', borderRadius: '50%' }} />
      </div>
    </div>
  );
}

function MemoryTask({ onComplete }: { onComplete: () => void }) {
  const colors = ['#00E5FF', '#8B5CF6', '#22FF88', '#FF3B5C'];
  const [sequence, setSequence] = useState<number[]>([]);
  const [playerSeq, setPlayerSeq] = useState<number[]>([]);
  const [showing, setShowing] = useState(true);
  const [activeIdx, setActiveIdx] = useState<number | null>(null);

  useEffect(() => {
    const seq = [Math.floor(Math.random()*4), Math.floor(Math.random()*4), Math.floor(Math.random()*4)];
    setSequence(seq);
    let i = 0;
    const interval = setInterval(() => {
      if (i < seq.length) {
        setActiveIdx(seq[i]);
        setTimeout(() => setActiveIdx(null), 400);
        i++;
      } else { setShowing(false); clearInterval(interval); }
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const handleClick = (idx: number) => {
    if (showing) return;
    const newSeq = [...playerSeq, idx];
    setPlayerSeq(newSeq);
    if (newSeq[newSeq.length - 1] !== sequence[newSeq.length - 1]) {
      setPlayerSeq([]); setShowing(true);
      let i = 0;
      const interval = setInterval(() => {
        if (i < sequence.length) {
          setActiveIdx(sequence[i]); setTimeout(() => setActiveIdx(null), 400); i++;
        } else { setShowing(false); clearInterval(interval); }
      }, 800);
    } else if (newSeq.length === sequence.length) { onComplete(); }
  };

  return (
    <div style={{ position: 'absolute', top: 100, display: 'flex', gap: 16, left: '50%', transform: 'translateX(-50%)' }}>
      {colors.map((c, i) => (
        <motion.div
          key={i} animate={{ scale: activeIdx === i ? 1.2 : 1, opacity: activeIdx === i ? 1 : 0.5 }}
          style={{ width: 60, height: 60, background: c, borderRadius: 12, cursor: showing ? 'default' : 'pointer' }}
          onClick={() => handleClick(i)}
        />
      ))}
    </div>
  );
}

function EnergyTask({ onComplete }: { onComplete: () => void }) {
  const [charge, setCharge] = useState(0);
  const [charging, setCharging] = useState(false);

  useEffect(() => {
    let t: NodeJS.Timeout;
    if (charging) {
      t = setInterval(() => {
        setCharge(c => {
          if (c >= 100) { clearInterval(t); onComplete(); return 100; }
          return c + 2;
        });
      }, 50);
    }
    return () => clearInterval(t);
  }, [charging, onComplete]);

  return (
    <div style={{ position: 'absolute', bottom: 120, left: '50%', transform: 'translateX(-50%)', width: 200, textAlign: 'center' }}>
      <div style={{ color: '#00E5FF', marginBottom: 12 }}>HOLD TO CHARGE</div>
      <div 
        onMouseDown={() => setCharging(true)} onMouseUp={() => setCharging(false)} onMouseLeave={() => setCharging(false)}
        style={{ 
          width: 80, height: 80, margin: '0 auto', borderRadius: '50%', 
          background: charging ? '#00E5FF' : 'transparent', border: '2px solid #00E5FF', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}
      >
        <Zap color={charging ? '#000' : '#00E5FF'} />
      </div>
      <div style={{ height: 4, background: 'rgba(255,255,255,0.1)', marginTop: 12 }}>
        <div style={{ height: '100%', background: '#00E5FF', width: `${charge}%` }} />
      </div>
    </div>
  );
}
