import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { audioManager } from '../lib/audio';

export default function FirstLaunch({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<'black' | 'text' | 'dots' | 'heartbeat_1' | 'heartbeat_2' | 'heartbeat_3' | 'glitch' | 'done'>('black');

  useEffect(() => {
    
    const runSequence = async () => {
      // Black screen
      await new Promise(r => setTimeout(r, 1500));
      setPhase('text'); // "No idea is ever truly dead."
      
      await new Promise(r => setTimeout(r, 4000));
      setPhase('dots'); // ... .. .
      
      await new Promise(r => setTimeout(r, 3000));
      setPhase('heartbeat_1'); // ❤️ ...thump...
      audioManager.play('select'); // temp sound
      
      await new Promise(r => setTimeout(r, 3500));
      setPhase('heartbeat_2'); // light appears
      audioManager.play('select');
      
      await new Promise(r => setTimeout(r, 2000));
      setPhase('heartbeat_3'); // loud thump
      audioManager.play('select');
      await new Promise(r => setTimeout(r, 800));
      audioManager.play('select');
      await new Promise(r => setTimeout(r, 800));
      audioManager.play('select');
      
      await new Promise(r => setTimeout(r, 1000));
      setPhase('glitch');
      
      await new Promise(r => setTimeout(r, 500));
      setPhase('done');
      onComplete();
    };

    runSequence();
  }, [onComplete]);

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 10000,
      background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#fff', fontFamily: "'Inter', sans-serif"
    }}>
      <AnimatePresence>
        {phase === 'text' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2 }}
            style={{ fontSize: 24, letterSpacing: '0.05em', color: 'rgba(255,255,255,0.8)' }}
          >
            No idea is ever truly dead.
          </motion.div>
        )}
        
        {phase === 'dots' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            style={{ fontSize: 24, letterSpacing: '0.2em', color: 'rgba(255,255,255,0.4)', fontFamily: 'monospace' }}
          >
            ...<br/>..<br/>.
          </motion.div>
        )}

        {phase === 'heartbeat_1' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            style={{ fontSize: 18, color: 'rgba(255,255,255,0.5)', fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 12 }}
          >
            <span style={{ fontSize: 24 }}>❤️</span> ...thump...
          </motion.div>
        )}

        {phase === 'heartbeat_2' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >
            <div style={{
              width: 10, height: 10, borderRadius: '50%', background: '#00FFFF',
              boxShadow: '0 0 20px 10px rgba(0, 255, 255, 0.4)',
              animation: 'heartbeat 1.5s infinite ease-in-out'
            }} />
          </motion.div>
        )}

        {phase === 'heartbeat_3' && (
          <motion.div
            style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20 }}
          >
            <div style={{
              width: 40, height: 40, borderRadius: '50%', background: '#00FFFF',
              boxShadow: '0 0 100px 40px rgba(0, 255, 255, 0.8)',
              animation: 'heartbeatFast 0.8s infinite ease-in-out'
            }} />
            <div style={{ fontSize: 32, fontFamily: 'monospace', fontWeight: 'bold', color: '#fff', textShadow: '0 0 10px #00FFFF', animation: 'heartbeatFast 0.8s infinite ease-in-out' }}>
              ❤️ THUMP
            </div>
          </motion.div>
        )}

        {phase === 'glitch' && (
          <div style={{
            position: 'absolute', inset: 0, background: '#00FFFF', mixBlendMode: 'difference',
            animation: 'glitch-flash 0.1s infinite'
          }} />
        )}
      </AnimatePresence>

      <style>{`
        @keyframes heartbeat {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50% { transform: scale(1.5); opacity: 1; }
        }
        @keyframes heartbeatFast {
          0%, 100% { transform: scale(1); opacity: 0.9; }
          20% { transform: scale(1.3); opacity: 1; }
        }
        @keyframes glitch-flash {
          0% { opacity: 0; }
          50% { opacity: 1; transform: translateX(-10px); }
          100% { opacity: 0; transform: translateX(10px); }
        }
      `}</style>
    </div>
  );
}
