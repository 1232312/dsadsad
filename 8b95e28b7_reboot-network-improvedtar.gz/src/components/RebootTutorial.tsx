import React, { useState, useEffect } from 'react';
import { Database, Target, Zap, Gift, ChevronRight, CheckCircle2, Power, BrainCircuit } from 'lucide-react';
import { motion } from 'framer-motion';

const steps = [
  {
    title: 'ECHO NEURAL LINK ESTABLISHED',
    desc: 'Welcome to the Graveyard. We are re-orienting your neural pathways to the Echo network. Do not be alarmed if you experience slight digital dissonance.',
    icon: <Database size={48} color="#00FFFF" />,
    color: '#00FFFF'
  },
  {
    title: 'THE LIVING IDEA',
    desc: 'Ideas here are not files—they are living organisms. They start as glowing seeds. As they gain upvotes and interest, they grow. When abandoned, they begin to die and fade into the background.',
    icon: <BrainCircuit size={48} color="#00FF88" />,
    color: '#00FF88'
  },
  {
    title: 'WHAT IS A REBOOT?',
    desc: 'A Reboot is a second chance at life. When you take over a dying or abandoned project, you breathe new life into it. Dead projects become active once again in the Resurrection queue.',
    icon: <Power size={48} color="#8B5CF6" />,
    color: '#8B5CF6'
  },
  {
    title: 'DREAM DIVING (THE NEXUS)',
    desc: 'Enter the Neural Network to see ideas mapped out as constellations. Explore the universe of projects based on their technology stacks and domains rather than scrolling lifeless lists.',
    icon: <Target size={48} color="#FF00CC" />,
    color: '#FF00CC'
  },
  {
    title: 'HEART SYNC & VITALITY',
    desc: 'Notice the Global Vitality HUD in the corner. Every active project contributes to the giant community heartbeat. When the community thrives, the pulse beats faster. Keep the network alive.',
    icon: <Zap size={48} color="#EAB308" />,
    color: '#EAB308'
  },
  {
    title: 'TUESDAY DROPS',
    desc: 'Every Tuesday, when the system reaches critical mass, the admin initiates a drop of resources. Look out for the floating gift icon to claim rewards!',
    icon: <Gift size={48} color="#10B981" />,
    color: '#10B981'
  }
];

export default function RebootTutorial({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [typing, setTyping] = useState('');

  useEffect(() => {
    let currentText = '';
    const fullText = steps[step].desc;
    let i = 0;
    
    setTyping('');
    
    const typeTimer = setInterval(() => {
      if (i < fullText.length) {
        currentText += fullText.charAt(i);
        setTyping(currentText);
        i++;
      } else {
        clearInterval(typeTimer);
      }
    }, 15);

    return () => {
      clearInterval(typeTimer);
    };
  }, [step]);

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(s => s + 1);
    } else {
      onComplete();
    }
  };

  const current = steps[step];

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'rgba(4, 4, 12, 0.95)', backdropFilter: 'blur(20px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#fff', fontFamily: 'monospace'
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at center, ${current.color}15 0%, transparent 60%)`,
        transition: 'background 0.5s ease',
        pointerEvents: 'none'
      }} />

      <motion.div 
        key={step}
        initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
        animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        style={{
          width: '100%', maxWidth: 640, padding: 48,
          background: 'rgba(10,10,20,0.7)', border: `1px solid ${current.color}44`,
          borderRadius: 24, position: 'relative',
          boxShadow: `0 20px 60px rgba(0,0,0,0.8), inset 0 0 40px ${current.color}11`
        }}
      >
        {/* Progress bar */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 40 }}>
          {steps.map((_, i) => (
            <div key={i} style={{
              flex: 1, height: 3, borderRadius: 2,
              background: i <= step ? current.color : 'rgba(255,255,255,0.1)',
              boxShadow: i === step ? `0 0 10px ${current.color}` : 'none',
              transition: 'all 0.4s ease'
            }} />
          ))}
        </div>

        <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start' }}>
          <div style={{
            width: 88, height: 88, borderRadius: 20,
            background: `${current.color}11`, border: `1px solid ${current.color}44`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `inset 0 0 20px ${current.color}22`,
            flexShrink: 0
          }}>
            <motion.div
              animate={{ rotate: [0, -5, 5, 0], scale: [1, 1.05, 1] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            >
              {current.icon}
            </motion.div>
          </div>

          <div style={{ flex: 1, minHeight: 140 }}>
            <motion.h2 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              style={{
                fontSize: 22, fontWeight: 700, color: current.color,
                letterSpacing: '0.12em', marginBottom: 16,
                textShadow: `0 0 15px ${current.color}66`,
                fontFamily: "'Share Tech Mono', monospace"
              }}
            >
              {current.title}
            </motion.h2>
            <p style={{
              fontSize: 15, color: 'rgba(255,255,255,0.8)',
              lineHeight: 1.7, minHeight: 80, fontFamily: 'Inter, sans-serif'
            }}>
              {typing}
              <motion.span 
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.8, repeat: Infinity, stepEnd: true }}
                style={{ color: current.color, fontWeight: 'bold' }}
              >
                _
              </motion.span>
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 40, alignItems: 'center' }}>
          <button 
            onClick={onComplete}
            style={{
              background: 'none', border: 'none', color: 'rgba(255,255,255,0.3)',
              fontFamily: 'monospace', fontSize: 12, cursor: 'pointer',
              letterSpacing: '0.1em', transition: 'color 0.2s', textDecoration: 'underline'
            }}
            onMouseEnter={e => e.currentTarget.style.color = 'rgba(255,255,255,0.7)'}
            onMouseLeave={e => e.currentTarget.style.color = 'rgba(255,255,255,0.3)'}
          >
            SKIP PROTOCOL
          </button>
          
          <button
            onClick={handleNext}
            style={{
              padding: '14px 28px', borderRadius: 12,
              background: `${current.color}15`, border: `1px solid ${current.color}55`,
              color: current.color, fontWeight: 700, letterSpacing: '0.1em',
              display: 'flex', alignItems: 'center', gap: 10,
              cursor: 'pointer', transition: 'all 0.2s', fontFamily: "'Share Tech Mono', monospace"
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = `${current.color}33`;
              e.currentTarget.style.boxShadow = `0 0 25px ${current.color}44`;
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = `${current.color}15`;
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            {step === steps.length - 1 ? (
              <>ENTER SYSTEM <CheckCircle2 size={18} /></>
            ) : (
              <>NEXT MODULE <ChevronRight size={18} /></>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
