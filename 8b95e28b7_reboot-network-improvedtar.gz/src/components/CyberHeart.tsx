import React, { useMemo, useEffect } from 'react';

let sharedAudioCtx: AudioContext | null = null;
const getAudioCtx = () => {
  if (typeof window === 'undefined') return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  return sharedAudioCtx;
};

interface CyberHeartProps {
  status: string;
  vitality: number;
  size?: number;
}

export default function CyberHeart({ status, vitality, size = 48 }: CyberHeartProps) {
  let color = '#FF00CC';
  let pulseDuration = '3s';
  let glowSize = '10px';
  
  const isGolden = status === 'revived';
  const isDead = status === 'abandoned';
  
  // Create a unique ID for gradients and filters
  const uid = useMemo(() => Math.random().toString(36).slice(2, 9), []);

  if (isDead && !isGolden) {
    color = '#4a4a5a'; // Dark gray
    pulseDuration = '6s';
    glowSize = '2px';
  } else if (isGolden) {
    color = '#FFE000';
    pulseDuration = '1.2s';
    glowSize = '25px';
  } else {
    if (vitality >= 1000) {
      color = '#00FFFF';
      pulseDuration = '0.8s';
      glowSize = '30px';
    } else if (vitality >= 100) {
      color = '#00FF88';
      pulseDuration = '1.2s';
      glowSize = '20px';
    } else if (vitality >= 10) {
      color = '#FF00CC';
      pulseDuration = '2s';
      glowSize = '12px';
    } else {
      color = '#888888';
      pulseDuration = '4s';
      glowSize = '5px';
    }
  }

  const animClass = isDead ? `cyber-glitch-${uid}` : `cyber-beat-${uid}`;
  const isHighEnergy = vitality >= 1000 || isGolden;
  
  const durationSec = parseFloat(pulseDuration.replace('s', ''));

  useEffect(() => {
    if (isDead) return;
    
    let timeoutId: ReturnType<typeof setTimeout>;

    const playThump = (freq = 55, duration = 0.15) => {
      try {
        const ctx = getAudioCtx();
        if (!ctx) return;
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }
        if (ctx.state !== 'running') return;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(10, ctx.currentTime + duration);

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + duration);
      } catch {
        // ignore
      }
    };

    const durationMs = durationSec * 1000;
    const beat2Delay = durationMs * 0.3; // matches the 30% mark in keyframes

    const loop = () => {
      playThump(55, 0.2);
      timeoutId = setTimeout(() => {
        playThump(65, 0.15);
      }, beat2Delay);
    };

    loop();
    const intervalId = setInterval(loop, durationMs);

    return () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
    };
  }, [isDead, durationSec]);

  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', width: size, height: size }}>
      
      {/* Pulse Rings */}
      {!isDead && (
        <div style={{
          position: 'absolute', inset: -size * 0.5,
          border: `1px solid ${color}`,
          borderRadius: '50%',
          opacity: 0,
          animation: `cyber-ring-${uid} ${pulseDuration} cubic-bezier(0.215, 0.61, 0.355, 1) infinite`
        }} />
      )}

      {/* Background Glow */}
      <div style={{
        position: 'absolute', inset: 0,
        background: color,
        filter: `blur(${glowSize})`,
        opacity: isDead ? 0.1 : (isHighEnergy ? 0.5 : 0.2),
        animation: isDead ? 'none' : `cyber-glow-${uid} ${pulseDuration} ease-in-out infinite`,
        borderRadius: '50%'
      }} />

      {/* Cybernetic Heart SVG */}
      <div style={{
        position: 'relative',
        zIndex: 2,
        width: '100%',
        height: '100%',
        animation: `${animClass} ${pulseDuration} ease-in-out infinite`,
        filter: `drop-shadow(0 0 ${isDead ? '2px' : '8px'} ${color})`
      }}>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={isGolden ? "1.5" : "1"}
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ width: '100%', height: '100%', color: isDead ? '#666' : color }}
        >
          <defs>
            {/* SVG Filters for glowing circuitry */}
            <filter id={`neon-glow-${uid}`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation={isDead ? "1" : "3"} result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>

            <linearGradient id={`holoGrad-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={color} stopOpacity={isDead ? 0.1 : 0.6} />
              <stop offset="50%" stopColor={color} stopOpacity={isDead ? 0.05 : 0.2} />
              <stop offset="100%" stopColor={color} stopOpacity={isDead ? 0.2 : 0.8} />
            </linearGradient>

            <clipPath id={`heartClip-${uid}`}>
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
            </clipPath>
            
            <pattern id={`circuit-${uid}`} width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <line x1="0" y1="3" x2="6" y2="3" stroke={color} strokeWidth="0.5" strokeOpacity={isDead ? 0.2 : 0.5} />
              <circle cx="3" cy="3" r="1" fill={color} fillOpacity={isDead ? 0.2 : 0.6} />
            </pattern>
          </defs>

          {/* Base Heart Body */}
          <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" 
                fill={`url(#holoGrad-${uid})`} 
                stroke={isDead ? '#555' : color} 
                strokeWidth="1.5" />
          
          {/* Internal Circuitry Overlay */}
          <rect x="0" y="0" width="24" height="24" fill={`url(#circuit-${uid})`} clipPath={`url(#heartClip-${uid})`} />

          {/* Holographic Scanline */}
          {!isDead && (
            <line x1="0" y1="0" x2="24" y2="0" stroke={color} strokeWidth="1.5" opacity="0.6" clipPath={`url(#heartClip-${uid})`} filter={`url(#neon-glow-${uid})`}>
               <animate attributeName="y1" values="-2;26" dur="2s" repeatCount="indefinite" />
               <animate attributeName="y2" values="-2;26" dur="2s" repeatCount="indefinite" />
            </line>
          )}
          
          {/* Dead Glitch & Flatline Visual */}
          {isDead && (
            <g clipPath={`url(#heartClip-${uid})`}>
              <line x1="2" y1="12" x2="22" y2="12" stroke="#444" strokeWidth="0.5" strokeDasharray="3 3" />
              {/* Flatline spike */}
              <path d="M6 12 L10 12 L11 8 L13 16 L14 12 L18 12" stroke="#4a4a5a" strokeWidth="1" fill="none" opacity="0.6">
                 <animate attributeName="opacity" values="0.2;0.6;0.2" dur="6s" repeatCount="indefinite" />
                 <animate attributeName="stroke" values="#4a4a5a;#ff4444;#4a4a5a" dur="6s" repeatCount="indefinite" />
              </path>
            </g>
          )}

          {/* Pulsing Energy Arcs */}
          {!isDead && (
            <path d="M12 4c-2-2-4-1-4 1 0 2 3 4 4 6 1-2 4-4 4-6 0-2-2-3-4-1" stroke={color} strokeWidth="0.8" fill="none" filter={`url(#neon-glow-${uid})`}>
              <animate attributeName="opacity" values="0;1;0;0;0" dur={pulseDuration} repeatCount="indefinite" />
            </path>
          )}

        </svg>
      </div>
      
      <style>{`
        @keyframes cyber-beat-${uid} {
          0%, 100% { transform: scale(1); }
          15% { transform: scale(1.15); }
          30% { transform: scale(1); }
          45% { transform: scale(1.08); }
        }
        @keyframes cyber-glow-${uid} {
          0%, 100% { opacity: 0.3; transform: scale(0.9); }
          15% { opacity: ${isHighEnergy ? 0.7 : 0.5}; transform: scale(1.1); }
          30% { opacity: 0.3; transform: scale(0.9); }
          45% { opacity: ${isHighEnergy ? 0.5 : 0.4}; transform: scale(1.05); }
        }
        @keyframes cyber-ring-${uid} {
          0% { transform: scale(0.8); opacity: 0.8; stroke-width: 2px; }
          100% { transform: scale(1.8); opacity: 0; stroke-width: 0px; }
        }
        @keyframes cyber-glitch-${uid} {
          0%, 100% { transform: scale(1) translate(0, 0); opacity: 0.8; filter: drop-shadow(0 0 2px #4a4a5a); }
          10% { transform: scale(1) translate(-1px, 1px); opacity: 0.5; filter: drop-shadow(0 0 2px #ff4444); }
          20% { transform: scale(1) translate(1px, -1px); opacity: 0.9; filter: drop-shadow(0 0 2px #4a4a5a); }
          30% { transform: scale(1) translate(0, 0); opacity: 0.8; filter: drop-shadow(0 0 2px #4a4a5a); }
        }
      `}</style>
    </div>
  );
}
