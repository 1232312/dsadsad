import * as React from "react";
import { useRef, useState, useEffect, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { CameraControls, Text, Edges, ContactShadows, Environment, Float, Html, Sparkles, Stars, Grid, Line } from '@react-three/drei';
import { EffectComposer, Bloom, ChromaticAberration, Vignette, Noise } from '@react-three/postprocessing';
import * as THREE from 'three';

export interface Project {
  id: number | string;
  name: string;
  district: string;
  stage: number;
  status: string;
  founder?: string;
  timeline?: string;
}

const THEMES: Record<string, {color: string, emissive: string}> = {
  'AI District': { color: '#22d3ee', emissive: '#0891b2' },
  'Gaming': { color: '#e879f9', emissive: '#c026d3' },
  'Health': { color: '#34d399', emissive: '#059669' },
  'Finance': { color: '#fbbf24', emissive: '#d97706' },
  'Education': { color: '#60a5fa', emissive: '#2563eb' },
  'Art & Design': { color: '#f87171', emissive: '#dc2626' },
  'Robotics': { color: '#f97316', emissive: '#c2410c' },
  'Space': { color: '#ffffff', emissive: '#94a3b8' },
  'Open Source': { color: '#84cc16', emissive: '#4d7c0f' },
  'Marketplace': { color: '#38bdf8', emissive: '#0284c7' },
  'default': { color: '#a78bfa', emissive: '#7c3aed' }
};

const DISTRICT_CENTERS: Record<string, [number, number]> = {
  'AI District': [0, 0],
  'Gaming': [45, 30],
  'Health': [-45, 30],
  'Finance': [45, -30],
  'Education': [-45, -30],
  'Art & Design': [70, 0],
  'Robotics': [-70, 0],
  'Space': [0, -60],
  'Open Source': [0, 60],
  'Marketplace': [70, -60],
  'default': [70, 60]
};

function getProjectPosition(project: Project, aliveProjects: Project[], deadProjects: Project[]): THREE.Vector3 {
  const isDead = project.stage === 0 || project.status === 'Abandoned';
  if (isDead) {
    const i = deadProjects.findIndex(p => p.id === project.id);
    const cols = Math.ceil(Math.sqrt(deadProjects.length || 1));
    const x = (i % cols) * 12 - ((cols * 12) / 2);
    const z = Math.floor(i / cols) * 12 + 80;
    return new THREE.Vector3(x, 0, z);
  }

  const center = DISTRICT_CENTERS[project.district] || DISTRICT_CENTERS.default;
  const sameDistrict = aliveProjects.filter(p => p.district === project.district);
  const idx = sameDistrict.findIndex(p => p.id === project.id);
  
  const cols = Math.ceil(Math.sqrt(sameDistrict.length));
  const x = center[0] + ((idx % cols) - cols/2) * 15;
  const z = center[1] + (Math.floor(idx / cols) - cols/2) * 15;
  
  return new THREE.Vector3(x, 0, z);
}

// Simple and stable hash function based on project ID or name
const getProjectHash = (id: string | number): number => {
  const str = String(id);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash);
};

export interface LandmarkProps {
  w: number;
  h: number;
  matBlack: THREE.Material;
  matGlow: THREE.Material;
  theme?: { color: string; emissive: string };
  project?: Project;
  zoomLevel?: number;
}

function InstancedWindows({ w, h, isDead, theme, style }: { w: number; h: number; isDead: boolean; theme: { color: string; emissive: string }; style: string }) {
  const instancedMeshRef = useRef<THREE.InstancedMesh>(null);

  // Generate window positions once based on geometry style
  const windowData = useMemo(() => {
    const data = [];
    const rows = Math.floor(h * 3.2);

    if (style === 'cylinder' || style === 'hexagonal') {
      const cols = style === 'hexagonal' ? 6 : 8;
      const radius = w * 0.48;
      const spacingY = h / (rows + 1);

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const theta = (c / cols) * Math.PI * 2 + (style === 'hexagonal' ? Math.PI / 6 : 0);
          data.push({
            position: [
              Math.cos(theta) * (radius + 0.015),
              -h / 2 + spacingY * (r + 1),
              Math.sin(theta) * (radius + 0.015)
            ] as [number, number, number],
            rotation: [0, -theta + Math.PI / 2, 0] as [number, number, number],
            scale: [w * 0.22, 0.15, 0.01] as [number, number, number],
            flickerOffset: Math.random() * Math.PI * 2,
            flickerSpeed: 1.5 + Math.random() * 2.5
          });
        }
      }
    } else {
      // Box, setback, or angled styles
      const cols = 2;
      const spacingY = h / (rows + 1);
      

      const sides = [
        { dir: [0, 0, 1], rot: [0, 0, 0] }, // Front
        { dir: [0, 0, -1], rot: [0, Math.PI, 0] }, // Back
        { dir: [-1, 0, 0], rot: [0, -Math.PI / 2, 0] }, // Left
        { dir: [1, 0, 0], rot: [0, Math.PI / 2, 0] } // Right
      ];

      sides.forEach((side) => {
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            // Apply slight setbacks for tapered (angled) or nested shapes
            const currentW = style === 'angled' ? w * (1 - (r / rows) * 0.4) : w;
            const currentOffset = currentW / 2 + 0.015;

            const posX = side.dir[0] !== 0 ? side.dir[0] * currentOffset : -currentW / 2 + (currentW / (cols + 1)) * (c + 1);
            const posZ = side.dir[2] !== 0 ? side.dir[2] * currentOffset : -currentW / 2 + (currentW / (cols + 1)) * (c + 1);

            data.push({
              position: [posX, -h / 2 + spacingY * (r + 1), posZ] as [number, number, number],
              rotation: side.rot as [number, number, number],
              scale: [(currentW / (cols + 1)) * 0.45, 0.15, 0.01] as [number, number, number],
              flickerOffset: Math.random() * Math.PI * 2,
              flickerSpeed: 1.5 + Math.random() * 2.5
            });
          }
        }
      });
    }

    return data;
  }, [w, h, style]);

  const colorObj = useMemo(() => new THREE.Color(isDead ? '#3a0505' : theme.color), [isDead, theme.color]);
  const tempMatrix = useMemo(() => new THREE.Matrix4(), []);
  const tempPosition = useMemo(() => new THREE.Vector3(), []);
  const tempRotation = useMemo(() => new THREE.Euler(), []);
  const tempScale = useMemo(() => new THREE.Vector3(), []);
  const tempColor = useMemo(() => new THREE.Color(), []);

  useEffect(() => {
    const mesh = instancedMeshRef.current;
    if (!mesh) return;

    windowData.forEach((win, index) => {
      tempPosition.fromArray(win.position);
      tempRotation.fromArray(win.rotation);
      tempScale.fromArray(win.scale);

      tempMatrix.compose(tempPosition, new THREE.Quaternion().setFromEuler(tempRotation), tempScale);
      mesh.setMatrixAt(index, tempMatrix);
      mesh.setColorAt(index, colorObj);
    });

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [windowData, colorObj, tempMatrix, tempPosition, tempRotation, tempScale]);

  useFrame((state) => {
    const mesh = instancedMeshRef.current;
    if (!mesh) return;

    const t = state.clock.elapsedTime;

    windowData.forEach((win, index) => {
      let brightness = 1.0;
      if (isDead) {
        // Graveyard windows: mostly dead, rare low flicker
        const val = Math.sin(t * win.flickerSpeed + win.flickerOffset);
        brightness = val > 0.96 ? 0.25 : 0.02;
      } else {
        // Natural per-window flicker
        const val = Math.sin(t * win.flickerSpeed + win.flickerOffset);
        brightness = 0.5 + Math.max(0, val) * 0.8;
        
        // Occasional deep fade (e.g. resident turning off lights)
        if (Math.sin(t * 0.15 + win.flickerOffset) > 0.88) {
          brightness *= 0.1;
        }
      }

      tempColor.copy(colorObj).multiplyScalar(brightness);
      mesh.setColorAt(index, tempColor);
    });

    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={instancedMeshRef}
      args={[null as any, null as any, windowData.length]}
      castShadow={false}
      receiveShadow={false}
    >
      <planeGeometry />
      <meshBasicMaterial toneMapped={false} transparent opacity={0.9} />
    </instancedMesh>
  );
}

function VolumetricBeam({ w, h, color }: { w: number; h: number; color: string }) {
  const beamRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (beamRef.current) {
      const t = state.clock.elapsedTime;
      // Pulse scale
      const scalePulse = 1.0 + Math.sin(t * 1.5) * 0.04;
      beamRef.current.scale.set(scalePulse, 1, scalePulse);

      const mat = beamRef.current.material as THREE.MeshBasicMaterial;
      if (mat) {
        mat.opacity = 0.14 + Math.sin(t * 4) * 0.04; // pulsing flicker
      }
    }
  });

  return (
    <mesh ref={beamRef} position={[0, h / 2 + 30, 0]}>
      <cylinderGeometry args={[w * 0.02, w * 0.35, 60, 16, 1, true]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.15}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function AILandmark({ w, h, matBlack, matGlow, theme }: LandmarkProps) {
  const ref = useRef<THREE.Group>(null);
  const ring1Ref = useRef<THREE.Mesh>(null);
  const ring2Ref = useRef<THREE.Mesh>(null);
  const ring3Ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (ring1Ref.current) {
      ring1Ref.current.rotation.x = t * 0.4;
      ring1Ref.current.rotation.y = t * 0.6;
    }
    if (ring2Ref.current) {
      ring2Ref.current.rotation.y = -t * 0.5;
      ring2Ref.current.rotation.z = t * 0.3;
    }
    if (ring3Ref.current) {
      ring3Ref.current.rotation.z = t * 0.8;
    }
  });

  const glowingColor = theme?.color || '#22d3ee';

  return (
    <group ref={ref} position={[0, h / 2, 0]}>
      {/* Central Spire */}
      <mesh material={matBlack} castShadow receiveShadow>
        <cylinderGeometry args={[w * 0.25, w * 0.7, h, 6]} />
        <Edges scale={1.01} color="#22d3ee" />
      </mesh>

      {/* Gyroscopic floating rings */}
      <group position={[0, 1.5, 0]}>
        <mesh ref={ring1Ref}>
          <torusGeometry args={[w * 1.3, 0.06, 16, 64]} />
          <meshBasicMaterial color={glowingColor} toneMapped={false} transparent opacity={0.8} />
        </mesh>
        <mesh ref={ring2Ref}>
          <torusGeometry args={[w * 1.1, 0.04, 16, 64]} />
          <meshBasicMaterial color={glowingColor} toneMapped={false} transparent opacity={0.6} />
        </mesh>
        <mesh ref={ring3Ref} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[w * 0.9, 0.03, 16, 64]} />
          <meshBasicMaterial color={glowingColor} toneMapped={false} transparent opacity={0.5} />
        </mesh>
      </group>

      {/* Floating glowing core sphere */}
      <Float speed={3.5} floatIntensity={1.5}>
        <mesh position={[0, h / 2 + 1.5, 0]} material={matGlow} castShadow>
          <sphereGeometry args={[w * 0.35, 32, 32]} />
          <Edges scale={1.01} color={glowingColor} />
        </mesh>
      </Float>

      {/* Vertical scanning line */}
      <mesh material={matGlow} position={[0, 0, w * 0.75]} castShadow>
        <planeGeometry args={[0.08, h * 0.9]} />
      </mesh>

      {/* Sparkles count */}
      <Sparkles count={80} scale={w * 3} size={2.5} speed={1.5} color={glowingColor} />

      {/* Holographic Ground Projection */}
      <group position={[0, -h / 2 + 0.02, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.3, w * 1.35, 6]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.4} wireframe />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.7, w * 1.75, 12]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.25} wireframe />
        </mesh>
      </group>

      {/* Volumetric Beam */}
      <VolumetricBeam w={w} h={h} color={glowingColor} />
    </group>
  );
}

function GamingLandmark({ w, h, matBlack, matGlow, theme }: LandmarkProps) {
  const ref = useRef<THREE.Group>(null);
  const cube1Ref = useRef<THREE.Mesh>(null);
  const cube2Ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (ref.current) {
      ref.current.children.forEach((child, i) => {
        if (i < 3) {
          child.rotation.y = Math.sin(t * 0.4 + i) * 0.15;
        }
      });
    }
    // Spin floating mini cubes
    if (cube1Ref.current) {
      cube1Ref.current.position.set(
        Math.sin(t * 1.8) * w * 1.4,
        h * 0.3 + Math.sin(t * 3) * 0.4,
        Math.cos(t * 1.8) * w * 1.4
      );
      cube1Ref.current.rotation.x = t * 2;
      cube1Ref.current.rotation.y = t * 1;
    }
    if (cube2Ref.current) {
      cube2Ref.current.position.set(
        Math.sin(t * -1.5) * w * 1.8,
        h * 0.7 + Math.cos(t * 2) * 0.3,
        Math.cos(t * -1.5) * w * 1.8
      );
      cube2Ref.current.rotation.y = t * 1.5;
      cube2Ref.current.rotation.z = t * 2.5;
    }
  });

  const glowingColor = theme?.color || '#e879f9';

  return (
    <group ref={ref} position={[0, h / 2, 0]}>
      {/* Dynamic stacked cubes */}
      <mesh material={matBlack} castShadow receiveShadow>
        <boxGeometry args={[w * 1.5, h * 0.3, w * 1.5]} />
        <Edges scale={1.01} color="#e879f9" />
      </mesh>
      <mesh material={matBlack} position={[0, h * 0.3, 0]} castShadow receiveShadow>
        <boxGeometry args={[w * 1.1, h * 0.3, w * 1.1]} />
        <Edges scale={1.01} color="#e879f9" />
      </mesh>
      <mesh material={matGlow} position={[0, h * 0.6, 0]} castShadow receiveShadow>
        <boxGeometry args={[w * 0.7, h * 0.3, w * 0.7]} />
        <Edges scale={1.01} color="#e879f9" />
      </mesh>

      {/* Floating high-tech voxel cubes */}
      <mesh ref={cube1Ref}>
        <boxGeometry args={[0.3, 0.3, 0.3]} />
        <meshBasicMaterial color={glowingColor} toneMapped={false} />
      </mesh>
      <mesh ref={cube2Ref}>
        <boxGeometry args={[0.2, 0.2, 0.2]} />
        <meshBasicMaterial color={glowingColor} toneMapped={false} />
      </mesh>

      {/* Glowing Diamond at Top */}
      <Float speed={4} rotationIntensity={1.5} floatIntensity={0.8}>
        <mesh position={[0, h * 0.8 + 1.2, 0]} material={matGlow} castShadow>
          <octahedronGeometry args={[w * 0.45]} />
          <Edges scale={1.01} color={glowingColor} />
        </mesh>
      </Float>

      {/* Sparkles */}
      <Sparkles count={100} scale={w * 4} size={3} speed={2} color={glowingColor} />

      {/* Holographic Ground Projection: Double Spinning Square */}
      <group position={[0, -h / 2 + 0.02, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.3, w * 1.35, 4]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.45} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, Math.PI / 4]}>
          <ringGeometry args={[w * 1.6, w * 1.65, 4]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.25} />
        </mesh>
      </group>

      {/* Volumetric Beam */}
      <VolumetricBeam w={w} h={h} color={glowingColor} />
    </group>
  );
}

function RoboticsLandmark({ w, h, matBlack, matGlow, theme }: LandmarkProps) {
  const armRef = useRef<THREE.Group>(null);
  const sweepRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (armRef.current) {
      armRef.current.rotation.y = Math.sin(t) * (Math.PI / 3);
      armRef.current.children[0].rotation.z = Math.sin(t * 1.8) * 0.25;
    }
    if (sweepRef.current) {
      sweepRef.current.rotation.y = t * 1.4;
    }
  });

  const glowingColor = theme?.color || '#f97316';

  return (
    <group position={[0, h / 2, 0]}>
      {/* Heavy Cybernetic Spire Base */}
      <mesh material={matBlack} castShadow receiveShadow>
        <boxGeometry args={[w * 1.8, h * 0.55, w * 1.8]} />
        <Edges scale={1.01} color="#f97316" />
      </mesh>

      {/* Mechanical Rotating Piston Sleeve */}
      <mesh position={[0, h * 0.35, 0]} material={matBlack} castShadow>
        <cylinderGeometry args={[w * 0.8, w * 1.0, h * 0.25, 8]} />
        <Edges scale={1.01} color="#f97316" />
      </mesh>

      {/* Robotic Arm Assembly */}
      <group ref={armRef} position={[0, h * 0.45, 0]}>
        <mesh material={matBlack} position={[0, h * 0.25, 0]} castShadow>
          <cylinderGeometry args={[0.2, 0.25, h * 0.5]} />
          <Edges scale={1.01} color={glowingColor} />
        </mesh>
        <mesh material={matGlow} position={[0, h * 0.5, 0]} castShadow>
          <sphereGeometry args={[0.35]} />
        </mesh>
      </group>

      {/* Dynamic Sweeping Scanning Laser */}
      <group ref={sweepRef} position={[0, h * 0.45, 0]}>
        <mesh position={[0, -h * 0.35, w * 1.1]} rotation={[0.4, 0, 0]}>
          <cylinderGeometry args={[0.015, 0.015, h * 1.2]} />
          <meshBasicMaterial color={glowingColor} toneMapped={false} transparent opacity={0.9} />
        </mesh>
      </group>

      {/* Sparkles */}
      <Sparkles count={80} scale={w * 3.5} size={2.5} speed={1.2} color={glowingColor} />

      {/* Holographic Ground Projection: Scanning Circular Radar Grid */}
      <group position={[0, -h / 2 + 0.02, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 0.2, w * 2.2, 32, 1, 0, Math.PI / 3]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.15} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.4, w * 1.45, 32]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.35} />
        </mesh>
      </group>

      {/* Volumetric Beam */}
      <VolumetricBeam w={w} h={h} color={glowingColor} />
    </group>
  );
}

function SpaceLandmark({ w, h, matBlack, matGlow, theme }: LandmarkProps) {
  const satRef = useRef<THREE.Group>(null);
  const sleeveRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (satRef.current) {
      satRef.current.rotation.y = t * 0.9;
      satRef.current.rotation.z = Math.sin(t * 0.5) * 0.3;
    }
    if (sleeveRef.current) {
      sleeveRef.current.position.y = h * 0.2 + Math.sin(t * 0.8) * h * 0.22;
    }
  });

  const glowingColor = theme?.color || '#ffffff';

  return (
    <group position={[0, h / 2, 0]}>
      {/* High Tapered Space Elevator Tower */}
      <mesh material={matBlack} castShadow receiveShadow>
        <cylinderGeometry args={[w * 0.12, w * 1.2, h, 4, 1, false, Math.PI / 4]} />
        <Edges scale={1.01} color="#ffffff" />
      </mesh>

      {/* Central Beam core */}
      <mesh material={matGlow} position={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, h * 1.15]} />
      </mesh>

      {/* Moving Elevator / Docking Sleeve Ring */}
      <group ref={sleeveRef}>
        <mesh material={matGlow} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[w * 0.95, 0.09, 16, 64]} />
          <Edges scale={1.01} color={glowingColor} />
        </mesh>
      </group>

      {/* High-speed orbiting probe satellite */}
      <group ref={satRef} position={[0, h * 0.45, 0]}>
        <mesh position={[w * 2.2, 0, 0]} material={matGlow} castShadow>
          <sphereGeometry args={[0.18]} />
        </mesh>
        <mesh position={[w * 2.2, 0.1, 0]}>
          <cylinderGeometry args={[0.01, 0.01, 0.5]} />
          <meshBasicMaterial color={glowingColor} toneMapped={false} />
        </mesh>
      </group>

      {/* Sparkles */}
      <Sparkles count={90} scale={w * 4} size={2.5} speed={1.8} color={glowingColor} />

      {/* Holographic Ground Projection: Orbital coordinates and coordinate rings */}
      <group position={[0, -h / 2 + 0.02, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.2, w * 1.24, 32]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.4} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.8, w * 1.84, 24]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.2} />
        </mesh>
      </group>

      {/* Volumetric Beam */}
      <VolumetricBeam w={w} h={h} color={glowingColor} />
    </group>
  );
}

function DefaultLandmark({ w, h, matBlack, matGlow, theme }: LandmarkProps) {
  const crystalRef = useRef<THREE.Mesh>(null);
  const comp1Ref = useRef<THREE.Mesh>(null);
  const comp2Ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (crystalRef.current) {
      crystalRef.current.rotation.y = t * 0.65;
      crystalRef.current.rotation.x = Math.sin(t * 0.4) * 0.15;
    }
    // Animate companions floating out of phase
    if (comp1Ref.current) {
      comp1Ref.current.position.y = h * 0.5 + Math.sin(t * 1.2) * 0.4;
      comp1Ref.current.rotation.y = -t * 0.8;
    }
    if (comp2Ref.current) {
      comp2Ref.current.position.y = h * 0.4 + Math.cos(t * 1.2) * 0.4;
      comp2Ref.current.rotation.y = t * 0.8;
    }
  });

  const glowingColor = theme?.color || '#a78bfa';

  return (
    <group position={[0, h / 2, 0]}>
      {/* Sleek Tapered Monument Obelisk */}
      <mesh material={matBlack} castShadow receiveShadow>
        <cylinderGeometry args={[0.02, w * 1.1, h * 1.1, 4]} />
        <Edges scale={1.01} color="#a78bfa" />
      </mesh>

      {/* Floating Giant Central Crystal Core */}
      <Float speed={2.5}>
        <mesh ref={crystalRef} material={matGlow} position={[0, h * 0.65, 0]} castShadow>
          <octahedronGeometry args={[w * 0.65]} />
          <Edges scale={1.01} color={glowingColor} />
        </mesh>
      </Float>

      {/* Floating side companions */}
      <mesh ref={comp1Ref} position={[w * 1.2, h * 0.5, w * 1.2]} material={matBlack} castShadow>
        <boxGeometry args={[0.3, 0.6, 0.3]} />
        <Edges scale={1.01} color={glowingColor} />
      </mesh>
      <mesh ref={comp2Ref} position={[-w * 1.2, h * 0.4, -w * 1.2]} material={matBlack} castShadow>
        <boxGeometry args={[0.3, 0.6, 0.3]} />
        <Edges scale={1.01} color={glowingColor} />
      </mesh>

      {/* Sparkles */}
      <Sparkles count={70} scale={w * 3} size={2} speed={1.2} color={glowingColor} />

      {/* Holographic Ground Projection: Star Mandala */}
      <group position={[0, -h / 2 + 0.02, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.2, w * 1.25, 8]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.35} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[w * 1.7, w * 1.75, 5]} />
          <meshBasicMaterial color={glowingColor} transparent opacity={0.2} />
        </mesh>
      </group>

      {/* Volumetric Beam */}
      <VolumetricBeam w={w} h={h} color={glowingColor} />
    </group>
  );
}

function Rooftop({ stage, w, h, matBlack, matGlow }: { stage: number, w: number, h: number, matBlack: THREE.Material, matGlow: THREE.Material }) {
  if (stage === 2) {
    return (
      <group position={[0, h/2 + 0.2, 0]}>
        <mesh material={matBlack} castShadow>
          <boxGeometry args={[w*0.5, 0.4, w*0.5]} />
        </mesh>
        <mesh material={matGlow} position={[0, 0.2, 0]} castShadow>
          <boxGeometry args={[0.1, 0.1, 0.1]} />
        </mesh>
      </group>
    );
  }
  if (stage === 3) {
    return (
      <group position={[0, h/2 + 0.3, 0]}>
        <mesh material={matBlack} castShadow>
          <cylinderGeometry args={[w*0.4, w*0.4, 0.2, 8]} />
        </mesh>
        <mesh material={matBlack} position={[-0.2, 0.5, 0]} castShadow>
          <cylinderGeometry args={[0.02, 0.02, 1]} />
        </mesh>
        <mesh material={matGlow} position={[-0.2, 1, 0]} castShadow>
          <sphereGeometry args={[0.05]} />
        </mesh>
      </group>
    );
  }
  if (stage === 4) {
    return (
      <group position={[0, h/2 + 1, 0]}>
        <Float speed={2}>
          <mesh material={matGlow} rotation={[Math.PI/2, 0, 0]} castShadow>
            <torusGeometry args={[w*0.6, 0.05, 8, 32]} />
          </mesh>
        </Float>
        <mesh material={matBlack} position={[0, -0.5, 0]} castShadow>
          <coneGeometry args={[w*0.8, 1, 4]} />
        </mesh>
      </group>
    );
  }
  return null;
}

function SciFiBuilding({ 
  stage, 
  district, 
  isDead, 
  isReviving, 
  theme, 
  hovered,
  project 
}: { 
  stage: number; 
  district: string; 
  isDead: boolean; 
  isReviving: boolean; 
  theme: { color: string; emissive: string }; 
  hovered: boolean;
  project: Project;
}) {
  const matBlack = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#07070a', 
    roughness: 0.15, 
    metalness: 0.9,
    envMapIntensity: 1.5
  }), []);

  const matDead = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#030303', 
    roughness: 0.85, 
    metalness: 0.1 
  }), []);
  
  const emissiveColor = isDead ? '#ff0000' : theme.emissive;
  const matGlow = useMemo(() => new THREE.MeshStandardMaterial({ 
    color: '#000000', 
    emissive: emissiveColor, 
    emissiveIntensity: hovered || isReviving ? 2.5 : (isDead ? 0.3 : 1.3),
    roughness: 0.1,
    metalness: 0.1
  }), [emissiveColor, hovered, isReviving, isDead]);

  const h = isDead ? 0.5 : Math.max(1, stage * 1.8);
  const w = isDead ? 1.5 : (1 + stage * 0.15);
  const ref = useRef<THREE.Group>(null);
  const glowStripRef = useRef<THREE.MeshStandardMaterial>(null);

  const hash = useMemo(() => getProjectHash(project.id), [project.id]);
  const style = useMemo(() => {
    if (isDead) return 'box';
    const styles = ['box', 'setback', 'angled', 'cylinder', 'hexagonal'];
    return styles[hash % styles.length];
  }, [hash, isDead]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (isDead && ref.current) {
      const flicker = Math.random() > 0.96 ? 0.05 : 0.45;
      matGlow.emissiveIntensity = flicker;
    }
    if (isReviving && ref.current) {
      matGlow.emissiveIntensity = 2.0 + Math.sin(t * 8) * 1.4;
    }
    // Pulse ground glow strip
    if (glowStripRef.current) {
      glowStripRef.current.emissiveIntensity = 1.5 + Math.sin(t * 3) * 0.7;
    }
  });

  if (stage >= 5 && !isDead) {
    let Landmark: React.FC<LandmarkProps> = DefaultLandmark;
    if (district === 'AI District') Landmark = AILandmark;
    else if (district === 'Gaming') Landmark = GamingLandmark;
    else if (district === 'Robotics') Landmark = RoboticsLandmark;
    else if (district === 'Space') Landmark = SpaceLandmark;
    
    return (
      <group ref={ref}>
        <Landmark w={w} h={h} matBlack={matBlack} matGlow={matGlow} theme={theme} />
        {isReviving && (
          <group position={[0, h/2, 0]}>
            <mesh>
              <boxGeometry args={[w*2 + 0.4, h*1.5 + 0.4, w*2 + 0.4]} />
              <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
            </mesh>
          </group>
        )}
      </group>
    );
  }

  return (
    <group ref={ref} position={[0, h/2, 0]}>
      {/* Base Building Model based on procedural style */}
      {style === 'setback' ? (
        <group>
          {/* Bottom step */}
          <mesh castShadow receiveShadow material={isDead ? matDead : matBlack} position={[0, -h * 0.15, 0]}>
            <boxGeometry args={[w, h * 0.7, w]} />
            <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
          </mesh>
          {/* Top step */}
          <mesh castShadow receiveShadow material={isDead ? matDead : matBlack} position={[0, h * 0.35, 0]}>
            <boxGeometry args={[w * 0.7, h * 0.3, w * 0.7]} />
            <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
          </mesh>
        </group>
      ) : style === 'angled' ? (
        <mesh castShadow receiveShadow material={isDead ? matDead : matBlack}>
          {/* Tapered tower shape */}
          <cylinderGeometry args={[w * 0.4, w * 0.9, h, 4, 1, false, Math.PI / 4]} />
          <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
        </mesh>
      ) : style === 'cylinder' ? (
        <mesh castShadow receiveShadow material={isDead ? matDead : matBlack}>
          <cylinderGeometry args={[w * 0.45, w * 0.5, h, 16]} />
          <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
        </mesh>
      ) : style === 'hexagonal' ? (
        <mesh castShadow receiveShadow material={isDead ? matDead : matBlack}>
          <cylinderGeometry args={[w * 0.45, w * 0.5, h, 6]} />
          <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
        </mesh>
      ) : (
        /* Standard Box tower */
        <mesh castShadow receiveShadow material={isDead ? matDead : matBlack}>
          {stage === 4 ? (
            <boxGeometry args={[w * 0.8, h, w * 1.2]} />
          ) : (
            <boxGeometry args={[w, h, w]} />
          )}
          <Edges scale={1.01} color={isDead ? '#330000' : '#222222'} />
        </mesh>
      )}

      {stage === 4 && !isDead && style === 'box' && (
        <mesh castShadow receiveShadow material={matBlack} position={[w * 0.8, 0, 0]}>
          <boxGeometry args={[w * 0.5, h * 0.8, w * 0.8]} />
          <Edges scale={1.01} color="#222222" />
        </mesh>
      )}

      {/* Instanced Glowing Windows */}
      <InstancedWindows w={w} h={h} isDead={isDead} theme={theme} style={style} />

      {/* Rooftop props */}
      {!isDead && <Rooftop stage={stage} w={w} h={h} matBlack={matBlack} matGlow={matGlow} />}

      {/* Ground-floor glow strips */}
      {!isDead && (
        <mesh position={[0, -h/2 + 0.05, 0]}>
          {style === 'cylinder' || style === 'hexagonal' ? (
            <cylinderGeometry args={[w * 0.49, w * 0.51, 0.08, style === 'hexagonal' ? 6 : 16, 1, true]} />
          ) : (
            <boxGeometry args={[w * 1.01, 0.08, w * 1.01]} />
          )}
          <meshStandardMaterial
            ref={glowStripRef}
            color={theme.color}
            emissive={theme.color}
            emissiveIntensity={1.8}
            toneMapped={false}
            transparent
            opacity={0.9}
          />
        </mesh>
      )}

      {/* Volumetric Beam for Stage 4 buildings */}
      {stage === 4 && !isDead && (
        <VolumetricBeam w={w} h={h} color={theme.color} />
      )}

      {isReviving && (
        <group>
          <mesh>
            <boxGeometry args={[w + 0.4, h + 0.4, w + 0.4]} />
            <meshBasicMaterial color="#00ffff" wireframe transparent opacity={0.3} />
          </mesh>
          <mesh position={[w, h, w]} rotation={[0.5, -0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.8} />
          </mesh>
          <mesh position={[-w, h, -w]} rotation={[-0.5, 0.5, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 3]} />
            <meshBasicMaterial color="#e879f9" transparent opacity={0.8} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function HtmlNode({ position, title, value, children }: { position: [number, number, number], title: string, value?: string, children?: React.ReactNode }) {
  return (
    <Html position={position} center className="pointer-events-auto z-50">
      <div className="bg-black/90 border border-fuchsia-500/30 p-3 rounded-lg backdrop-blur-xl min-w-[140px] shadow-[0_0_30px_rgba(232,121,249,0.15)] transform transition-transform hover:scale-105">
        <div className="text-[9px] text-fuchsia-400 font-mono uppercase tracking-[0.2em] mb-1.5 opacity-80">{title}</div>
        {value && <div className="text-sm text-white font-medium tracking-wide">{value}</div>}
        {children}
      </div>
    </Html>
  );
}

function EchoAIBrain({ project, isDead, onRevive, close }: { project: Project, isDead: boolean, onRevive: (id: string | number) => void, close: () => void }) {
  const brainRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (brainRef.current) {
      brainRef.current.rotation.y += 0.005;
      brainRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <group position={[0, 4, 0]}>
      <Float speed={2} floatIntensity={1}>
        <group ref={brainRef}>
          <mesh>
            <icosahedronGeometry args={[1.5, 2]} />
            <meshBasicMaterial color={isDead ? "#ff0000" : "#0891b2"} wireframe transparent opacity={0.4} />
          </mesh>
          <mesh>
            <icosahedronGeometry args={[0.8, 1]} />
            <meshBasicMaterial color={isDead ? "#880000" : "#22d3ee"} transparent opacity={0.6} />
          </mesh>
          <Sparkles count={50} scale={3} size={4} speed={0.5} color={isDead ? "#ff0000" : "#ffffff"} />
        </group>
      </Float>
      <HtmlNode position={[2.5, 1.5, 0]} title="Founder" value={project.founder || "Unknown"} />
      <HtmlNode position={[-2.5, 1, 1]} title="Status" value={project.status} />
      <HtmlNode position={[0, 3, 0]} title="Timeline" value={project.timeline || "Active"} />
      <HtmlNode position={[1.5, -2, 1]} title="District" value={project.district} />
      
      <Html position={[0, -3.5, 0]} center className="pointer-events-auto z-50">
        <div className="flex gap-4">
          {isDead && (
            <button 
              onClick={(e) => { e.stopPropagation(); onRevive(project.id); close(); }} 
              className="bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500 text-cyan-400 px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
            >
              Initiate Revival
            </button>
          )}
          <button 
            onClick={(e) => { e.stopPropagation(); close(); }} 
            className="bg-white/5 hover:bg-white/10 border border-white/20 text-white px-6 py-2 rounded-full font-mono uppercase text-xs tracking-widest transition-all"
          >
            Close Core
          </button>
        </div>
      </Html>
    </group>
  );
}

function BuildingNode({ project, position, onClick, isReviving, isDead, isSelected, onRevive, close }: { project: Project, position: [number, number, number], onClick: (p: Project) => void, isReviving: boolean, isDead: boolean, isSelected: boolean, onRevive: (id: string | number) => void, close: () => void }) {
  const [hovered, setHovered] = useState(false);
  const theme = THEMES[project.district] || THEMES.default;

  if (isSelected) {
    return (
      <group position={position}>
        <EchoAIBrain project={project} isDead={isDead} onRevive={onRevive} close={close} />
        <group>
          <SciFiBuilding project={project} stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={false} />
        </group>
      </group>
    );
  }

  return (
    <group 
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        onClick(project);
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
        document.body.style.cursor = 'pointer';
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setHovered(false);
        document.body.style.cursor = 'auto';
      }}
    >
      <SciFiBuilding project={project} stage={project.stage} district={project.district} isDead={isDead} isReviving={isReviving} theme={theme} hovered={hovered} />
      <Text
        position={[0, Math.max(1, project.stage * 1.8) + (hovered ? 1.5 : 0.5), 0]}
        fontSize={0.5}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.05}
        outlineColor="black"
        visible={hovered}
      >
        {project.name}
      </Text>
    </group>
  );
}

function AnimatedDistrictFloor({ d, center, theme }: { d: string, center: [number, number], theme: any }) {
  const outerRingRef = useRef<THREE.Mesh>(null);
  const innerHexRef = useRef<THREE.Mesh>(null);
  const lightRef = useRef<THREE.PointLight>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (outerRingRef.current) {
      outerRingRef.current.rotation.z = t * 0.04;
    }
    if (innerHexRef.current) {
      innerHexRef.current.rotation.z = -t * 0.06;
    }
    // Subtly pulsing point light with district colors
    if (lightRef.current) {
      lightRef.current.intensity = 1.2 + Math.sin(t * 2.0) * 0.5;
    }
  });

  return (
    <group position={[center[0], -0.05, center[1]]}>
      {/* Soft Glow Disk */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[30, 32]} />
        <meshBasicMaterial color={theme.color} transparent opacity={0.015} />
      </mesh>
      
      {/* Outer Spinning Holographic Circle Ring */}
      <mesh ref={outerRingRef} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[29.5, 30, 64]} />
        <meshBasicMaterial color={theme.color} transparent opacity={0.25} />
      </mesh>

      {/* Decorative Outer Dash Brackets */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[30.6, 30.8, 8]} />
        <meshBasicMaterial color={theme.color} transparent opacity={0.12} wireframe />
      </mesh>

      {/* Inner Spinning Hexagonal boundary */}
      <mesh ref={innerHexRef} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[24.0, 24.3, 6]} />
        <meshBasicMaterial color={theme.color} transparent opacity={0.18} />
      </mesh>

      {/* Concentric inner alignment ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[15.0, 15.1, 32]} />
        <meshBasicMaterial color={theme.color} transparent opacity={0.08} />
      </mesh>

      {/* District Label */}
      <Text 
        position={[0, 0.1, -31]} 
        rotation={[-Math.PI/2, 0, 0]} 
        fontSize={2.5} 
        color={theme.color} 
        fillOpacity={0.7} 
        font="https://fonts.gstatic.com/s/orbitron/v25/yq5sZ5O8r_b6t9C8oKizRfk.woff"
      >
        {d.toUpperCase()}
      </Text>

      {/* Pulsing District Point Light */}
      <pointLight
        ref={lightRef}
        position={[0, 6, 0]}
        color={theme.color}
        intensity={1.5}
        distance={60}
        decay={1.8}
        castShadow
        shadow-mapSize-width={512}
        shadow-mapSize-height={512}
        shadow-bias={-0.002}
      />
    </group>
  );
}

function DistrictFloor({ aliveProjects }: { aliveProjects: Project[] }) {
  const districts = useMemo(() => Array.from(new Set(aliveProjects.map(p => p.district))), [aliveProjects]);
  
  return (
    <group>
      {districts.map(d => {
        const center = DISTRICT_CENTERS[d] || DISTRICT_CENTERS.default;
        const theme = THEMES[d] || THEMES.default;
        return (
          <AnimatedDistrictFloor 
            key={d} 
            d={d} 
            center={center as [number, number]} 
            theme={theme} 
          />
        );
      })}
    </group>
  );
}

function AnimatedDataPacket({ p1, p2, color }: { p1: THREE.Vector3; p2: THREE.Vector3; color: string }) {
  const packetRef = useRef<THREE.Mesh>(null);
  const speed = useMemo(() => 0.4 + Math.random() * 0.5, []);
  const offset = useMemo(() => Math.random(), []);

  useFrame((state) => {
    if (packetRef.current) {
      const t = ((state.clock.elapsedTime * speed + offset) % 1);
      packetRef.current.position.set(
        THREE.MathUtils.lerp(p1.x, p2.x, t),
        0.1, // slightly above ground
        THREE.MathUtils.lerp(p1.z, p2.z, t)
      );
    }
  });

  return (
    <mesh ref={packetRef}>
      <boxGeometry args={[0.25, 0.25, 0.25]} />
      <meshBasicMaterial color={color} toneMapped={false} />
    </mesh>
  );
}

function GlowingRoads({ aliveProjects }: { aliveProjects: Project[] }) {
  const districts = useMemo(() => Array.from(new Set(aliveProjects.map(p => p.district))), [aliveProjects]);
  
  const roads = useMemo(() => {
    const list: any[] = [];
    districts.forEach(d => {
      const theme = THEMES[d] || THEMES.default;
      const projects = aliveProjects.filter(p => p.district === d);
      
      for (let i = 1; i < projects.length; i++) {
        const p1 = getProjectPosition(projects[i-1], aliveProjects, []);
        const p2 = getProjectPosition(projects[i], aliveProjects, []);
        list.push({
          key: `${projects[i-1].id}-${projects[i].id}`,
          p1,
          p2,
          color: theme.color
        });
      }
    });
    return list;
  }, [aliveProjects, districts]);

  return (
    <group position={[0, 0.05, 0]}>
      {roads.map(road => (
        <React.Fragment key={road.key}>
          {/* Static Road Line */}
          <Line 
            points={[[road.p1.x, 0, road.p1.z], [road.p2.x, 0, road.p2.z]]}
            color={road.color}
            lineWidth={1.5}
            transparent
            opacity={0.3}
          />
          {/* Glowing Animated Data Packet */}
          <AnimatedDataPacket p1={road.p1} p2={road.p2} color={road.color} />
        </React.Fragment>
      ))}
    </group>
  );
}

function Drone({ type, center, radius, height, speed, color, isOrbit }: {
  type: 'x' | 'z';
  center: [number, number];
  radius: number;
  height: number;
  speed: number;
  color: string;
  isOrbit: boolean;
}) {
  const droneRef = useRef<THREE.Group>(null);
  const trailRef = useRef<any>(null);
  const angleRef = useRef<number>(Math.random() * Math.PI * 2);
  const startPos = useMemo(() => (Math.random() - 0.5) * 200, []);
  const direction = useMemo(() => (Math.random() > 0.5 ? 1 : -1), []);

  const initialPos = useMemo(() => {
    if (isOrbit) {
      return [
        center[0] + Math.cos(angleRef.current) * radius,
        height,
        center[1] + Math.sin(angleRef.current) * radius
      ];
    } else {
      if (type === 'x') {
        return [startPos, height, center[1]];
      } else {
        return [center[0], height, startPos];
      }
    }
  }, [isOrbit, type, center, radius, height, startPos]);

  useFrame((_state, delta) => {
    if (!droneRef.current) return;

    if (isOrbit) {
      angleRef.current += speed * 0.45 * delta * direction;
      const x = center[0] + Math.cos(angleRef.current) * radius;
      const z = center[1] + Math.sin(angleRef.current) * radius;
      droneRef.current.position.set(x, height, z);

      // Rotate to face trajectory
      const tangentX = -Math.sin(angleRef.current) * direction;
      const tangentZ = Math.cos(angleRef.current) * direction;
      droneRef.current.rotation.y = Math.atan2(tangentX, tangentZ);

      // Curved trailing points
      if (trailRef.current) {
        const points = [];
        const segments = 4;
        const dTheta = 0.05 * direction;
        for (let i = 0; i < segments; i++) {
          const theta = angleRef.current - i * dTheta;
          points.push(new THREE.Vector3(
            Math.cos(theta) * radius - Math.cos(angleRef.current) * radius,
            0,
            Math.sin(theta) * radius - Math.sin(angleRef.current) * radius
          ));
        }
        trailRef.current.setPoints(points);
      }
    } else {
      // Highway straight movement
      let currentPos = droneRef.current.position.x;
      if (type === 'z') currentPos = droneRef.current.position.z;

      currentPos += speed * 22 * delta * direction;
      if (currentPos > 120) currentPos = -120;
      if (currentPos < -120) currentPos = 120;

      if (type === 'x') {
        droneRef.current.position.set(currentPos, height, center[1]);
        droneRef.current.rotation.y = direction > 0 ? Math.PI / 2 : -Math.PI / 2;
      } else {
        droneRef.current.position.set(center[0], height, currentPos);
        droneRef.current.rotation.y = direction > 0 ? 0 : Math.PI;
      }

      // Straight trailing points
      if (trailRef.current) {
        const points = [];
        for (let i = 0; i < 4; i++) {
          points.push(new THREE.Vector3(0, 0, -i * 1.5));
        }
        trailRef.current.setPoints(points);
      }
    }
  });

  return (
    <group ref={droneRef} position={initialPos as [number, number, number]}>
      {/* Drone fuselage */}
      <mesh castShadow={false}>
        <boxGeometry args={[0.3, 0.15, 0.6]} />
        <meshBasicMaterial color="#ffffff" toneMapped={false} />
      </mesh>
      {/* Side details */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.7, 0.04, 0.18]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      {/* High-quality trail */}
      <Line
        ref={trailRef}
        points={[new THREE.Vector3(0,0,0), new THREE.Vector3(0,0,-4)]}
        color={color}
        lineWidth={2.2}
        transparent
        opacity={0.65}
      />
    </group>
  );
}

function CityTraffic({ aliveProjects }: { aliveProjects: Project[] }) {
  const districts = useMemo(() => Array.from(new Set(aliveProjects.map(p => p.district))), [aliveProjects]);

  const droneSpecs = useMemo(() => {
    const list: any[] = [];
    
    // Create highway drones (around 22 drones)
    for (let i = 0; i < 22; i++) {
      const isX = i % 2 === 0;
      const xOffset = (Math.random() - 0.5) * 160;
      const zOffset = (Math.random() - 0.5) * 160;
      list.push({
        id: `highway-${i}`,
        isOrbit: false,
        type: isX ? 'x' : 'z' as any,
        center: [xOffset, zOffset] as [number, number],
        radius: 0,
        height: 7 + Math.random() * 28,
        speed: 0.3 + Math.random() * 0.8,
        color: Math.random() > 0.5 ? '#22d3ee' : '#e879f9'
      });
    }

    // Create orbiting drones (around district spires/centers)
    districts.forEach((d) => {
      const center = DISTRICT_CENTERS[d] || DISTRICT_CENTERS.default;
      const theme = THEMES[d] || THEMES.default;
      
      list.push({
        id: `orbit-${d}-1`,
        isOrbit: true,
        type: 'x' as any,
        center: center as [number, number],
        radius: 11 + Math.random() * 5,
        height: 8 + Math.random() * 12,
        speed: 0.4 + Math.random() * 0.4,
        color: theme.color
      });

      list.push({
        id: `orbit-${d}-2`,
        isOrbit: true,
        type: 'x' as any,
        center: center as [number, number],
        radius: 16 + Math.random() * 8,
        height: 14 + Math.random() * 14,
        speed: 0.25 + Math.random() * 0.35,
        color: theme.color
      });
    });

    return list;
  }, [districts]);

  return (
    <group>
      {droneSpecs.map((spec) => (
        <Drone
          key={spec.id}
          type={spec.type}
          center={spec.center}
          radius={spec.radius}
          height={spec.height}
          speed={spec.speed}
          color={spec.color}
          isOrbit={spec.isOrbit}
        />
      ))}
    </group>
  );
}

function CityEnvironment({ 
  aliveProjects, 
  deadProjects, 
  onProjectClick, 
  revivingIds, 
  selectedProject, 
  onRevive, 
  close 
}: { 
  aliveProjects: Project[], 
  deadProjects: Project[], 
  onProjectClick: (p: Project) => void, 
  revivingIds: Set<number | string>, 
  selectedProject: Project | null, 
  onRevive: (id: string | number) => void, 
  close: () => void 
}) {
  const controlsRef = useRef<CameraControls>(null);

  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.smoothTime = 1.0;
      controlsRef.current.draggingSmoothTime = 0.1;
    }
  }, []);

  useEffect(() => {
    if (selectedProject && controlsRef.current) {
      const pos = getProjectPosition(selectedProject, aliveProjects, deadProjects);
      controlsRef.current.smoothTime = 1.2;
      controlsRef.current.setLookAt(
        pos.x + 8, pos.y + 12, pos.z + 15,
        pos.x, pos.y + 3, pos.z,
        true
      );
    } else if (controlsRef.current) {
      controlsRef.current.smoothTime = 2.0;
      // Low angle cinematic framing of the city
      controlsRef.current.setLookAt(0, 35, 110, 0, 2, 0, true);
    }
  }, [selectedProject, aliveProjects, deadProjects]);

  useFrame((_state, delta) => {
    // Cinematic idle camera drift when no project is selected
    if (!selectedProject && controlsRef.current) {
      controlsRef.current.rotate(0.065 * delta, 0, false);
    }
  });

  return (
    <group>
      <CameraControls 
        ref={controlsRef} 
        maxPolarAngle={Math.PI / 2 - 0.05}
        minDistance={5}
        maxDistance={250}
        makeDefault
      />
      
      {aliveProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray() as [number, number, number]}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={false}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      <Float speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
        <Text 
          position={[0, 0.5, 60]} 
          fontSize={3} 
          color="#ff0000" 
          rotation={[-Math.PI/2, 0, 0]} 
          fillOpacity={0.3}
          outlineWidth={0.05} 
          outlineColor="black"
          font="https://fonts.gstatic.com/s/orbitron/v25/yq5sZ5O8r_b6t9C8oKizRfk.woff"
        >
          GRAVEYARD
        </Text>
      </Float>
      
      {deadProjects.map((p: Project) => (
        <BuildingNode 
          key={p.id}
          project={p}
          position={getProjectPosition(p, aliveProjects, deadProjects).toArray() as [number, number, number]}
          onClick={onProjectClick}
          isReviving={revivingIds.has(p.id)}
          isDead={true}
          isSelected={selectedProject?.id === p.id}
          onRevive={onRevive}
          close={close}
        />
      ))}

      <DistrictFloor aliveProjects={aliveProjects} />
      <GlowingRoads aliveProjects={aliveProjects} />

      {/* Main City Grid with subtle blue tech colors */}
      <Grid
        position={[0, -0.01, 0]}
        args={[300, 300]}
        cellSize={5}
        cellThickness={1}
        cellColor="#0891b2"
        sectionSize={25}
        sectionThickness={1.5}
        sectionColor="#22d3ee"
        fadeDistance={150}
        fadeStrength={1.5}
      />
      
      {/* Graveyard red warning grid */}
      <Grid
        position={[0, -0.02, 80]}
        args={[150, 100]}
        cellSize={5}
        cellThickness={1}
        cellColor="#660000"
        sectionSize={25}
        sectionThickness={1.5}
        sectionColor="#ff0000"
        fadeDistance={100}
        fadeStrength={2}
      />
      
      <ContactShadows resolution={1024} scale={200} blur={2.5} opacity={0.6} far={20} color="#000000" />
      <Environment preset="night" />
      <CityTraffic aliveProjects={aliveProjects} />
      
      {/* Volumetric low-altitude dust particles */}
      <Sparkles count={350} scale={[180, 12, 180]} position={[0, 6, 0]} size={1.5} speed={0.15} opacity={0.35} color="#22d3ee" />
      
      {/* Deep stars with slow twinkle */}
      <Stars radius={150} depth={50} count={3500} factor={3.5} saturation={0.5} fade speed={1.2} />
    </group>
  );
}

export function City3D({ aliveProjects, deadProjects, selectedProject, setSelectedProject, onRevive, revivingIds, timeColors }: { 
  aliveProjects: Project[], 
  deadProjects: Project[], 
  selectedProject: Project | null,
  setSelectedProject: (p: Project | null) => void,
  onRevive: (id: string | number) => void,
  revivingIds: Set<number | string>, 
  timeColors: Record<string, string> 
}) {
  return (
    <div className="absolute inset-0 w-full h-full z-10 pointer-events-auto bg-[#020203]">
      <Canvas shadows camera={{ position: [0, 50, 90], fov: 45 }}>
        {/* Cinematic exponential fog */}
        <fogExp2 attach="fog" args={['#030308', 0.0065]} />
        
        {/* Soft, rich sky/ground ambient hemisphere gradient */}
        <hemisphereLight args={['#0e1622', '#020205', 0.55]} />
        
        {/* Multi-light setup: Warm Key Light, Cool Fill Light, and Edge/Rim Light */}
        <directionalLight
          castShadow
          position={[45, 60, 45]}
          intensity={1.8}
          color={timeColors?.ambientLight || '#ffeaa7'} // warm key light
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={250}
          shadow-camera-left={-120}
          shadow-camera-right={120}
          shadow-camera-top={120}
          shadow-camera-bottom={-120}
          shadow-bias={-0.0006}
        />
        
        <directionalLight
          position={[-50, 35, -50]}
          intensity={1.1}
          color="#0984e3" // cool blue fill light
        />

        <directionalLight
          position={[0, 15, -90]}
          intensity={1.4}
          color="#d946ef" // magenta rim light for cybernetic depth
        />
        
        {/* Ground level general environment glow point lights */}
        <pointLight position={[0, 10, -10]} intensity={1.2} color="#22d3ee" distance={100} />
        <pointLight position={[0, 5, 80]} intensity={1.5} color="#ff0000" distance={80} />
        
        <CityEnvironment 
          aliveProjects={aliveProjects}
          deadProjects={deadProjects}
          onProjectClick={setSelectedProject}
          revivingIds={revivingIds}
          selectedProject={selectedProject}
          onRevive={onRevive}
          close={() => setSelectedProject(null)}
        />
        
        <EffectComposer>
          {/* Well-tuned bloom for sci-fi glow without blowing out */}
          <Bloom luminanceThreshold={0.8} luminanceSmoothing={0.3} intensity={0.9} mipmapBlur />
          
          {/* Subtle cinematic chromatic aberration */}
          <ChromaticAberration offset={new THREE.Vector2(0.0003, 0.0003)} radialModulation={false} modulationOffset={0} />
          
          {/* Subtle noise grain for film-like texture */}
          <Noise opacity={0.012} premultiply />
          
          {/* Classic Vignette */}
          <Vignette eskil={false} offset={0.12} darkness={1.15} />
        </EffectComposer>
      </Canvas>
      
      {selectedProject && (
        <div className="absolute top-8 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="bg-black/80 border border-cyan-500/50 px-6 py-3 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.2)]">
            <h2 className="text-xl font-bold text-white tracking-widest uppercase">{selectedProject.name}</h2>
            <div className="text-xs text-cyan-400 font-mono tracking-widest text-center mt-1">ECHO AI CORE ACCESSED</div>
          </div>
        </div>
      )}
    </div>
  );
}