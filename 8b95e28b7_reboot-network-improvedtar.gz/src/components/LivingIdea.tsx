import React from 'react';

export default function LivingIdea({ upvotes = 0 }: { upvotes: number }) {
  // Base scale starts at 1, maxes out at 3 when upvotes >= 100
  const scale = Math.min(3, 1 + upvotes / 50);
  
  // Base opacity starts at 0.3, maxes out at 1 when upvotes >= 50
  const opacity = Math.min(1, 0.3 + upvotes / 50);
  
  // Hue shift: starts cyan (180), moves toward green/yellow/orange as it grows
  const hue = Math.max(0, 180 - (upvotes * 2));
  const color = `hsl(${hue}, 100%, 50%)`;

  return (
    <div style={{
      width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative'
    }}>
      {/* Outer glow */}
      <div style={{
        position: 'absolute',
        width: 16 * scale, height: 16 * scale,
        borderRadius: '50%',
        background: color,
        filter: `blur(${8 * scale}px)`,
        opacity: opacity * 0.5,
        animation: 'pulse 2s infinite ease-in-out'
      }} />

      {/* Core seed shape */}
      <svg
        width={16 * scale}
        height={16 * scale}
        viewBox="0 0 24 24"
        style={{
          filter: `drop-shadow(0 0 ${4 * scale}px ${color})`,
          opacity: opacity,
          transition: 'all 0.5s ease',
        }}
      >
        <path
          d="M12 2C8 2 4 6 4 10C4 16 12 22 12 22C12 22 20 16 20 10C20 6 16 2 12 2Z"
          fill={color}
          style={{ animation: 'breathe 3s infinite ease-in-out' }}
        />
        <circle cx="12" cy="10" r={2 * scale} fill="#fff" opacity="0.8" />
      </svg>

      <style>{`
        @keyframes pulse {
          0%, 100% { transform: scale(1); opacity: ${opacity * 0.4}; }
          50% { transform: scale(1.2); opacity: ${opacity * 0.8}; }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(0.95); }
          50% { transform: scale(1.05); }
        }
      `}</style>
    </div>
  );
}
