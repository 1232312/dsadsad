import React, { useState, useEffect } from 'react';
import { Network, Radar, GitBranch, Skull, Puzzle, MessageSquare, Gift, X, Lock } from 'lucide-react';

const features = [
  { id: 'connections', name: 'Idea Connections', icon: Network, color: '#A855F7', desc: 'Find hidden links across all projects.' },
  { id: 'radar', name: 'Opportunity Radar', icon: Radar, color: '#3B82F6', desc: 'Scan market gaps and emerging trends.' },
  { id: 'evolution', name: 'Idea Evolution', icon: GitBranch, color: '#10B981', desc: 'Track how an idea morphs over time.' },
  { id: 'graveyard', name: 'Graveyard Intelligence', icon: Skull, color: '#F97316', desc: 'Extract lessons from fallen startups.' },
  { id: 'fusion', name: 'Idea Fusion', icon: Puzzle, color: '#EAB308', desc: 'Merge multiple concepts into one hybrid.' },
  { id: 'talk', name: 'Talk to Echo', icon: MessageSquare, color: '#EF4444', desc: 'Direct access to the neural network.' }
];

import { useAuth } from "../lib/auth";
import { db } from "../lib/firebase";
import { collection, getCountFromServer } from "firebase/firestore";
import { TuesdayGiveawayModal } from "../components/TuesdayGiveawayModal";
const isAdmin = (uid?: string) => uid === 'ZHMdWsiKfVO7UQNu9d8P7bNld7N2';

export default function AILab() {
  const { user } = useAuth();
  const [activeState, setActiveState] = useState<'idle' | 'expanded'>('idle');
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [openModal, setOpenModal] = useState<typeof features[0] | null>(null);
  const [showGiveaway, setShowGiveaway] = useState(false);
  const [particles, setParticles] = useState<{x: number, y: number, r: number, vx: number, vy: number, opacity: number}[]>([]);
  const [orbs, setOrbs] = useState<{angle: number, speed: number, dist: number, size: number, color: string, pulse: number}[]>([]);
  const [userCount, setUserCount] = useState<number>(0);

  useEffect(() => {
    // Generate background particles (stars / neural pathways)
    const pts = Array.from({ length: 80 }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      r: Math.random() * 1.5 + 0.5,
      vx: (Math.random() - 0.5) * 0.05,
      vy: (Math.random() - 0.5) * 0.05,
      opacity: Math.random() * 0.5 + 0.1
    }));
    setParticles(pts);

    // Generate orbiting project orbs
    const projectOrbs = Array.from({ length: 15 }).map(() => ({
      angle: Math.random() * Math.PI * 2,
      speed: (Math.random() * 0.01 + 0.005) * (Math.random() > 0.5 ? 1 : -1),
      dist: Math.random() * 80 + 120, // Orbit distance
      size: Math.random() * 4 + 2,
      color: ['#A855F7', '#3B82F6', '#10B981', '#F97316', '#EAB308', '#EF4444'][Math.floor(Math.random() * 6)],
      pulse: Math.random() * 2
    }));
    setOrbs(projectOrbs);

    getCountFromServer(collection(db, 'users')).then(s => setUserCount(s.data().count)).catch(() => setUserCount(11248)); // fallback

    const int = setInterval(() => {
      setParticles(prev => prev.map(p => ({
        ...p,
        x: (p.x + p.vx + 100) % 100,
        y: (p.y + p.vy + 100) % 100
      })));
      setOrbs(prev => prev.map(o => ({
        ...o,
        angle: o.angle + o.speed,
        pulse: (o.pulse + 0.05) % (Math.PI * 2)
      })));
    }, 50);
    return () => clearInterval(int);
  }, []);

  console.log({
    action: "DEBUG_GIVEAWAY_VISIBILITY",
    uid: user?.uid,
    isAdmin: isAdmin(user?.uid),
    userCount: userCount,
    meetsThreshold: userCount >= 100000
  });

  return (
    <div style={{
      width: '100%', minHeight: '100vh', background: '#05050A',
      position: 'relative', overflow: 'hidden', color: '#fff',
      display: 'flex', flexDirection: 'column'
    }}>
      {/* Dynamic Background Universe */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.6 }}>
        {/* Perspective Grid */}
        <div style={{
          position: 'absolute', inset: -500,
          backgroundImage: 'linear-gradient(rgba(139, 92, 246, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(139, 92, 246, 0.1) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
          transform: 'perspective(500px) rotateX(60deg) translateY(-100px) translateZ(-200px)',
          animation: 'gridMove 15s linear infinite'
        }} />
        
        {/* Particles */}
        {particles.map((p, i) => (
          <div key={i} style={{
            position: 'absolute', left: `${p.x}%`, top: `${p.y}%`,
            width: p.r * 2, height: p.r * 2, borderRadius: '50%',
            background: '#A855F7', opacity: p.opacity,
            boxShadow: '0 0 10px #A855F7'
          }} />
        ))}
      </div>

      <div style={{ position: 'relative', zIndex: 10, flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', paddingTop: 80, paddingBottom: 80 }}>
        
        {/* Connection Lines (Animate Outward) */}
        {activeState === 'expanded' && (
          <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="600" height="600" viewBox="-300 -300 600 600" style={{ overflow: 'visible' }}>
              {features.map((feat, i) => {
                const angle = (i / features.length) * Math.PI * 2;
                const isHovered = activeFeature === feat.id;
                const opacity = activeFeature ? (isHovered ? 1 : 0.1) : 0.4;
                const strokeColor = feat.color;
                
                return (
                  <g key={`line-${i}`} style={{ opacity, transition: 'opacity 0.3s' }}>
                    <line 
                      x1="0" y1="0" 
                      x2={Math.cos(angle) * 280} y2={Math.sin(angle) * 280} 
                      stroke={strokeColor} strokeWidth={isHovered ? 2 : 1} strokeDasharray="4 8"
                      style={{ filter: isHovered ? `drop-shadow(0 0 8px ${strokeColor})` : 'none' }}
                    />
                    {/* Glowing pulse moving outward */}
                    {isHovered && (
                      <circle r="3" fill="#fff" style={{ filter: `drop-shadow(0 0 5px #fff)` }}>
                        <animateMotion 
                          path={`M 0 0 L ${Math.cos(angle) * 280} ${Math.sin(angle) * 280}`} 
                          dur="1.5s" repeatCount="indefinite" 
                        />
                      </circle>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        )}

        {/* Orbiting Projects (Shows when expanded) */}
        {activeState === 'expanded' && (
          <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 35 }}>
             {orbs.map((orb, i) => {
                const x = Math.cos(orb.angle) * orb.dist;
                const y = Math.sin(orb.angle) * orb.dist;
                const opacity = (Math.sin(orb.pulse) + 1) / 2 * 0.5 + 0.3; // 0.3 to 0.8
                return (
                  <div key={`orb-${i}`} style={{
                    position: 'absolute',
                    transform: `translate(${x}px, ${y}px)`,
                    width: orb.size, height: orb.size,
                    borderRadius: '50%',
                    background: orb.color,
                    opacity,
                    boxShadow: `0 0 ${orb.size * 3}px ${orb.color}`,
                    transition: 'all 0.1s linear'
                  }} />
                );
             })}
          </div>
        )}

        {/* Brain Center */}
        <div 
          onClick={() => setActiveState(prev => prev === 'idle' ? 'expanded' : 'idle')}
          style={{
            position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
            width: 140, height: 140, zIndex: 50, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}
        >
          {/* Depth rings */}
          <div style={{ position: 'absolute', inset: -40, border: '1px solid rgba(168,85,247,0.2)', borderRadius: '50%', animation: 'spinSlow 20s linear infinite' }} />
          <div style={{ position: 'absolute', inset: -20, border: '1px dashed rgba(168,85,247,0.3)', borderRadius: '50%', animation: 'spinSlow 15s linear infinite reverse' }} />
          
          <div style={{
            position: 'relative', width: 100, height: 100,
            animation: 'floatBrain 4s ease-in-out infinite'
          }}>
            {/* Core Glow */}
            <div style={{
              position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(168,85,247,0.4) 0%, transparent 70%)',
              animation: 'heartbeat 3s ease-in-out infinite'
            }} />
            
            <svg viewBox="0 0 100 100" width="100%" height="100%" style={{ 
              filter: 'drop-shadow(0 0 15px rgba(168,85,247,0.6))',
              transform: activeFeature ? 'scale(1.05)' : 'scale(1)',
              transition: 'transform 0.3s'
            }}>
              {/* Brain Outline/Shape */}
              <path d="M 50 15 C 30 15 15 30 15 50 C 15 60 20 70 30 75 C 35 85 45 90 50 90 C 55 90 65 85 70 75 C 80 70 85 60 85 50 C 85 30 70 15 50 15 Z" 
                 fill="rgba(10,10,18,0.8)" stroke="#A855F7" strokeWidth="1" strokeDasharray="2 4" />
              <path d="M 50 20 C 35 20 22 32 22 50 C 22 62 30 70 38 72 C 42 80 48 85 50 85 C 52 85 58 80 62 72 C 70 70 78 62 78 50 C 78 32 65 20 50 20 Z" 
                 fill="rgba(168,85,247,0.15)" stroke="rgba(168,85,247,0.8)" strokeWidth="1.5" />
              
              {/* Midline separator */}
              <line x1="50" y1="20" x2="50" y2="85" stroke="rgba(168,85,247,0.6)" strokeWidth="1" strokeDasharray="1 3" />
              
              {/* Neural pathways & synapses */}
              <g stroke="rgba(168,85,247,0.9)" strokeWidth="0.5" fill="none">
                <path d="M 50 30 Q 35 25 25 40 T 30 60" />
                <path d="M 50 30 Q 65 25 75 40 T 70 60" />
                <path d="M 50 45 Q 40 40 35 55 T 45 70" />
                <path d="M 50 45 Q 60 40 65 55 T 55 70" />
              </g>
              
              {/* Firing Neurons */}
              <circle cx="35" cy="40" r="1.5" fill="#fff" style={{ animation: 'blink 2s infinite' }} />
              <circle cx="65" cy="40" r="1.5" fill="#fff" style={{ animation: 'blink 3s infinite 1s' }} />
              <circle cx="30" cy="60" r="2" fill="#fff" style={{ animation: 'blink 1.5s infinite 0.5s', filter: 'drop-shadow(0 0 4px #fff)' }} />
              <circle cx="70" cy="60" r="2" fill="#fff" style={{ animation: 'blink 2.5s infinite 1.2s', filter: 'drop-shadow(0 0 4px #fff)' }} />
              <circle cx="50" cy="30" r="2.5" fill="#A855F7" style={{ filter: 'blur(1px)', animation: 'pulseNode 2s infinite' }} />
              
              {/* Electricity arcs */}
              <path d="M 40 40 Q 45 45 50 40 T 60 40" stroke="#fff" strokeWidth="0.8" fill="none" style={{ animation: 'electricity 4s infinite' }} />
              <path d="M 30 60 Q 40 50 50 65 T 70 60" stroke="#A855F7" strokeWidth="0.5" fill="none" style={{ animation: 'electricity 5s infinite 1s' }} />
            </svg>
          </div>
        </div>

        {/* Orbiting Interface (Shows when expanded) */}
        <div style={{
          position: 'absolute', inset: 0,
          opacity: activeState === 'expanded' ? 1 : 0,
          pointerEvents: activeState === 'expanded' ? 'all' : 'none',
          transition: 'opacity 1s ease',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 40
        }}>
          {features.map((feat, i) => {
            const angle = (i / features.length) * Math.PI * 2;
            const radius = 280;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            const isHovered = activeFeature === feat.id;
            const opacity = activeFeature ? (isHovered ? 1 : 0.3) : 1;

            return (
              <div
                key={feat.id}
                onMouseEnter={() => setActiveFeature(feat.id)}
                onClick={() => setOpenModal(feat)}
                onMouseLeave={() => setActiveFeature(null)}
                style={{
                  position: 'absolute',
                  transform: `translate(${x}px, ${y}px)`,
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
                  width: 160, opacity,
                  transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)',
                  zIndex: isHovered ? 60 : 40,
                }}
              >
                <div style={{
                  width: 56, height: 56, borderRadius: '50%',
                  background: isHovered ? `${feat.color}20` : 'rgba(15,15,24,0.8)',
                  border: `1px solid ${isHovered ? feat.color : 'rgba(255,255,255,0.15)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: isHovered ? `0 0 30px ${feat.color}60, inset 0 0 10px ${feat.color}40` : '0 4px 12px rgba(0,0,0,0.5)',
                  backdropFilter: 'blur(10px)',
                  color: isHovered ? '#fff' : feat.color,
                  cursor: 'pointer',
                  transform: isHovered ? 'scale(1.2)' : 'scale(1)',
                  transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)'
                }}>
                  <feat.icon size={24} />
                </div>
                
                <div style={{
                  transform: isHovered ? 'translateY(5px)' : 'translateY(0)',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  width: '100%'
                }}>
                  <p style={{ 
                    fontSize: 13, fontWeight: 700, 
                    color: isHovered ? '#fff' : 'rgba(255,255,255,0.8)', 
                    letterSpacing: '0.05em', 
                    textShadow: isHovered ? `0 0 10px ${feat.color}` : 'none',
                    transition: 'all 0.3s'
                  }}>
                    {feat.name}
                  </p>
                </div>

                {/* Feature Description Tooltip */}
                {isHovered && (
                  <div style={{
                    position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)',
                    width: 260, padding: '16px 20px', marginTop: 16,
                    background: 'rgba(10,10,15,0.95)', border: `1px solid ${feat.color}50`,
                    borderRadius: 16, boxShadow: `0 20px 50px rgba(0,0,0,0.8), 0 0 20px ${feat.color}20`,
                    animation: 'fadeUp 0.3s cubic-bezier(0.16,1,0.3,1) both',
                    pointerEvents: 'none'
                  }}>
                    <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.9)', lineHeight: 1.6, textAlign: 'center' }}>
                      {feat.desc}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Central status text / Echo Status */}
        <div style={{
          position: 'absolute', bottom: '10%', left: '50%', transform: 'translateX(-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16,
          opacity: 1, // Always visible or change based on state
          transition: 'opacity 0.5s ease',
          pointerEvents: 'none',
          background: 'rgba(10,10,15,0.8)', padding: '20px 32px', borderRadius: 24, 
          border: '1px solid rgba(168,85,247,0.2)',
          boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
          backdropFilter: 'blur(20px)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#A855F7', boxShadow: '0 0 12px #A855F7', animation: 'blink 2s infinite' }} />
            <p style={{ fontSize: 14, color: '#fff', fontWeight: 700, letterSpacing: '0.1em' }}>ECHO</p>
          </div>
          
          <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'center' }}>
            <p style={{ fontSize: 12, color: '#A855F7', fontFamily: 'monospace' }}>Analyzing...</p>
            <div style={{ display: 'flex', gap: 2 }}>
              {Array.from({ length: 15 }).map((_, i) => (
                <div key={i} style={{ 
                  width: 10, height: 4, 
                  background: i < 10 ? '#A855F7' : 'rgba(255,255,255,0.1)',
                  borderRadius: 2,
                  animation: i < 10 ? `pulseOpacity 1.5s infinite ${i * 0.1}s` : 'none'
                }} />
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 24, marginTop: 8 }}>
             <div style={{ textAlign: 'center' }}>
               <p style={{ fontSize: 16, fontWeight: 700, color: '#fff', fontFamily: 'monospace' }}>11,248</p>
               <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Projects</p>
             </div>
             <div style={{ width: 1, background: 'rgba(255,255,255,0.1)' }} />
             <div style={{ textAlign: 'center' }}>
               <p style={{ fontSize: 16, fontWeight: 700, color: '#fff', fontFamily: 'monospace' }}>1.8M</p>
               <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Connections</p>
             </div>
             <div style={{ width: 1, background: 'rgba(255,255,255,0.1)' }} />
             <div style={{ textAlign: 'center' }}>
               <p style={{ fontSize: 16, fontWeight: 700, color: '#10B981', fontFamily: 'monospace' }}>73</p>
               <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Patterns Today</p>
             </div>
          </div>
        </div>

      </div>


      {/* Feature Modal */}
      {openModal && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 100,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(2,2,12,0.8)', backdropFilter: 'blur(10px)'
        }}>
          <div style={{
            background: 'rgba(10,10,15,0.95)', border: `1px solid ${openModal.color}50`,
            borderRadius: 24, padding: 40, maxWidth: 500, width: '90%',
            boxShadow: `0 20px 50px rgba(0,0,0,0.8), 0 0 40px ${openModal.color}20`,
            position: 'relative', animation: 'fadeUp 0.3s ease-out'
          }}>
            <button 
              onClick={() => setOpenModal(null)}
              style={{ position: 'absolute', top: 20, right: 20, color: 'rgba(255,255,255,0.5)', cursor: 'pointer', background: 'none', border: 'none' }}
            >
              <X size={24} />
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
              <div style={{
                width: 64, height: 64, borderRadius: '50%',
                background: `${openModal.color}20`, border: `1px solid ${openModal.color}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: openModal.color
              }}>
                {React.createElement(openModal.icon, { size: 32 })}
              </div>
              <div>
                <h2 style={{ fontSize: 24, fontWeight: 700, color: '#fff', margin: 0 }}>{openModal.name}</h2>
                <p style={{ color: openModal.color, fontSize: 14, fontFamily: 'monospace' }}>STATUS: ONLINE</p>
              </div>
            </div>
            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 16, lineHeight: 1.6, marginBottom: 32 }}>
              {openModal.desc}
            </p>
            
            <div style={{ padding: 20, background: 'rgba(255,255,255,0.03)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                <Lock size={16} color="rgba(255,255,255,0.5)" />
                <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Authentication Required</span>
              </div>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13, lineHeight: 1.5, margin: 0 }}>
                This Echo capability requires Level 3 neural synchronization. Please continue contributing to the collective knowledge base to unlock this feature.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Giveaway Button (Only for Admin) */}
      {isAdmin(user?.uid) && (
        <>
          <button 
            onClick={() => setShowGiveaway(true)}
            style={{
              position: 'fixed', bottom: 30, right: 30, zIndex: 90,
              width: 60, height: 60, borderRadius: '50%',
              background: 'linear-gradient(135deg, #FF00CC 0%, #3B82F6 100%)',
              border: '2px solid rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 10px 20px rgba(0,0,0,0.5), 0 0 20px rgba(255,0,204,0.4)',
              cursor: 'pointer', color: '#fff',
              transition: 'transform 0.2s, box-shadow 0.2s',
              animation: 'floatingPulse 2.5s ease-in-out infinite'
            }}
            onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.currentTarget.style.transform = ''}
          >
            <Gift size={28} />
          </button>
          
          {/* Giveaway Modal */}
          {showGiveaway && (
            <TuesdayGiveawayModal onClose={() => setShowGiveaway(false)} userCount={userCount} />
          )}
        </>
      )}

      <style>{`
        @keyframes floatBrain {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-15px); }
        }
        @keyframes heartbeat {
          0%, 100% { opacity: 0.4; transform: scale(0.95); }
          15% { opacity: 0.8; transform: scale(1.05); }
          30% { opacity: 0.4; transform: scale(0.95); }
          45% { opacity: 0.7; transform: scale(1.02); }
          60% { opacity: 0.4; transform: scale(0.95); }
        }
        @keyframes blink {
          0%, 100% { opacity: 0.1; }
          50% { opacity: 1; }
        }
        @keyframes pulseNode {
          0%, 100% { transform: scale(0.8); opacity: 0.6; }
          50% { transform: scale(1.3); opacity: 1; }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translate(-50%, 10px); }
          to { opacity: 1; transform: translate(-50%, 0); }
        }
        @keyframes electricity {
          0%, 100% { opacity: 0; stroke-dasharray: 0 100; stroke-dashoffset: 0; }
          10% { opacity: 1; stroke-dasharray: 20 80; stroke-dashoffset: -20; }
          20% { opacity: 0; stroke-dasharray: 0 100; stroke-dashoffset: -40; }
        }
        @keyframes spinSlow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes gridMove {
          from { background-position: 0 0; }
          to { background-position: 0 40px; }
        }
        @keyframes pulseOpacity {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }
        @keyframes floatingPulse {
          0%, 100% { transform: translateY(0); box-shadow: 0 10px 20px rgba(0,0,0,0.5), 0 0 20px rgba(255,0,204,0.4); }
          50% { transform: translateY(-8px); box-shadow: 0 15px 25px rgba(0,0,0,0.6), 0 0 35px rgba(255,0,204,0.7); }
        }
      `}</style>
    </div>
  );
}
