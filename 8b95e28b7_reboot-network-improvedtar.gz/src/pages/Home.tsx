import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, doc, getDocs } from 'firebase/firestore';
import { db, Idea } from '../lib/firebase';
import { Zap, Heart } from 'lucide-react';
import { motion } from 'framer-motion';
import WeatherSystem from "../components/WeatherSystem";
import CityScene from '../components/CityScene';

export default function Home({ onIdeaSelect }: { onIdeaSelect: (idea: Idea) => void, onExplore: () => void }) {
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [hoveredIdea, setHoveredIdea] = useState<Idea | null>(null);
  const [globalEnergy, setGlobalEnergy] = useState(0); 

  useEffect(() => {
    // Subscribe to global energy
    const unsubEnergy = onSnapshot(doc(db, 'system', 'global_energy'), (docSnap) => {
      if (docSnap.exists()) {
        const val = docSnap.data().current || 0;
        setGlobalEnergy(Math.min(100, val));
      }
    });

    const fetchIdeas = async () => {
      try {
        const snap = await getDocs(collection(db, 'ideas'));
        const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() } as Idea));
        setIdeas(loaded);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchIdeas();

    return () => {
      unsubEnergy();
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100vh', background: '#020205', overflow: 'hidden' }}>
      
      {/* City Scene 3D Canvas */}
      {!loading && (
        <CityScene 
          ideas={ideas} 
          onHover={setHoveredIdea} 
          onClick={onIdeaSelect} 
        />
      )}

      {/* UI Overlay */}
      <div style={{ position: 'absolute', top: 32, left: '50%', transform: 'translateX(-50%)', width: 400, zIndex: 10, pointerEvents: 'none' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#00FFFF', fontFamily: "'Share Tech Mono', monospace", textShadow: '0 0 10px #00FFFF' }}>
            <Zap size={16} /> REBOOT CITY
          </div>
          <div style={{ color: '#fff', fontFamily: 'monospace', fontWeight: 'bold' }}>{globalEnergy}%</div>
        </div>
        <div style={{ height: 6, background: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden', boxShadow: '0 0 10px rgba(0,255,255,0.2)' }}>
          <motion.div 
            style={{ height: '100%', background: '#00FFFF', boxShadow: '0 0 20px #00FFFF' }}
            animate={{ width: `${globalEnergy}%` }}
            transition={{ type: 'spring', stiffness: 50 }}
          />
        </div>
      </div>

      {loading && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(0,255,255,0.5)', fontFamily: 'monospace', letterSpacing: '0.2em', zIndex: 20 }}>
          LOADING REBOOT CITY...
        </div>
      )}

      <WeatherSystem energy={globalEnergy} />
      {new Date().getDay() === 5 && (
        <motion.div 
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          style={{
            position: "absolute", top: 100, right: 32,
            background: "rgba(255, 59, 92, 0.1)", border: "1px solid rgba(255, 59, 92, 0.5)",
            padding: "16px 24px", borderRadius: 12, backdropFilter: "blur(10px)",
            zIndex: 20
          }}
        >
          <div style={{ color: "#FF3B5C", fontFamily: "monospace", fontWeight: "bold", fontSize: 14 }}>
            UNKNOWN SIGNAL DETECTED
          </div>
          <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, marginTop: 4 }}>
            12 Minutes Remaining
          </div>
        </motion.div>
      )}
      {/* Hovered Idea Hologram */}
      {hoveredIdea && (
        <motion.div 
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          style={{ 
            position: 'absolute', bottom: 40, left: 40,
            background: 'rgba(10,10,18,0.85)', border: '1px solid rgba(0,255,255,0.3)',
            borderRadius: 16, padding: 24, width: 320, pointerEvents: 'none',
            backdropFilter: 'blur(20px)', boxShadow: '0 20px 60px rgba(0,0,0,0.8), inset 0 0 30px rgba(0,255,255,0.05)',
            zIndex: 30
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
            <span className={`chip chip-${hoveredIdea.status}`}>{hoveredIdea.status.replace('_', ' ').toUpperCase()}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#F59E0B', fontFamily: 'monospace', fontSize: 12 }}>
              <Heart size={12} fill="#F59E0B" /> {hoveredIdea.upvotes || 0}
            </div>
          </div>
          <h3 style={{ fontSize: 18, color: '#fff', margin: '0 0 8px 0', fontFamily: 'Inter, sans-serif' }}>{hoveredIdea.title}</h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 16, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
            <div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', fontFamily: 'monospace' }}>Owner</div>
              <div style={{ fontSize: 13, color: '#fff' }}>{hoveredIdea.creator_name || 'Anonymous'}</div>
            </div>
            <div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', fontFamily: 'monospace' }}>AI Score</div>
              <div style={{ fontSize: 13, color: '#00FFFF' }}>{hoveredIdea.potential_score || 0}%</div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Tutorial / Help text */}
      <div style={{ position: 'absolute', bottom: 40, right: 40, color: 'rgba(255,255,255,0.3)', fontFamily: 'monospace', fontSize: 12, textAlign: 'right', pointerEvents: 'none', zIndex: 20 }}>
        SCROLL TO ZOOM<br/>
        DRAG TO PAN<br/>
        CLICK BUILDING TO EXAMINE
      </div>
    </div>
  );
}
