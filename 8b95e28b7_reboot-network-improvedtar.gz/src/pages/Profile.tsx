import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/auth';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db, UserAchievement, Idea } from '../lib/firebase';
import { Trophy, Award, Star, Zap, Clock, Shield, Flame, Share2, Copy, CheckCircle2 } from 'lucide-react';
import { calculateXP, getRankInfo } from '../lib/ranks';
import CityScene from '../components/CityScene';
import IdeaModal from '../components/IdeaModal';
import { motion } from 'framer-motion';

const ACHIEVEMENTS_DATA: Record<string, { label: string; icon: React.FC<{ size?: number; color?: string }>; color: string; rarity: string; desc: string }> = {
  first_idea: { label: 'First Idea Published', icon: Star, color: '#4F8CFF', rarity: 'common', desc: 'Published your very first idea to the graveyard.' },
  active_10_days: { label: '10 Days Active', icon: Clock, color: '#10B981', rarity: 'common', desc: 'Logged in and explored for 10 days.' },
  idea_revived: { label: 'Idea Revived', icon: Zap, color: '#F59E0B', rarity: 'legendary', desc: 'One of your ideas was revived by the community.' },
  veteran: { label: 'Graveyard Veteran', icon: Shield, color: '#8B5CF6', rarity: 'rare', desc: 'An active contributor to the startup graveyard.' },
  streak_7: { label: '7-Day Streak', icon: Flame, color: '#EF4444', rarity: 'rare', desc: 'Engaged with ideas for 7 consecutive days.' },
  first_share: { label: 'Spreading the Word', icon: Share2, color: '#10B981', rarity: 'common', desc: 'Shared the app or an idea with the world.' },
  master_sharer: { label: 'Master Promoter', icon: Zap, color: '#F59E0B', rarity: 'rare', desc: 'Used your referral link to spread awareness.' },
};

export default function Profile() {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<UserAchievement[]>([]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [referralCount, setReferralCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch user achievements
        const achvQuery = query(collection(db, 'user_achievements'), where('user_id', '==', user.uid));
        const achvSnapshot = await getDocs(achvQuery);
        const fetchedAchievements = achvSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as UserAchievement));
        
        // Fetch user's ideas
        const ideasQuery = query(collection(db, 'ideas'), where('creator_name', '==', user.displayName || user.email?.split('@')[0] || 'Anonymous'));
        const ideasSnapshot = await getDocs(ideasQuery);
        const fetchedIdeas = ideasSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Idea));

        // Fetch referrals
        let refs = 0;
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          refs = userDoc.data().referrals || 0;
          setReferralCount(refs);
        }

        // Keep to actual achievements without mocking 100 of them
        setAchievements(fetchedAchievements);
        setIdeas(fetchedIdeas);
      } catch (error) {
        console.error('Error fetching profile data', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [user]);

  const handleCopyLink = async () => {
    if (!user) return;
    const shareUrl = `${window.location.origin}/?ref=${user.uid}`;
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return (
    <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ width: 32, height: 32, border: '2px solid rgba(79,140,255,0.2)', borderTopColor: '#4F8CFF', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
    </div>
  );

  const totalUpvotes = ideas.reduce((acc, i) => acc + (i.upvotes || 0), 0);
  const xp = calculateXP(ideas.length, achievements.length, referralCount, totalUpvotes);
  const { currentRank, nextRank } = getRankInfo(xp);
  
  const progressToNext = nextRank.xp > currentRank.xp 
    ? ((xp - currentRank.xp) / (nextRank.xp - currentRank.xp)) * 100 
    : 100;

  return (
    <div style={{ padding: '40px 0', maxWidth: 1000, margin: '0 auto', fontFamily: 'Inter, sans-serif' }}>
      {/* Rank Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        style={{
          display: 'flex', alignItems: 'center', gap: 32, padding: 40, borderRadius: 24,
          background: 'rgba(10,10,18,0.8)', border: `1px solid ${currentRank.effects.border}`,
          boxShadow: `0 20px 60px rgba(0,0,0,0.5), inset 0 0 40px ${currentRank.effects.glow}`,
          position: 'relative', overflow: 'hidden', marginBottom: 40
        }}
      >
        <div style={{
          position: 'absolute', top: -50, right: -50, width: 200, height: 200,
          background: currentRank.effects.border, filter: 'blur(100px)', opacity: 0.3, pointerEvents: 'none'
        }} />
        
        <div style={{
          width: 100, height: 100, borderRadius: '50%',
          background: currentRank.effects.border, display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 0 30px ${currentRank.effects.glow}`, position: 'relative'
        }}>
          <Trophy size={48} color="#000" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.5)', fontFamily: 'monospace', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
            Current Rank
          </div>
          <h1 style={{ fontSize: 48, fontWeight: 900, color: '#fff', margin: '4px 0 12px', textShadow: `0 0 20px ${currentRank.effects.glow}`, fontFamily: 'monospace' }}>
            {currentRank.name}
          </h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, height: 6, background: 'rgba(255,255,255,0.1)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ height: '100%', background: currentRank.effects.border, width: `${progressToNext}%`, boxShadow: `0 0 10px ${currentRank.effects.border}` }} />
            </div>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.6)', fontFamily: 'monospace' }}>
              {xp} / {nextRank.xp} XP
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Content Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 40 }}>
        {/* Left Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
          
          {/* Echo Brain */}
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 600, color: '#fff', margin: '0 0 20px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
              <Zap size={20} color="#00E5FF" /> My Personal District
            </h2>
            <div style={{ width: '100%', height: 400, position: 'relative', borderRadius: 16, overflow: 'hidden', border: '1px solid rgba(0, 229, 255, 0.2)' }}>
              <CityScene ideas={ideas} onHover={() => {}} onClick={setSelectedIdea} style={{ position: 'absolute', inset: 0 }} />
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 600, color: '#fff', margin: '0 0 20px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
              <Award size={20} color="#F59E0B" /> Unlocked Memory Badges
            </h2>
            {achievements.length === 0 ? (
              <div style={{ padding: 40, textAlign: 'center', background: 'rgba(255,255,255,0.02)', borderRadius: 16, border: '1px dashed rgba(255,255,255,0.1)' }}>
                <p style={{ color: 'rgba(255,255,255,0.4)' }}>No badges unlocked yet. Start exploring the graveyard.</p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
                {achievements.map((achv, i) => {
                  const data = ACHIEVEMENTS_DATA[achv.badge_type] || ACHIEVEMENTS_DATA.first_idea;
                  const Icon = data.icon;
                  return (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                      key={achv.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 16, padding: 20, background: 'rgba(15,15,21,0.6)', border: `1px solid rgba(255,255,255,0.05)`, borderRadius: 16 }}
                    >
                      <div style={{ width: 48, height: 48, borderRadius: 12, background: `${data.color}15`, border: `1px solid ${data.color}44`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Icon size={24} color={data.color} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#fff', margin: '0 0 4px 0' }}>{data.label}</h3>
                        <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', margin: 0, lineHeight: 1.4 }}>{data.desc}</p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column */}
        <div>
          {/* Referral Card */}
          <div style={{ padding: 24, background: 'linear-gradient(135deg, rgba(79, 140, 255, 0.05), rgba(139, 92, 246, 0.05))', border: '1px solid rgba(79, 140, 255, 0.2)', borderRadius: 16, position: 'sticky', top: 40 }}>
            <h2 style={{ fontSize: 18, fontWeight: 600, color: '#fff', margin: '0 0 12px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
              <Share2 size={18} color="#4F8CFF" /> Invite Friends
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.7)', margin: '0 0 20px 0', fontSize: 14, lineHeight: 1.5 }}>
              Share Graveyard. Successful referrals grant massive XP boosts.
            </p>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, padding: 12, background: 'rgba(0,0,0,0.3)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', fontFamily: 'monospace' }}>Referrals</div>
              <div style={{ fontSize: 20, fontWeight: 'bold', color: '#10B981', fontFamily: 'monospace' }}>{referralCount}</div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ 
                flex: 1, background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.1)', 
                padding: '12px', borderRadius: 8, fontFamily: 'monospace', color: 'rgba(255,255,255,0.6)', fontSize: 12,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
              }}>
                {window.location.origin}/?ref={user?.uid}
              </div>
              <button 
                onClick={handleCopyLink}
                style={{ background: '#4F8CFF', color: '#fff', border: 'none', padding: '12px', borderRadius: 8, cursor: 'pointer' }}
              >
                {copied ? <CheckCircle2 size={16} /> : <Copy size={16} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {selectedIdea && <IdeaModal idea={selectedIdea} onClose={() => setSelectedIdea(null)} />}
    </div>
  );
}
