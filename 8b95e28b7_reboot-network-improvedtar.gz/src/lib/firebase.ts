import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Data Types
export interface Idea {
  id: string;
  title: string;
  slug: string;
  short_desc: string;
  description: string;
  failure_story: string;
  last_words: string;
  why_died: string;
  almost_worked: string;
  category: string;
  status: 'abandoned' | 'seeking' | 'in_progress' | 'revived';
  potential_score: number;
  revival_score: number;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Expert';
  tech_stack: string[];
  cover_url?: string;
  creator_name: string;
  creator_avatar?: string;
  is_anonymous: boolean;
  founded_year?: number;
  abandoned_year?: number;
  time_invested: string;
  views: number;
  upvotes: number;
  revival_count: number;
  contributor_count: number;
  ai_analyzed: boolean;
  ai_summary: string;
  ai_strengths: string[];
  ai_weaknesses: string[];
  ai_market: string;
  ai_roadmap: string;
  ai_tech_stack: string[];
  ai_monetization: string;
  // Story features
  commits_count: number;
  users_count: number;
  revenue_made: number;
  months_built: number;
  failure_emotion: string;
  surviving_assets: SurvivingAsset[];
  almost_made_it: boolean;
  almost_milestones: string[];
  founder_update: string;
  letter_to_founder: string;
  skills_required: string[];
  created_at: string;
  updated_at: string;
}

export interface SurvivingAsset {
  label: string;
  exists: boolean;
}

export interface TimelineEvent {
  id?: string;
  idea_id?: string;
  emoji: string;
  label: string;
  description: string;
  milestone_date: string;
  sort_order: number;
}

export interface RevivalBounty {
  id?: string;
  idea_id?: string;
  mentorship: boolean;
  domain_handover: boolean;
  github_handover: boolean;
  equity_offer: string;
  cash_bounty: number;
  milestone_trigger: string;
  custom_offer: string;
}

export interface TimeCapsule {
  id?: string;
  idea_id?: string;
  repo_url: string;
  demo_url: string;
  figma_url: string;
  domain: string;
  screenshots: string[];
  readme_text: string;
  final_message: string;
  lessons_learned: string;
  last_commit_date: string;
}

export interface Resurrection {
  id: string;
  idea_id?: string;
  original_title: string;
  original_founder: string;
  reviver_name: string;
  reviver_handle: string;
  current_users: number;
  current_mrr: number;
  months_to_revival: number;
  story: string;
  verified: boolean;
  created_at: string;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  color: string;
  icon: string;
}

export interface UserAchievement {
  id?: string;
  user_id: string;
  badge_type: string; // 'first_idea', '10_days_active', '1_revival', '100_upvotes', etc.
  unlocked_at: string;
}

export interface IdeaComment { id?: string; idea_id: string; author_name: string; content: string; created_at: string; }
