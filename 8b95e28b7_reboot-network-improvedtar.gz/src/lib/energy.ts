import { doc, setDoc, increment } from 'firebase/firestore';
import { db } from './firebase';

export async function addGlobalEnergy(amount: number) {
  try {
    const energyRef = doc(db, 'system', 'global_energy');
    await setDoc(energyRef, { current: increment(amount) }, { merge: true });
  } catch (err) {
    console.error('Failed to add global energy:', err);
  }
}
