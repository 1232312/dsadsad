import { db } from './firebase';
import { collection, addDoc, getDocs, query, doc, updateDoc } from 'firebase/firestore';

export interface ProjectData {
  name: string;
  district: string;
  stage: number;
  status: string;
  founder: string;
  description: string;
  timeline: string;
  reason?: string;
}

export const CreateProjectService = {
  async createProject(projectData: ProjectData) {
    try {
      const docRef = await addDoc(collection(db, 'projects'), {
        ...projectData,
        createdAt: new Date().toISOString(),
      });
      return { ...projectData, id: docRef.id };
    } catch (e) {
      console.error("Error adding document: ", e);
      throw e;
    }
  },

  async getProjects() {
    try {
      const q = query(collection(db, 'projects'));
      const querySnapshot = await getDocs(q);
      const projects: (ProjectData & { id: string })[] = [];
      querySnapshot.forEach((doc) => {
        projects.push({ ...(doc.data() as ProjectData), id: doc.id });
      });
      return projects;
    } catch (e) {
      console.error("Error fetching projects: ", e);
      return [];
    }
  },

  async updateProject(id: string, updates: Partial<ProjectData>) {
    try {
      const docRef = doc(db, 'projects', id);
      await updateDoc(docRef, updates);
    } catch (e) {
      console.error("Error updating document: ", e);
    }
  }
};
