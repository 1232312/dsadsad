export const RANKS = [
  { name: 'Spark', xp: 0, color: '#00FFFF', effects: { glow: 'rgba(0,255,255,0.2)', border: '#00FFFF' } },
  { name: 'Dreamer', xp: 100, color: '#4F8CFF', effects: { glow: 'rgba(79,140,255,0.3)', border: '#4F8CFF' } },
  { name: 'Builder', xp: 250, color: '#00FF88', effects: { glow: 'rgba(0,255,136,0.3)', border: '#00FF88' } },
  { name: 'Creator', xp: 500, color: '#F59E0B', effects: { glow: 'rgba(245,158,11,0.4)', border: '#F59E0B' } },
  { name: 'Innovator', xp: 1000, color: '#FF00CC', effects: { glow: 'rgba(255,0,204,0.4)', border: '#FF00CC' } },
  { name: 'Founder', xp: 2500, color: '#8B5CF6', effects: { glow: 'rgba(139,92,246,0.5)', border: '#8B5CF6' } },
  { name: 'Visionary', xp: 5000, color: '#FF3366', effects: { glow: 'rgba(255,51,102,0.6)', border: '#FF3366' } },
  { name: 'Architect', xp: 10000, color: '#00FFFF', effects: { glow: 'rgba(0,255,255,0.7)', border: '#00FFFF' } },
  { name: 'Legend', xp: 25000, color: '#FFE000', effects: { glow: 'rgba(255,224,0,0.8)', border: '#FFE000' } },
  { name: 'Rebooter', xp: 50000, color: '#FFFFFF', effects: { glow: 'rgba(255,255,255,1)', border: '#FFFFFF' } },
];

export function calculateXP(ideasCount: number, achievementsCount: number, referrals: number, totalUpvotes: number) {
  return (ideasCount * 250) + (achievementsCount * 500) + (referrals * 1000) + (totalUpvotes * 50);
}

export function getRankInfo(xp: number) {
  let currentRank = RANKS[0];
  let nextRank = RANKS[1];
  for (let i = 0; i < RANKS.length; i++) {
    if (xp >= RANKS[i].xp) {
      currentRank = RANKS[i];
      nextRank = RANKS[i + 1] || RANKS[i];
    } else {
      break;
    }
  }
  return { currentRank, nextRank };
}
