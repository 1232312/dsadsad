export class AudioManager {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private currentTier = 1;
  private soundEnabled = true;
  private masterGain: GainNode | null = null;
  private timeoutId: number | null = null;
  private step = 0;
  private nextNoteTime = 0;
  private volume = 0.3;

  // Synthwave bassline notes (frequencies)
  private readonly bassNotes = [
    65.41, // C2
    65.41,
    73.42, // D2
    73.42,
    58.27, // A#1
    58.27,
    65.41, // C2
    65.41,
  ];

  // Arp notes
  private readonly arpNotes = [
    130.81, // C3
    196.00, // G3
    261.63, // C4
    155.56, // D#3
    196.00, // G3
    261.63, // C4
    174.61, // F3
    196.00, // G3
  ];

  init() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
      this.masterGain.gain.value = this.volume; // Base volume
    }
  }

  setVolume(vol: number) {
    this.volume = vol;
    if (this.masterGain && this.soundEnabled) {
      this.masterGain.gain.setTargetAtTime(vol, this.ctx?.currentTime || 0, 0.1);
    }
  }

  getVolume() {
    return this.volume;
  }

  setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    if (this.masterGain) {
      this.masterGain.gain.setTargetAtTime(enabled ? this.volume : 0, this.ctx?.currentTime || 0, 0.1);
    }
  }

  setTier(tier: number) {
    this.currentTier = tier;
  }

  private playNote(freq: number, type: OscillatorType, time: number, dur: number, vol: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    // Pitch shift based on tier
    const pitchMultiplier = 1 + (this.currentTier - 1) * 0.05;
    
    osc.type = type;
    osc.frequency.setValueAtTime(freq * pitchMultiplier, time);

    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(vol, time + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + dur);
  }

  private scheduleNote() {
    if (!this.ctx || !this.masterGain) return;
    
    // Calculate speed based on tier (faster at higher tiers)
    const baseSpeed = 0.25; // seconds per step
    const currentSpeed = Math.max(0.12, baseSpeed - (this.currentTier - 1) * 0.015);

    if (this.soundEnabled) {
      // Play Bass
      const bassFreq = this.bassNotes[this.step % this.bassNotes.length];
      this.playNote(bassFreq, 'sawtooth', this.nextNoteTime, currentSpeed * 0.8, 0.4);

      // Play Arp
      const arpFreq1 = this.arpNotes[(this.step * 2) % this.arpNotes.length];
      const arpFreq2 = this.arpNotes[(this.step * 2 + 1) % this.arpNotes.length];
      this.playNote(arpFreq1, 'square', this.nextNoteTime, currentSpeed * 0.4, 0.1);
      this.playNote(arpFreq2, 'square', this.nextNoteTime + currentSpeed / 2, currentSpeed * 0.4, 0.1);

      // Kick Drum (synthesized)
      if (this.step % 2 === 0) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.frequency.setValueAtTime(150, this.nextNoteTime);
        kickOsc.frequency.exponentialRampToValueAtTime(0.01, this.nextNoteTime + 0.5);
        kickGain.gain.setValueAtTime(0.6, this.nextNoteTime);
        kickGain.gain.exponentialRampToValueAtTime(0.001, this.nextNoteTime + 0.5);
        kickOsc.connect(kickGain);
        kickGain.connect(this.masterGain);
        kickOsc.start(this.nextNoteTime);
        kickOsc.stop(this.nextNoteTime + 0.5);
      }
    }

    this.nextNoteTime += currentSpeed;
    this.step++;
  }

  private scheduler = () => {
    if (!this.isPlaying || !this.ctx) return;
    
    // Schedule notes that need to be played in the next 100ms
    while (this.nextNoteTime < this.ctx.currentTime + 0.1) {
      this.scheduleNote();
    }
    
    this.timeoutId = window.setTimeout(this.scheduler, 25);
  };

  play(type: string) {
    if (!this.soundEnabled) return;
    this.init();
    if (this.ctx?.state === 'suspended') {
      this.ctx.resume();
    }
    
    if (!this.ctx || !this.masterGain) return;

    if (type === 'select') {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.3, this.ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.2);
    }
  }

  start() {
    if (this.isPlaying) return;
    this.init();
    if (this.ctx?.state === 'suspended') {
      this.ctx.resume();
    }
    this.isPlaying = true;
    this.step = 0;
    this.nextNoteTime = this.ctx!.currentTime + 0.1;
    this.scheduler();
  }

  stop() {
    this.isPlaying = false;
    if (this.timeoutId !== null) {
      window.clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
  }
}

export const audioManager = new AudioManager();
