const fs = require('fs');
let code = fs.readFileSync('src/components/City3D.tsx', 'utf-8');

// Fix group opacity
code = code.replace(/<group opacity=\{0.1\} transparent>/, '<group>');

// Fix Text opacity
code = code.replace(/opacity=\{0.3\}\n\s*transparent\n\s*outlineWidth=\{0.05\}\n\s*outlineColor="black"/g, 'fillOpacity={0.3} outlineWidth={0.05} outlineColor="black"');
code = code.replace(/opacity=\{0.6\} transparent font=/g, 'fillOpacity={0.6} font=');

// Fix Grid opacity
code = code.replace(/fadeStrength=\{1.5\}\n\s*opacity=\{0.2\}\n\s*transparent/g, 'fadeStrength={1.5}');
code = code.replace(/fadeStrength=\{2\}\n\s*opacity=\{0.3\}\n\s*transparent/g, 'fadeStrength={2}');

// Fix ChromaticAberration offset
code = code.replace(/<ChromaticAberration offset=\{new THREE.Vector2\(0.0005, 0.0005\)\} \/>/g, '<ChromaticAberration offset={new THREE.Vector2(0.0005, 0.0005)} radialModulation={false} modulationOffset={0} />');

fs.writeFileSync('src/components/City3D.tsx', code);
